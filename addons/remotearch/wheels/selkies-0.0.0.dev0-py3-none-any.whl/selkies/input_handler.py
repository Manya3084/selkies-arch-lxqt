# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# This file incorporates work covered by the following copyright and
# permission notice:
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import ctypes
import fcntl
import functools
import logging
import select
import struct
import threading
import time
import asyncio
from asyncio import subprocess
import socket
import os
import base64
import io
import re
import json
import aiofiles
import msgpack
from PIL import Image
import urllib.parse
import urllib.request
from .display_utils import (
    pixelflux_x11_cursor,
    unpremultiply_rgba,
    cursor_content_handle,
)
from .media_pipeline import RateControlMode
from .settings import settings, WS_MAX_MESSAGE_BYTES
try:
    from pixelflux import VirtualKeyboardUnavailable as PixelfluxVkUnavailable
except Exception:
    class PixelfluxVkUnavailable(RuntimeError):
        """Stand-in when pixelflux predates the typed exception."""
try:
    libxkb = ctypes.CDLL("libxkbcommon.so.0")
    libxkb.xkb_keysym_to_utf8.argtypes = [ctypes.c_uint32, ctypes.c_char_p, ctypes.c_size_t]
    libxkb.xkb_keysym_to_utf8.restype = ctypes.c_int
    # Keymap-compilation surface for _WaylandKeymapOwner: compile a keymap string
    # and enumerate keysyms per keycode/level.
    libxkb.xkb_context_new.argtypes = [ctypes.c_int]
    libxkb.xkb_context_new.restype = ctypes.c_void_p
    libxkb.xkb_context_unref.argtypes = [ctypes.c_void_p]
    libxkb.xkb_keymap_new_from_string.argtypes = [
        ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
    libxkb.xkb_keymap_new_from_string.restype = ctypes.c_void_p
    libxkb.xkb_keymap_unref.argtypes = [ctypes.c_void_p]
    libxkb.xkb_keymap_min_keycode.argtypes = [ctypes.c_void_p]
    libxkb.xkb_keymap_min_keycode.restype = ctypes.c_uint32
    libxkb.xkb_keymap_max_keycode.argtypes = [ctypes.c_void_p]
    libxkb.xkb_keymap_max_keycode.restype = ctypes.c_uint32
    libxkb.xkb_keymap_num_levels_for_key.argtypes = [
        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    libxkb.xkb_keymap_num_levels_for_key.restype = ctypes.c_uint32
    libxkb.xkb_keymap_key_get_syms_by_level.argtypes = [
        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.POINTER(ctypes.c_uint32))]
    libxkb.xkb_keymap_key_get_syms_by_level.restype = ctypes.c_int
    libxkb.xkb_utf32_to_keysym.argtypes = [ctypes.c_uint32]
    libxkb.xkb_utf32_to_keysym.restype = ctypes.c_uint32
except Exception:
    libxkb = None

try:
    from . import Xlib
    from .Xlib import display
    from .Xlib import X
    from .Xlib import XK
    from .Xlib.ext import xfixes, xtest
    from .Xlib.protocol import event as xevent
    from .Xlib import error as xlib_error
    X11_LIBS_AVAILABLE = True
except ImportError:
    X11_LIBS_AVAILABLE = False
    Xlib = None
    display = None
    X = None
    XK = None
    xlib_error = None
    xfixes = None
    xtest = None
    xevent = None

try:
    from pixelflux import ScreenCapture
except (ImportError, RuntimeError):
    ScreenCapture = None

# Server-side input authority, shared by both transports so a modified client
# can't inject input a controller didn't grant. A read-only viewer peer
# (shared/#player co-op) may only send VIEWER_ALLOWED_PREFIXES; a viewer
# holding the active mk token while enable_collab is on (a read-write
# collaborator) may additionally send the keyboard/mouse/clipboard set below.
# cmd and other settings-mutating messages stay controller-only on both.
VIEWER_ALLOWED_PREFIXES = (
    "SETTINGS,",
    "START_VIDEO",
    # A viewer must be able to pause its own video feed on tab hide (the client
    # sends this); without it a broadcast-pause can never trigger for viewers.
    "STOP_VIDEO",
    "REQUEST_KEYFRAME",
    "js,",
)
VIEWER_COLLAB_EXTRA_PREFIXES = (
    "kd", "ku", "kh", "kr", "m", "m2",
    # co,end is keyboard input like kd/ku: IME commits and atomic typing arrive
    # this way, so blocking it strips composed text from a collaborator.
    "co,",
    "cws", "cbs", "cwd", "cbd", "cwe", "cbe", "cw", "cb", "cr",
    "REQUEST_CLIPBOARD",
)
# Lifecycle noise every client emits on blur/visibility changes (kr =
# release-all, cr = clipboard read-back): a read-only viewer sending them is
# normal operation, so they are dropped without a warning.
VIEWER_SILENT_DROP_PREFIXES = ("kr", "cr")


class _WaylandKeymapOwner:
    """Owns keysym policy for the Wayland compositor: resolves keysyms to keycodes
    against the compositor's own keymap (synthesizing Shift/AltGr for leveled
    glyphs) and binds unmapped keysyms — Unicode codepoints, IME output — to spare
    overlay keycodes by swapping in a rebuilt keymap. Everything is delivered
    through inject_key / set_keymap_string on the one compositor channel, so key
    ordering holds. Raises on failure so the caller can fall back."""

    # Overlay keycodes are chosen from the live keymap in _build_map rather than
    # fixed, because they must stay under X11's 255 ceiling for XWayland apps to
    # receive them. These bound the search.
    _SUB256_CEILING = 256
    # Overflow past the ceiling, appended so a layout with no room still works for
    # Wayland clients instead of failing outright; XWayland cannot see these.
    _OVERFLOW_BASE_KEYCODE = 257
    _OVERFLOW_SLOTS = 64

    def __init__(self, wayland_input, base_keymap_text):
        if libxkb is None:
            raise RuntimeError("libxkbcommon unavailable")
        if not base_keymap_text:
            raise RuntimeError("empty compositor keymap")
        self._input = wayland_input
        self._base_text = base_keymap_text
        # _map: keysym -> (keycode, level)
        # _overlay: keysym -> overlay keycode
        # _overlay_order: round-robin recycle order
        # _pressed: keysym -> (keycode, SYNTHESIZED modifier keycodes)
        # _mod_refs: synthesized modifier keycode -> holders
        # _down: every keycode currently injected down — the one live view
        # synth-skip and conflict-lift decisions read (no compositor query)
        self._map = {}
        self._overlay = {}
        self._overlay_order = []
        self._pressed = {}
        self._mod_refs = {}
        self._down = set()
        self._build_map()

    def _build_map(self):
        ctx = libxkb.xkb_context_new(0)
        if not ctx:
            raise RuntimeError("xkb_context_new failed")
        try:
            # Trailing arguments are TEXT_V1 and NO_FLAGS.
            km = libxkb.xkb_keymap_new_from_string(
                ctx, self._base_text.encode(), 1, 0)
            if not km:
                raise RuntimeError("keymap compile failed")
            try:
                lo = libxkb.xkb_keymap_min_keycode(km)
                hi = libxkb.xkb_keymap_max_keycode(km)
                syms = ctypes.POINTER(ctypes.c_uint32)()
                # Overlay pool, gathered in this same walk. Under X11 a keycode is
                # a byte, so XWayland clients never see anything above 255; emoji and
                # CJK bound up there would reach Wayland apps only. The sub-256 range
                # is nearly full on a pc105 keymap, so unbound keycodes are taken
                # first, then ones carrying only XF86 media/browser keysyms. All the
                # rest down there is load bearing (modifiers, F-keys, punctuation,
                # Print) and is never touched.
                unbound, shadowable = [], []
                for kc in range(lo, hi + 1):
                    levels = min(4, libxkb.xkb_keymap_num_levels_for_key(km, kc, 0))
                    seen = spare = 0
                    for level in range(levels):
                        n = libxkb.xkb_keymap_key_get_syms_by_level(
                            km, kc, 0, level, ctypes.byref(syms))
                        for i in range(n):
                            sym = syms[i]
                            if not sym:
                                continue
                            seen += 1
                            if self._VENDOR_FIRST <= sym <= self._VENDOR_LAST:
                                spare += 1
                            if sym not in self._map:
                                self._map[sym] = (kc, level)
                    if kc < self._SUB256_CEILING and kc >= max(lo, 9):
                        if not seen:
                            unbound.append(kc)
                        elif seen == spare:
                            shadowable.append(kc)
                self._overlay_codes = unbound + shadowable + list(range(
                    self._OVERFLOW_BASE_KEYCODE,
                    self._OVERFLOW_BASE_KEYCODE + self._OVERFLOW_SLOTS))
            finally:
                libxkb.xkb_keymap_unref(km)
        finally:
            libxkb.xkb_context_unref(ctx)
        # Modifier keycodes for level synthesis; conventional evdev+8 fallbacks.
        self._shift_kc = self._map.get(0xFFE1, (50, 0))[0]
        self._shift_r_kc = self._map.get(0xFFE2, (62, 0))[0]
        self._altgr_kc = self._map.get(0xFE03, (108, 0))[0]

    def resolves(self, keysym):
        """Whether the base keymap carries this keysym on some key/level — i.e.
        it can be injected without an overlay bind."""
        return keysym in self._map

    def _held_conflicts(self, required):
        """Shift/AltGr keycodes currently down (client-pressed or synthesized)
        that the target level does not want: held, they would shift the injected
        key onto a different glyph. A required Shift is satisfied by either
        side, so neither is lifted then."""
        shift_wanted = self._shift_kc in required
        out = []
        for kc in (self._shift_kc, self._shift_r_kc, self._altgr_kc):
            if not kc or kc not in self._down or kc in required:
                continue
            if shift_wanted and kc in (self._shift_kc, self._shift_r_kc):
                continue
            out.append(kc)
        return out

    def _inject(self, kc, state):
        (self._down.add if state else self._down.discard)(kc)
        self._input.inject_key(kc, state)

    # XF86 vendor keysym block: media and browser keys a streamed session does not
    # need, so their keycodes can be shadowed by the overlay. Matched numerically —
    # a name lookup per keysym doubled the cost of building the map.
    _VENDOR_FIRST = 0x10080000
    _VENDOR_LAST = 0x1008FFFF

    def _mods_for_level(self, level):
        mods = []
        if level & 1:
            mods.append(self._shift_kc)
        if level & 2:
            mods.append(self._altgr_kc)
        return tuple(mods)

    def _overlay_text(self):
        """Base keymap text with the overlay keycodes appended and every occupied
        slot bound to its keysym at level 0 (hex keysym literals need no names)."""
        base = self._base_text
        max_at = base.index("maximum = ")
        max_end = base.index(";", max_at)
        # Only the slots actually in use are declared, and at the keycodes the pool
        # handed out (which are mostly existing sub-256 codes being shadowed). The
        # base's own maximum is kept: a pc105 keymap binds a couple of hundred
        # keycodes above 255, and lowering the ceiling would drop every one of them.
        used = sorted(self._overlay.values())
        base_max = int(base[max_at + len("maximum = "):max_end].strip())
        parts = [base[:max_at],
                 f"maximum = {max([base_max] + used)}"]
        rest = base[max_end:]
        kc_end = rest.index("};")
        parts.append(rest[:kc_end])
        for kc in used:
            parts.append(f"\t<UC{kc:03}> = {kc};\n")
        rest = rest[kc_end:]
        sym_at = rest.index("xkb_symbols")
        open_at = rest.index("{", sym_at)
        depth = 0
        close_at = None
        for idx in range(open_at, len(rest)):
            ch = rest[idx]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    close_at = idx
                    break
        if close_at is None:
            raise RuntimeError("unbalanced xkb_symbols section")
        parts.append(rest[:close_at])
        for keysym, kc in self._overlay.items():
            parts.append(
                f"\tkey <UC{kc:03}> {{ [ {overlay_bind_keysym(keysym):#x} ] }};\n")
        parts.append(rest[close_at:])
        return "".join(parts)

    def _overlay_bind_many(self, keysyms):
        """Assign overlay keycodes to every keysym not already bound, then swap the
        keymap ONCE for the whole batch. A swap costs milliseconds on the compositor
        thread (which also drives input and rendering), so binding a burst one at a
        time would stall it proportionally. Returns {keysym: keycode}."""
        held = {kc for kc, _ in self._pressed.values()}
        out = {}
        fresh = False
        for keysym in dict.fromkeys(keysyms):
            kc = self._overlay.get(keysym)
            if kc is None:
                if len(self._overlay) >= len(self._overlay_codes):
                    # Recycle the oldest slot that is not held down: rebinding a
                    # pressed keycode would make its release report a different
                    # symbol than its press did.
                    victim = next(
                        (s for s in self._overlay_order if self._overlay[s] not in held),
                        None,
                    )
                    if victim is None:
                        out[keysym] = 0
                        continue
                    self._overlay_order.remove(victim)
                    kc = self._overlay.pop(victim)
                else:
                    kc = self._overlay_codes[len(self._overlay)]
                self._overlay[keysym] = kc
                self._overlay_order.append(keysym)
                held.add(kc)
                fresh = True
            out[keysym] = kc
        if fresh:
            # Both calls ride the one command channel the key events use and
            # neither awaits a reply, so the swap is drained before the keys that
            # need it while this loop is never blocked on the compositor. The
            # splice hands over just the binds; the fallback rebuilds and re-sends
            # the whole keymap text, which costs a redundant compile on the far side.
            binds = [(kc, overlay_bind_keysym(sym))
                     for sym, kc in self._overlay.items()]
            splice = getattr(self._input, "set_keymap_overlay", None)
            if splice is not None:
                splice(binds)
            else:
                self._input.set_keymap_string(self._overlay_text())
        return out

    def _overlay_bind(self, keysym):
        return self._overlay_bind_many([keysym])[keysym]

    def _tap(self, kc, mods, into=None):
        """Momentary press+release with refcounted modifier synthesis; a
        modifier the client itself holds down is left alone.

        With `into`, the events are appended to that list instead of injected, so a
        caller typing a run of characters can hand the compositor one ordered batch —
        an event at a time costs a channel send and a calloop wake each, on the thread
        that also renders."""
        out = [] if into is None else into
        synthed = []
        for m in mods:
            if m in self._down and m not in self._mod_refs:
                continue
            self._mod_refs[m] = self._mod_refs.get(m, 0) + 1
            if self._mod_refs[m] == 1:
                out.append((m, 1))
            synthed.append(m)
        out.append((kc, 1))
        out.append((kc, 0))
        for m in reversed(synthed):
            refs = self._mod_refs.get(m, 0) - 1
            if refs <= 0:
                self._mod_refs.pop(m, None)
                out.append((m, 0))
            else:
                self._mod_refs[m] = refs
        if into is None:
            self._inject_run(out)

    def _inject_run(self, events):
        """Deliver an ordered run of (keycode, state) events, batched when the
        compositor accepts a batch."""
        if not events:
            return
        for kc, state in events:
            (self._down.add if state else self._down.discard)(kc)
        batch = getattr(self._input, "inject_keys", None)
        if batch is not None:
            batch(events)
            return
        for kc, state in events:
            self._input.inject_key(kc, state)

    def type_text(self, text, neutralize=False):
        """Type text as momentary taps, resolving every missing keysym in ONE keymap
        swap (no per-char swap storm) — through the compositor's batch API when it
        offers one, else through the local overlay, which batches the same way.
        Each char prefers its canonical layout keysym (a ru layout types ф on its
        own key) before falling to the overlay. With neutralize, conflicting held
        Shift/AltGr are lifted around the whole run so the taps land on their
        resolved levels. Returns False, having typed nothing, when a char cannot
        be bound at all."""
        keysyms = []
        for ch in text:
            ks = character_to_layout_keysym(ch)
            if ks not in self._map:
                cp = ord(ch)
                ks = cp if 0x20 <= cp <= 0xFF else (0x01000000 | cp)
            keysyms.append(ks)
        missing = [ks for ks in dict.fromkeys(keysyms) if ks not in self._map]
        overlay = self._overlay_bind_many(missing) if missing else {}
        # Resolve everything before touching any state, so the False path
        # really has typed nothing (and charged no modifier refs).
        resolved_keys = []
        for ks in keysyms:
            resolved = self._map.get(ks)
            if resolved is None and overlay.get(ks):
                resolved = (overlay[ks], 0)
            if resolved is None:
                return False
            resolved_keys.append(resolved)
        # Lift conflicts BEFORE building the taps: with the lift reflected in
        # _down, a shifted char inside the run synthesizes its Shift normally.
        lifted = self._held_conflicts(()) if neutralize else []
        for kc in lifted:
            self._inject(kc, 0)
        events = []
        for kc, level in resolved_keys:
            self._tap(kc, self._mods_for_level(level), into=events)
        self._inject_run(events + [(kc, 1) for kc in reversed(lifted)])
        return True

    def press(self, keysym, neutralize=False):
        held = self._pressed.get(keysym)
        if held is not None:
            # Auto-repeat re-press: re-inject the key only; modifier refcounts and
            # the held map were charged by the first press.
            self._inject(held[0], 1)
            return
        resolved = self._map.get(keysym)
        if resolved is not None:
            kc, level = resolved
            mods = self._mods_for_level(level)
        else:
            kc = self._overlay_bind(keysym)
            if not kc:
                # Every slot is held down, so there is nothing to bind this to.
                # Injecting keycode 0 would press a key that does not exist.
                return
            mods = ()
        # A held Shift/AltGr the target level does not want would move the key
        # onto a different glyph (a client layout's Shift pairing rarely matches
        # the seat layout's): lift it for the press, restore it after. Chords are
        # exempt via neutralize so Ctrl+Shift+X passes through untouched.
        lifted = self._held_conflicts(set(mods)) if neutralize else []
        for m in lifted:
            self._inject(m, 0)
        # Synthesize only modifiers not already down; a modifier the client
        # holds as its own key is neither charged nor released here.
        synthed = []
        for m in mods:
            already = (m in self._down
                       or (m == self._shift_kc and self._shift_r_kc in self._down))
            if already and m not in self._mod_refs:
                continue
            self._mod_refs[m] = self._mod_refs.get(m, 0) + 1
            if self._mod_refs[m] == 1:
                self._inject(m, 1)
            synthed.append(m)
        self._pressed[keysym] = (kc, tuple(synthed))
        self._inject(kc, 1)
        for m in reversed(lifted):
            self._inject(m, 1)

    def release(self, keysym):
        held = self._pressed.pop(keysym, None)
        if held is None:
            return
        kc, mods = held
        self._inject(kc, 0)
        for m in reversed(mods):
            refs = self._mod_refs.get(m, 0) - 1
            if refs <= 0:
                self._mod_refs.pop(m, None)
                self._inject(m, 0)
            else:
                self._mod_refs[m] = refs

    def reset(self):
        """Release every held key and synthetic modifier."""
        for keysym in list(self._pressed):
            try:
                self.release(keysym)
            except Exception:
                self._pressed.pop(keysym, None)
        for m in list(self._mod_refs):
            try:
                self._inject(m, 0)
            except Exception:
                pass
        self._mod_refs.clear()
        self._down.clear()


class _X11ClipboardMonitor:
    """Event-driven X11 CLIPBOARD access on a dedicated Display connection:
    XFixes selection-owner events signal changes (no polling, no xclip forks) and
    reads go through ConvertSelection with INCR support for large payloads.
    Every Display call runs on this class's own event thread (python-xlib is not
    thread-safe); callers hand it work via a self-pipe. Writes are native too:
    offer() takes CLIPBOARD ownership and the event thread serves SelectionRequest
    (TARGETS + text aliases, or the stored image mime) until another app takes over
    (SelectionClear). xclip remains only as the caller's fallback."""

    _READ_TIMEOUT_S = 5.0
    # INCR reads accumulate at most this much (matches the Wayland read cap).
    _READ_MAX_BYTES = 64 * 1024 * 1024
    # Cap on a file-manager (text/uri-list) image pasted from disk.
    _URI_FILE_MAX_BYTES = 10 * 1024 * 1024
    # Per-ChangeProperty chunk: stays under the classic 256 KiB X11 request limit
    # (python-xlib has no BIG-REQUESTS); large payloads append in chunks BEFORE the
    # SelectionNotify, so requestors read one complete property and INCR is not needed.
    _WRITE_CHUNK = 240 * 1024

    def __init__(self, display_name=None):
        # Bounded handshake + reply waits: the monitor is (re)built from the event
        # loop, sometimes while the server is disrupted — the exact moment an
        # unbounded connection setup would freeze the loop.
        self._d = display.Display(display_name, blocking_timeout=INPUT_X_REPLY_TIMEOUT_S)
        self._cmd_r = self._cmd_w = -1
        try:
            self._build()
        except BaseException:
            # Every statement below is a round trip on a connection with a bounded
            # reply wait, so a disrupted server raises part-way through. The caller
            # retries on a timer, and a connection stranded per attempt exhausts the
            # server's client slots within minutes, after which every unrelated
            # component fails to reach the display.
            self._release_resources()
            raise

    def _release_resources(self):
        for fd in (self._cmd_r, self._cmd_w):
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass
        self._cmd_r = self._cmd_w = -1
        try:
            self._d.close()
        except Exception:
            pass

    def _build(self):
        if not self._d.has_extension('XFIXES'):
            raise RuntimeError("XFixes not available")
        self._d.xfixes_query_version()
        screen = self._d.screen()
        # Unmapped InputOutput window: receives SelectionNotify/PropertyNotify and
        # holds the transfer property; never mapped, so never visible.
        self._win = screen.root.create_window(
            0, 0, 1, 1, 0, screen.root_depth, window_class=X.InputOutput,
            event_mask=X.PropertyChangeMask)
        self._clipboard = self._d.get_atom('CLIPBOARD')
        # Middle-click paste mirrors what the Wayland compositor does natively:
        # content written from the browser is offered on PRIMARY too.
        self._primary = self._d.get_atom('PRIMARY')
        self._prop = self._d.get_atom('SELKIES_CLIP')
        self._incr = self._d.get_atom('INCR')
        self._targets = self._d.get_atom('TARGETS')
        # Pre-intern every target we can consume (all Display calls happen here,
        # before the event thread starts; read() then only compares atom ids).
        # Same set, in the same precedence order, as the Wayland data-control read
        # and the xclip fallback: a target offered on one path must be readable on
        # all of them. read() walks this list; offer() maps a write mime from it.
        self._image_targets = [(self._d.get_atom(m), m) for m in (
            'image/png', 'image/jpeg', 'image/bmp', 'image/webp', 'image/svg+xml',
            'image/svg')]
        self._text_targets = [(self._d.get_atom(t), t) for t in (
            'UTF8_STRING', 'text/plain;charset=utf-8', 'STRING')]
        # File managers copy an image as a text/uri-list of file:// URIs, not the
        # image bytes; resolve it locally so a paste from the file manager works
        # in-process (the xclip fallback covered only this case).
        self._uri_list_atom = self._d.get_atom('text/uri-list')
        self._d.xfixes_select_selection_input(
            self._win, self._clipboard,
            xfixes.XFixesSetSelectionOwnerNotifyMask
            | xfixes.XFixesSelectionWindowDestroyNotifyMask
            | xfixes.XFixesSelectionClientCloseNotifyMask)
        self._d.flush()
        self._atom_atom = self._d.get_atom('ATOM')
        self._multiple = self._d.get_atom('MULTIPLE')
        self._text_alias_atoms = [a for a, _n in self._text_targets] + [
            self._d.get_atom('TEXT'), self._d.get_atom('text/plain')]
        self._changed = threading.Event()
        self._pending_target = None
        self._reply = None
        self._reply_done = threading.Event()
        # One in-flight conversion at a time.
        self._read_lock = threading.Lock()
        # Owned-selection payload, staged by offer() and served by the event thread.
        self._own_data = None
        self._own_mime_atom = None
        self._own_is_text = False
        self._pending_own = None
        self._own_done = threading.Event()
        self._own_ok = False
        self._cmd_r, self._cmd_w = os.pipe()
        self._stop = False
        self._thread = threading.Thread(target=self._event_loop, daemon=True,
                                        name="X11ClipboardMonitor")
        self._thread.start()

    # ---- event thread ----

    def _event_loop(self):
        xfd = self._d.fileno()
        while not self._stop:
            try:
                r, _, _ = select.select([xfd, self._cmd_r], [], [], 1.0)
            except (OSError, ValueError):
                break
            if self._cmd_r in r:
                os.read(self._cmd_r, 64)
                target = self._pending_target
                if target is not None:
                    self._pending_target = None
                    try:
                        self._win.convert_selection(self._clipboard, target,
                                                    self._prop, X.CurrentTime)
                        self._d.flush()
                    except Exception:
                        self._reply = None
                        self._reply_done.set()
                own = self._pending_own
                if own is not None:
                    self._pending_own = None
                    self._take_ownership(own)
            if xfd in r or self._d.pending_events():
                try:
                    while self._d.pending_events():
                        ev = self._d.next_event()
                        self._dispatch_event(ev)
                except Exception:
                    if not self._stop:
                        time.sleep(0.1)

    def _dispatch_event(self, ev):
        if isinstance(ev, xfixes.SelectionNotify):
            self._changed.set()
        elif ev.type == X.SelectionNotify:
            self._collect_selection(ev)
        elif ev.type == X.SelectionRequest:
            self._serve_selection(ev)
        elif ev.type == X.SelectionClear:
            # We serve one payload on CLIPBOARD and PRIMARY; drop it only once a
            # foreign owner has taken BOTH (a text-selection steal of PRIMARY must
            # not orphan the browser-written CLIPBOARD payload, and vice versa).
            try:
                owners = (self._d.get_selection_owner(self._clipboard),
                          self._d.get_selection_owner(self._primary))
                if any(getattr(o, 'id', o) == self._win.id for o in owners):
                    return
            except Exception:
                pass
            self._own_data = None
            self._own_mime_atom = None

    def _take_ownership(self, payload):
        data, mime_atom, is_text = payload
        try:
            self._own_data = data
            self._own_mime_atom = mime_atom
            self._own_is_text = is_text
            self._win.set_selection_owner(self._clipboard, X.CurrentTime)
            # Middle-click paste parity with Wayland: offer the same payload on
            # PRIMARY. _serve_selection answers from the one staged payload
            # whatever selection a request names, so both are backed by it.
            self._win.set_selection_owner(self._primary, X.CurrentTime)
            self._d.flush()
            owner = self._d.get_selection_owner(self._clipboard)
            self._own_ok = (getattr(owner, 'id', owner) == self._win.id)
        except Exception:
            self._own_ok = False
        self._own_done.set()

    def _serve_selection(self, ev):
        """Answer a SelectionRequest for the payload offer() staged (ICCCM)."""
        prop = ev.property if ev.property != X.NONE else ev.target
        granted = X.NONE
        try:
            requestor = ev.requestor
            data = self._own_data
            if data is not None and ev.target == self._targets:
                offered = [self._targets]
                if self._own_is_text:
                    offered += self._text_alias_atoms
                elif self._own_mime_atom is not None:
                    offered.append(self._own_mime_atom)
                requestor.change_property(prop, self._atom_atom, 32, offered)
                granted = prop
            elif data is not None and ev.target != self._multiple and (
                    (self._own_is_text and ev.target in self._text_alias_atoms)
                    or ev.target == self._own_mime_atom):
                # Chunked appends stay under the 256 KiB request limit; the property
                # is complete before the notify below, so no INCR is needed.
                requestor.change_property(prop, ev.target, 8,
                                          data[:self._WRITE_CHUNK])
                offset = self._WRITE_CHUNK
                while offset < len(data):
                    requestor.change_property(prop, ev.target, 8,
                                              data[offset:offset + self._WRITE_CHUNK],
                                              mode=X.PropModeAppend)
                    offset += self._WRITE_CHUNK
                granted = prop
        except Exception:
            granted = X.NONE
        try:
            notify = xevent.SelectionNotify(
                time=ev.time, requestor=ev.requestor, selection=ev.selection,
                target=ev.target, property=granted)
            ev.requestor.send_event(notify)
            self._d.flush()
        except Exception:
            pass

    def _prop_bytes(self, prop):
        v = prop.value
        if isinstance(v, str):
            return v.encode('latin-1')
        if isinstance(v, (bytes, bytearray)):
            return bytes(v)
        return bytes(bytearray(v))

    def _collect_selection(self, ev):
        """On the event thread: fetch the converted property (INCR-aware)."""
        try:
            if ev.property == X.NONE:
                self._reply = None
                self._reply_done.set()
                return
            prop = self._win.get_full_property(self._prop, X.AnyPropertyType)
            self._win.delete_property(self._prop)
            self._d.flush()
            if prop is None:
                self._reply = None
            elif prop.property_type == self._incr:
                # INCR: each property delete requests the next chunk; a zero-length
                # chunk ends the transfer. Wait for events with the remaining
                # deadline — a stalled owner must time the read out, not wedge the
                # event thread inside a blocking next_event(). Total size is capped
                # like the Wayland read so a hostile owner cannot balloon memory.
                chunks = []
                total = 0
                deadline = time.monotonic() + self._READ_TIMEOUT_S
                while time.monotonic() < deadline and total <= self._READ_MAX_BYTES:
                    if not self._d.pending_events():
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            break
                        r, _, _ = select.select([self._d.fileno()], [], [], remaining)
                        if not r or not self._d.pending_events():
                            continue
                    e = self._d.next_event()
                    if (e.type == X.PropertyNotify and e.atom == self._prop
                            and e.state == X.PropertyNewValue):
                        part = self._win.get_full_property(self._prop, X.AnyPropertyType)
                        self._win.delete_property(self._prop)
                        self._d.flush()
                        if part is None or len(part.value) == 0:
                            break
                        piece = self._prop_bytes(part)
                        chunks.append(piece)
                        total += len(piece)
                    elif e.type in (X.SelectionRequest, X.SelectionClear) \
                            or isinstance(e, xfixes.SelectionNotify):
                        # Keep serving paste requests mid-INCR read.
                        self._dispatch_event(e)
                self._reply = (b"".join(chunks), 8)
            elif prop.format == 32:
                self._reply = (list(prop.value), 32)
            else:
                self._reply = (self._prop_bytes(prop), prop.format)
            self._reply_done.set()
        except Exception:
            self._reply = None
            self._reply_done.set()

    # ---- caller side (blocking; run via executor) ----

    def _convert_and_wait(self, target_atom):
        with self._read_lock:
            self._reply = None
            self._reply_done.clear()
            self._pending_target = target_atom
            os.write(self._cmd_w, b"x")
            if not self._reply_done.wait(self._READ_TIMEOUT_S):
                return None
            return self._reply

    def read(self, use_binary):
        """Blocking read (call via executor): (data, mime) like read_clipboard —
        text as str with mime 'text/plain', images as bytes with their mime."""
        reply = self._convert_and_wait(self._targets)
        if not reply or reply[1] != 32:
            # A fresh owner (e.g. xclip mid-fork) may not serve requests for a
            # moment after the owner-change event; one short retry covers it.
            time.sleep(0.1)
            reply = self._convert_and_wait(self._targets)
            if not reply or reply[1] != 32:
                return None, None
        offered = set(reply[0])
        if use_binary:
            for atom, mime in self._image_targets:
                if atom in offered:
                    got = self._convert_and_wait(atom)
                    if got and got[0]:
                        return bytes(got[0]), mime
            # File-manager copy: no image target, but a text/uri-list of file://
            # URIs pointing at an image on disk.
            if self._uri_list_atom in offered:
                got = self._convert_and_wait(self._uri_list_atom)
                if got and got[0]:
                    resolved = self._resolve_uri_list_image(bytes(got[0]))
                    if resolved is not None:
                        return resolved
        for atom, _name in self._text_targets:
            if atom in offered:
                got = self._convert_and_wait(atom)
                if got is not None and got[0] is not None:
                    return bytes(got[0]).decode('utf-8', errors='replace'), 'text/plain'
        return None, None

    def _resolve_uri_list_image(self, data_bytes):
        """Resolve a text/uri-list (file-manager copy) to (image_bytes, mime): the
        first local file:// URI with a known image extension, read bounded. Returns
        None when nothing qualifies."""
        mime_map = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                    '.bmp': 'image/bmp', '.webp': 'image/webp', '.svg': 'image/svg+xml'}
        try:
            text = data_bytes.decode('utf-8', errors='replace')
        except Exception:
            return None
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            try:
                parsed = urllib.parse.urlparse(line)
                if parsed.scheme != 'file':
                    continue
                path = urllib.request.url2pathname(parsed.path)
                if not os.path.isfile(path):
                    continue
                mime = mime_map.get(os.path.splitext(path)[1].lower())
                if not mime:
                    continue
                if 0 < os.path.getsize(path) <= self._URI_FILE_MAX_BYTES:
                    with open(path, 'rb') as f:
                        return f.read(self._URI_FILE_MAX_BYTES), mime
            except (OSError, ValueError):
                # ValueError: urlparse rejects malformed bracketed authorities;
                # one bad line must not kill the whole clipboard read.
                continue
        return None

    def offer(self, data, mime_type):
        """Blocking (call via executor): take CLIPBOARD ownership and serve `data`
        until another app copies. Returns True when ownership was acquired."""
        if not data:
            return False
        is_text = mime_type == "text/plain"
        data_bytes = data if isinstance(data, bytes) else data.encode('utf-8')
        mime_atom = None
        if not is_text:
            known = dict((m, a) for a, m in self._image_targets)
            mime_atom = known.get(mime_type)
            if mime_atom is None:
                return False
        with self._read_lock:
            self._own_done.clear()
            self._own_ok = False
            self._pending_own = (data_bytes, mime_atom, is_text)
            os.write(self._cmd_w, b"o")
            if not self._own_done.wait(self._READ_TIMEOUT_S):
                return False
            return self._own_ok

    async def wait_change(self, timeout):
        """Await a selection-owner change (True) or timeout (False)."""
        loop = asyncio.get_running_loop()
        got = await loop.run_in_executor(None, self._changed.wait, timeout)
        if got:
            self._changed.clear()
        return got

    def alive(self):
        """False once the event thread has exited (display disruption, XFixes
        error). A dead monitor never reports another change, so the outbound
        monitor loop rebuilds it instead of waiting on it forever."""
        return not self._stop and self._thread.is_alive()

    def close(self):
        self._stop = True
        try:
            os.write(self._cmd_w, b"q")
        except OSError:
            pass
        # Let the event thread leave its select() before the display closes under it.
        self._thread.join(timeout=2.0)
        self._release_resources()


class _XTestKeyboard:
    """Keyboard controller backed by the bundled python-xlib XTEST extension.
    Injects key events through the already-open self.xdisplay connection; a
    separate second X-display connection whose blocking sync could spin at
    100% CPU inside connect() is deliberately avoided."""

    # Spare keycodes past the base layout, bound on demand to keysyms the layout
    # lacks (Unicode, exotic symbols) so they inject in-process via XTEST instead of
    # forking xdotool. Round-robin recycled; the reverse of TigerVNC/x0vncserver's
    # XkbAddKeyKeysym, done through core ChangeKeyboardMapping.

    # Settle after rebinding a RECYCLED keycode: the server applies the mapping
    # synchronously (sync()), but xcb-class toolkits refetch keymaps
    # asynchronously and could translate the queued press with the old symbol.
    _RECYCLE_SETTLE_S = 0.01

    def __init__(self, xdisplay):
        self._d = xdisplay
        # XK_Shift_L; may be 0 on an exotic keymap (then capitals just skip shift).
        self._shift_kc = xdisplay.keysym_to_keycode(0xffe1)
        # XK_Shift_R: a client-held Shift may be down on either keycode.
        self._shift_r_kc = xdisplay.keysym_to_keycode(0xffe2)
        # AltGr, to reach glyphs bound above the Shift level (e.g. '@' on an Italian
        # or German keymap): prefer ISO_Level3_Shift, fall back to Mode_switch.
        self._altgr_kc = (xdisplay.keysym_to_keycode(0xfe03)
                          or xdisplay.keysym_to_keycode(0xff7e))
        self._effective_mod_keycodes = self._read_effective_modifiers()
        # keysym -> the modifier keycodes press() synthesized for it. release() undoes
        # only these, so a modifier the client is physically holding (injected via the
        # XTEST fast path) is never force-released here.
        self._synth_mods = {}
        # Dynamic-overlay state (lazy): spare keycodes, keysym->keycode bindings,
        # and the keycode used at PRESS so release replays it (never re-resolves,
        # matching neko's XKeyEntryGet — the layout may shift mid-keystroke).
        # _overlay: keysym -> keycode
        # _overlay_value_kc: bound VALUE (overlay_bind_keysym) -> keycode,
        # kept in step with _overlay so value lookups need no scan
        # _overlay_order: round-robin recycle order
        # _pressed_kc: keysym -> keycode injected at press
        # _dirty_spares: reclaimed keycodes whose first bind needs a settle
        self._spare_keycodes = None
        self._spare_set = frozenset()
        self._overlay = {}
        self._overlay_value_kc = {}
        self._overlay_order = []
        self._pressed_kc = {}
        self._dirty_spares = set()

    def _find_spare_keycodes(self):
        """Every keycode free to repurpose: all levels NoSymbol, or carrying a
        previous overlay bind — every level the SAME Unicode-plane keysym, a
        shape no real layout produces (the server echoes a two-sym bind back
        expanded across all levels). Overlay binds persist on the X server
        across a handler restart, so without reclaiming them each restart
        would shrink the pool until typing beyond the layout starves.
        Modifier-mapped keycodes are never spare: pressing one would toggle
        its modifier under the typed char. The full range is scanned (not a
        fixed cap): more slots make recycling — the only case where a slow
        app can mistranslate a rebound keycode — rare."""
        info = self._d.display.info
        lo, hi = info.min_keycode, info.max_keycode
        mapping = self._d.get_keyboard_mapping(lo, hi - lo + 1)
        try:
            mod_keycodes = {kc for row in self._d.get_modifier_mapping()
                            for kc in row if kc}
        except Exception:
            mod_keycodes = set()
        spares = []
        for i, syms in enumerate(mapping):
            kc = lo + i
            if kc in mod_keycodes:
                continue
            bound = {s for s in syms if s}
            if not bound:
                spares.append(kc)
            elif len(bound) == 1:
                sym = next(iter(bound))
                if (sym & 0xFF000000) == 0x01000000:
                    # Clients may still translate this keycode by its old
                    # value until they process the rebind's MappingNotify, so
                    # its first bind needs the same settle as a recycle.
                    spares.append(kc)
                    self._dirty_spares.add(kc)
        self._spare_set = frozenset(spares)
        return spares

    def _free_spares(self):
        if self._spare_keycodes is None:
            self._spare_keycodes = self._find_spare_keycodes()
        used = set(self._overlay.values())
        return [kc for kc in self._spare_keycodes if kc not in used]

    def _layout_keycode(self, keysym):
        """keysym_to_keycode, distrusting hits on spare-pool keycodes: the
        display's cached lookup can name a keycode whose bind belongs to a
        previous handler — or to a DIFFERENT keysym after this pool re-purposed
        it — so on a pool keycode only this shim's own live bind carrying
        exactly this value counts. Only keysym forms an overlay bind can carry
        (Latin-1 high half, Unicode plane) can hit the pool, so everything
        else skips the discovery."""
        kc = self._d.keysym_to_keycode(keysym)
        if not kc:
            return 0
        if (keysym & 0xFF000000) == 0x01000000 or 0xA0 <= keysym <= 0xFF:
            if self._spare_keycodes is None:
                self._spare_keycodes = self._find_spare_keycodes()
            if kc in self._spare_set:
                return self._overlay_value_kc.get(keysym, 0)
        return kc

    def _alloc_overlay_keycode(self, keysym):
        """Reserve a spare keycode for keysym (recycling the oldest binding when
        full) and record the binding. Returns (keycode, needs_settle) — True
        when clients may still hold a previous mapping for the keycode (an
        in-process recycle, or a reclaimed spare's first bind). The mapping
        request itself is the caller's (single vs batched)."""
        free = self._free_spares()
        if free:
            kc = free[0]
            needs_settle = kc in self._dirty_spares
            self._dirty_spares.discard(kc)
        else:
            oldest = self._overlay_order.pop(0)
            kc = self._overlay.pop(oldest)
            self._overlay_value_kc.pop(overlay_bind_keysym(oldest), None)
            needs_settle = True
        self._overlay[keysym] = kc
        self._overlay_value_kc[overlay_bind_keysym(keysym)] = kc
        self._overlay_order.append(keysym)
        return kc, needs_settle

    def _overlay_keycode(self, keysym):
        """Bind an unmapped keysym to a spare keycode (recycling the oldest) and
        return it, or None if no spare keycode exists."""
        if keysym in self._overlay:
            return self._overlay[keysym]
        if self._spare_keycodes is None:
            self._spare_keycodes = self._find_spare_keycodes()
        if not self._spare_keycodes:
            return None
        kc, needs_settle = self._alloc_overlay_keycode(keysym)
        # Assign the keysym at levels 0 and 1 so an accidental Shift can't change it.
        bind_value = overlay_bind_keysym(keysym)
        self._d.change_keyboard_mapping(kc, [[bind_value, bind_value]])
        self._d.sync()
        if needs_settle:
            time.sleep(self._RECYCLE_SETTLE_S)
        return kc

    def prebind(self, keysyms):
        """Overlay-bind every unmapped keysym in as few ChangeKeyboardMapping
        requests as possible — one per contiguous spare-keycode run, one sync —
        so a CJK composition commit broadcasts O(1) MappingNotify events instead
        of one per new char. Returns False (nothing bound) when the batch cannot
        fully resolve, so the caller can fall back without partial typing."""
        d = self._d
        missing = []
        for ks in dict.fromkeys(keysyms):
            if ks not in self._overlay and not self._layout_keycode(ks):
                missing.append(ks)
        if not missing:
            return True
        if self._spare_keycodes is None:
            self._spare_keycodes = self._find_spare_keycodes()
        # More new keysyms than slots would recycle bindings made earlier in this
        # very batch, corrupting the text; let the caller fall back instead.
        if len(missing) > len(self._spare_keycodes):
            return False
        # Allocate from the LONGEST contiguous free runs first: each contiguous
        # run binds with one ChangeKeyboardMapping, so this minimizes the
        # MappingNotify broadcasts a large commit produces.
        free = self._free_spares()
        runs = []
        i = 0
        while i < len(free):
            j = i
            while j + 1 < len(free) and free[j + 1] == free[j] + 1:
                j += 1
            runs.append(free[i:j + 1])
            i = j + 1
        runs.sort(key=len, reverse=True)
        picked = []
        for run in runs:
            if len(picked) >= len(missing):
                break
            picked.extend(run[:len(missing) - len(picked)])
        recycled_any = any(kc in self._dirty_spares for kc in picked)
        self._dirty_spares.difference_update(picked)
        while len(picked) < len(missing):
            oldest = self._overlay_order.pop(0)
            picked.append(self._overlay.pop(oldest))
            self._overlay_value_kc.pop(overlay_bind_keysym(oldest), None)
            recycled_any = True
        assigns = []
        for ks, kc in zip(missing, picked):
            self._overlay[ks] = kc
            self._overlay_value_kc[overlay_bind_keysym(ks)] = kc
            self._overlay_order.append(ks)
            assigns.append((kc, ks))
        assigns.sort()
        i = 0
        while i < len(assigns):
            j = i
            while j + 1 < len(assigns) and assigns[j + 1][0] == assigns[j][0] + 1:
                j += 1
            d.change_keyboard_mapping(
                assigns[i][0],
                [[overlay_bind_keysym(ks)] * 2 for _kc, ks in assigns[i:j + 1]])
            i = j + 1
        d.sync()
        if recycled_any:
            time.sleep(self._RECYCLE_SETTLE_S)
        return True

    def bindings_intact(self):
        """True when every overlay binding still resolves to its keysym in the
        server's map. Distinguishes our own MappingNotify from a foreign layout
        change by SEMANTICS: servers vary in how many notifies one
        ChangeKeyboardMapping emits and report the full keycode range, so
        neither counting nor range matching works — but a self-bind leaves the
        bindings intact and a foreign change wipes them."""
        if not self._overlay:
            return True
        try:
            for ks, kc in self._overlay.items():
                syms = self._d.get_keyboard_mapping(kc, 1)[0]
                if not len(syms) or syms[0] != overlay_bind_keysym(ks):
                    return False
            return True
        except Exception:
            return False

    def refresh_modifier_keycodes(self):
        """Re-resolve the synth-modifier keycodes from the (already refreshed)
        cache — a modifier remap moves them without touching the overlay."""
        d = self._d
        self._shift_kc = d.keysym_to_keycode(0xffe1)
        self._shift_r_kc = d.keysym_to_keycode(0xffe2)
        self._altgr_kc = (d.keysym_to_keycode(0xfe03)
                          or d.keysym_to_keycode(0xff7e))
        self._effective_mod_keycodes = self._read_effective_modifiers()

    def _read_effective_modifiers(self):
        """Keycodes the server actually treats as modifiers.

        Holding a key only selects a shifted level when that keycode is bound in
        the modifier map. A keymap can carry the Shift keysym without binding it
        (a bare Xvfb with no keymap is the common case), and injecting Shift there
        types the level-0 glyph instead: every capital arrives lowercase.
        """
        try:
            return {kc for row in self._d.get_modifier_mapping() for kc in row if kc}
        except Exception as e:
            logger_webrtc_input.debug(f"modifier map unreadable ({e}); assuming it binds what it names")
            return None

    def invalidate_mapping(self):
        """A foreign keymap change (setxkbmap, desktop layout switcher) wiped
        our overlay bindings and may have moved modifier keycodes: drop the
        overlay bookkeeping, rediscover spares lazily and re-resolve the
        modifier keycodes. Held keys are kept: release replays the exact
        press-time keycode."""
        self._overlay.clear()
        self._overlay_value_kc.clear()
        self._overlay_order.clear()
        self._spare_keycodes = None
        self._spare_set = frozenset()
        self._dirty_spares.clear()
        self.refresh_modifier_keycodes()

    def _resolve(self, keysym):
        """Return (keycode, modifier_keycodes) to inject this keysym. The modifiers are
        the Shift / AltGr keycodes whose held state selects the keymap level the keysym
        sits at, so a glyph bound above the Shift level (e.g. AltGr '@') types correctly
        instead of falling through to its level-0 glyph."""
        d = self._d
        kc = self._layout_keycode(keysym)
        if not kc:
            # Not in the layout: map it to a spare keycode in-process (no xdotool
            # fork). Overlay keysyms sit at level 0, so they never need modifiers.
            kc = self._overlay_keycode(keysym)
            if not kc:
                # No spare keycode: raise so the caller falls back to xdotool.
                raise ValueError("no keycode for keysym %r" % (keysym,))
            return kc, ()
        # Lowest column carrying this glyph: 0 base, 1 Shift, 2 AltGr, 3 Shift+AltGr.
        level = next((lvl for lvl in range(4)
                      if d.keycode_to_keysym(kc, lvl) == keysym), 0)
        mods = []
        if level & 1 and self._shift_kc:
            mods.append(self._shift_kc)
        if level & 2 and self._altgr_kc:
            mods.append(self._altgr_kc)
        if mods and not self._modifiers_engage(mods):
            # The level this glyph sits at is unreachable on this keymap, so bind
            # the keysym itself to a spare keycode at level 0 and type that. The
            # glyph then carries its own case instead of depending on a modifier
            # the server will not act on.
            overlay_kc = self._overlay_keycode(keysym)
            if overlay_kc:
                return overlay_kc, ()
        return kc, tuple(mods)

    def _modifiers_engage(self, mods):
        """Whether holding these keycodes actually selects a shifted level."""
        effective = getattr(self, "_effective_mod_keycodes", None)
        if effective is None:
            return True
        return all(kc in effective for kc in mods)

    def _down_mod_keycodes(self, held_keysyms):
        """Shift/AltGr keycodes currently down: the client-held keysyms the
        handler tracks, plus this shim's own synthesized holds. Tracked state
        only — the old per-press query_keymap round trip is gone."""
        down = set()
        for mods in self._synth_mods.values():
            down.update(mods)
        for ks in held_keysyms:
            if ks == 0xFFE1:
                down.add(self._shift_kc)
            elif ks == 0xFFE2:
                down.add(self._shift_r_kc)
            elif ks in (0xFE03, 0xFF7E):
                down.add(self._altgr_kc)
        down.discard(0)
        return down

    def _mods_to_lift(self, required, down):
        """Down Shift/AltGr keycodes the target level does not want. A required
        Shift is satisfied by either side, so neither is lifted then."""
        lift = []
        if self._shift_kc not in required:
            lift.extend(kc for kc in (self._shift_kc, self._shift_r_kc)
                        if kc in down)
        if self._altgr_kc and self._altgr_kc not in required and self._altgr_kc in down:
            lift.append(self._altgr_kc)
        return lift

    def press(self, keysym, neutralize=False, held_keysyms=()):
        kc, mods = self._resolve(keysym)
        down = self._down_mod_keycodes(held_keysyms)
        # A held Shift/AltGr the level does not want selects a different glyph
        # (and pushes an overlay bind onto its empty AltGr levels): lift it for
        # the press, restore it after. Chords pass neutralize=False so
        # Ctrl+Shift+X keeps its held modifiers.
        lifted = self._mods_to_lift(set(mods), down) if neutralize else []
        for m in lifted:
            xtest.fake_input(self._d, Xlib.X.KeyRelease, m)
        # Synthesize only modifiers not already down (a required Shift held on
        # either side counts); release only those on release().
        synth = [m for m in mods
                 if m not in down
                 and not (m == self._shift_kc and self._shift_r_kc in down)]
        for m in synth:
            xtest.fake_input(self._d, Xlib.X.KeyPress, m)
        if synth:
            self._synth_mods[keysym] = synth
        xtest.fake_input(self._d, Xlib.X.KeyPress, kc)
        # Replay this exact keycode on release.
        self._pressed_kc[keysym] = kc
        for m in reversed(lifted):
            xtest.fake_input(self._d, Xlib.X.KeyPress, m)
        self._d.flush()

    def release(self, keysym):
        # Replay the press-time keycode; only re-resolve if the press wasn't tracked
        # (the layout may have changed mid-keystroke, orphaning a re-resolve).
        kc = self._pressed_kc.pop(keysym, None)
        if kc is None:
            kc, _ = self._resolve(keysym)
        xtest.fake_input(self._d, Xlib.X.KeyRelease, kc)
        for m in reversed(self._synth_mods.pop(keysym, ())):
            xtest.fake_input(self._d, Xlib.X.KeyRelease, m)
        self._d.flush()


class _XTestMouse:
    """Mouse controller backed by the bundled python-xlib XTEST extension."""

    def __init__(self, xdisplay):
        self._d = xdisplay

    @property
    def position(self):
        p = self._d.screen().root.query_pointer()
        return (p.root_x, p.root_y)

    @position.setter
    def position(self, xy):
        x, y = xy
        xtest.fake_input(self._d, Xlib.X.MotionNotify, detail=False,
                         root=Xlib.X.NONE, x=int(x), y=int(y))
        self._d.flush()

    def scroll(self, dx, dy):
        d = self._d
        # X core pointer scroll buttons: 4=up, 5=down, 6=left, 7=right. The sign
        # convention is the callers': positive dy scrolls up, positive dx right.
        def _clicks(btn, n):
            for _ in range(int(abs(n))):
                xtest.fake_input(d, Xlib.X.ButtonPress, btn)
                xtest.fake_input(d, Xlib.X.ButtonRelease, btn)
        if dy:
            _clicks(4 if dy > 0 else 5, dy)
        if dx:
            _clicks(7 if dx > 0 else 6, dx)
        d.flush()

    def press(self, button):
        xtest.fake_input(self._d, Xlib.X.ButtonPress, int(button))
        self._d.flush()

    def release(self, button):
        xtest.fake_input(self._d, Xlib.X.ButtonRelease, int(button))
        self._d.flush()


logger_webrtc_input = logging.getLogger("webrtc_input")
logger_selkies_gamepad = logging.getLogger("selkies_gamepad")

# Upper bound on a single multi-part clipboard transfer (bytes). The declared
# size and the accumulated chunks are both checked against this so a client
# cannot grow the in-memory buffer without bound (memory-exhaustion DoS).
MULTIPART_CLIPBOARD_MAX_SIZE = 64 * 1024 * 1024

# Deadline (seconds) bounding a wait for an X reply on the input connection.
# Generous: no healthy round trip approaches it, so it fires only on a genuinely
# unresponsive server, converting an unbounded event-loop freeze into a bounded
# stall plus reconnect.
INPUT_X_REPLY_TIMEOUT_S = 20.0

# Poll interval (seconds) for the X event consumers when no loop reader is armed
# on the input connection, so cursor and keymap changes still land promptly.
INPUT_X_EVENT_POLL_S = 0.02


def _is_within_directory(directory: str, target: str) -> bool:
    """Return True if `target` is `directory` itself or strictly inside it.

    Compares on path-segment boundaries via os.path.commonpath rather than a
    bare string prefix (which would accept sibling dirs sharing a name prefix).
    Both paths should already be absolute/realpath-resolved by the caller.
    """
    directory = os.path.abspath(directory)
    target = os.path.abspath(target)
    try:
        return os.path.commonpath([directory, target]) == directory
    except ValueError:
        # Raised for paths on different drives or a mix of absolute/relative.
        return False

# EVDEV Event Codes (from linux/input-event-codes.h)
EV_SYN = 0x00
EV_KEY = 0x01
EV_REL = 0x02
EV_ABS = 0x03
EV_MSC = 0x04
SYN_REPORT = 0

# Mouse Button Codes (from linux/input-event-codes.h)
BTN_MOUSE = 0x110
BTN_LEFT = 0x110
BTN_RIGHT = 0x111
BTN_MIDDLE = 0x112
BTN_SIDE = 0x113
BTN_EXTRA = 0x114

# Gamepad Button Codes
# BTN_A/BTN_B/BTN_X/BTN_Y are also known as BTN_SOUTH/BTN_EAST/BTN_NORTH/BTN_WEST.
# BTN_C and BTN_Z are typically named that way in evdev and are kept here for
# matching the XBox360 bitmask.
BTN_A = 0x130
BTN_B = 0x131
BTN_C = 0x132
BTN_X = 0x133
BTN_Y = 0x134
BTN_Z = 0x135
# Left and right bumpers.
BTN_TL = 0x136
BTN_TR = 0x137
# Back, Start and Xbox/Guide buttons.
BTN_SELECT = 0x13a
BTN_START = 0x13b
BTN_MODE = 0x13c
# Left and right thumbstick clicks.
BTN_THUMBL = 0x13d
BTN_THUMBR = 0x13e


# Absolute Axis Codes
ABS_X = 0x00
ABS_Y = 0x01
# Often Left Trigger.
ABS_Z = 0x02
ABS_RX = 0x03
ABS_RY = 0x04
# Often Right Trigger.
ABS_RZ = 0x05
ABS_HAT0X = 0x10
ABS_HAT0Y = 0x11

# JS Event types (from linux/joystick.h, used by the JS-like interface)
JS_EVENT_BUTTON = 0x01
JS_EVENT_AXIS = 0x02
JS_EVENT_INIT = 0x80

# For js_config_t struct packing for the C interposer
# These are the max sizes in the C struct js_config_t
INTERPOSER_MAX_BTNS = 512
INTERPOSER_MAX_AXES = 64
CONTROLLER_NAME_MAX_LEN = 255 
C_INTERPOSER_STRUCT_SIZE = 1360

# Raw bytes per multipart message: fill the shared WebSocket frame ceiling, with
# margin for the verb prefix and base64 expansion (limit/4*3 of the payload budget).
CLIPBOARD_CHUNK_SIZE = ((WS_MAX_MESSAGE_BYTES - 4096) * 3) // 4 

# For mouse input to send fake back and forward events
KEYSYM_ALT_L = 0xFFE9
KEYSYM_LEFT_ARROW = 0xFF51
KEYSYM_RIGHT_ARROW = 0xFF53

# Import keysyms
try:
    from .server_keysym_map import X11_KEYSYM_MAP
except ImportError:
    logger_webrtc_input = logging.getLogger("webrtc_input_fallback_map_import")
    logger_webrtc_input.warning(
        "server_keysym_map.py not found or X11_KEYSYM_MAP not defined. "
        "Keysym mapping will rely entirely on fallback."
    )
    X11_KEYSYM_MAP = {}

# Cyrillic (ЙЦУКЕН) keysyms mapped to the QWERTY keysym sitting at the same
# physical key, row by row:
#   Й Ц У К Е Н Г Ш Щ З -> q w e r t y u i o p
#   Ф Ы В А П Р О Л Д -> a s d f g h j k l
#   Я Ч С М И Т Ь -> z x c v b n m
CYRILLIC_TO_QWERTY_KEYSYM = {
    0x06CA: 0x0071,
    0x06C3: 0x0077,
    0x06D5: 0x0065,
    0x06CB: 0x0072,
    0x06C5: 0x0074,
    0x06CE: 0x0079,
    0x06C7: 0x0075,
    0x06DB: 0x0069,
    0x06DD: 0x006F,
    0x06DA: 0x0070,
    0x06C6: 0x0061,
    0x06D9: 0x0073,
    0x06D7: 0x0064,
    0x06C1: 0x0066,
    0x06D0: 0x0067,
    0x06D2: 0x0068,
    0x06CF: 0x006A,
    0x06CC: 0x006B,
    0x06C4: 0x006C,
    0x06D1: 0x007A,
    0x06DE: 0x0078,
    0x06D3: 0x0063,
    0x06CD: 0x0076,
    0x06C9: 0x0062,
    0x06D4: 0x006E,
    0x06D8: 0x006D,
}


@functools.lru_cache(maxsize=4096)
def keysym_to_character(keysym):
    """The printable character a keysym types, or None for keysyms that are not
    plain text (modifiers, navigation, anything decoding to a control code).
    Latin-1 and Unicode-plane keysyms decode directly; the legacy planes
    (Cyrillic, Arabic, Hebrew, Greek, Thai, ...) resolve through libxkbcommon,
    with python-Xlib's table as the fallback. Cached: a session types the same
    keysyms over and over, and each miss costs a ctypes round trip."""
    char = None
    if (keysym & 0xFF000000) == 0x01000000:
        codepoint = keysym & 0x00FFFFFF
        if 0 <= codepoint <= 0x10FFFF:
            try:
                char = chr(codepoint)
            except ValueError:
                return None
    elif 0x20 <= keysym <= 0xFF:
        char = chr(keysym)
    elif keysym == 0x20AC:
        char = '€'
    else:
        if libxkb is not None:
            try:
                buf = ctypes.create_string_buffer(8)
                if libxkb.xkb_keysym_to_utf8(keysym, buf, 8) > 0:
                    char = buf.value.decode('utf-8')
            except Exception:
                char = None
        if not char and XK is not None:
            try:
                name = XK.keysym_to_string(keysym)
                if name and len(name) == 1:
                    char = name
            except Exception:
                char = None
    if char and (ord(char[0]) < 0x20 or 0x7F <= ord(char[0]) <= 0x9F):
        return None
    return char or None


@functools.lru_cache(maxsize=4096)
def character_to_layout_keysym(char):
    """The canonical keysym for a character (the one a physical keyboard layout
    binds: Cyrillic_ef for ф, not its Unicode-plane alias), so text typed onto a
    seat whose layout carries the script lands on real layout keys instead of
    overlay binds. Falls back to the Latin-1/Unicode-plane encoding."""
    codepoint = ord(char)
    if libxkb is not None:
        try:
            keysym = libxkb.xkb_utf32_to_keysym(codepoint)
            if keysym:
                return keysym
        except Exception:
            pass
    return codepoint if 0x20 <= codepoint <= 0xFF else (0x01000000 | codepoint)


@functools.lru_cache(maxsize=4096)
def overlay_bind_keysym(keysym):
    """The keysym VALUE an overlay slot carries for `keysym`. An overlay bind is
    a key we invent, not one a layout author chose, and the receiving toolkits'
    tables for legacy national/publishing keysyms disagree across versions
    (permille, signifblank and the angle brackets die or mistranslate on a
    legacy bind) — while Latin-1 and Unicode-plane keysyms translate
    algorithmically everywhere. So any keysym that spells one character is
    bound in that universal form; charless keysyms (XF86, F-keys) keep their
    semantic value."""
    if (keysym & 0xFF000000) == 0x01000000 or 0x20 <= keysym <= 0xFF:
        return keysym
    char = keysym_to_character(keysym)
    if char is not None and len(char) == 1:
        return 0x01000000 | ord(char)
    return keysym


def text_to_wayland_keysyms(text):
    """One keysym per typeable char for the virtual-keyboard typer, in the same
    universal Latin-1/Unicode-plane forms overlay binds carry. This is the
    policy half of vk typing — pixelflux's type_keysyms_wayland taps whatever
    it is given — so which keysym spells a character is decided (and tweaked)
    here, never in the transport."""
    out = []
    for char in text:
        if char in ('\n', '\r'):
            out.append(0xFF0D)
        elif char == '\t':
            out.append(0xFF09)
        else:
            codepoint = ord(char)
            if 0x20 <= codepoint <= 0xFF:
                out.append(codepoint)
            elif codepoint >= 0x100:
                out.append(0x01000000 | codepoint)
    return out


class JsConfigCtypes(ctypes.Structure):
    _fields_ = [
        ("name", ctypes.c_char * CONTROLLER_NAME_MAX_LEN),
        ("vendor", ctypes.c_uint16),
        ("product", ctypes.c_uint16),
        ("version", ctypes.c_uint16),
        ("num_btns", ctypes.c_uint16),
        ("num_axes", ctypes.c_uint16),
        ("btn_map", ctypes.c_uint16 * INTERPOSER_MAX_BTNS),
        ("axes_map", ctypes.c_uint8 * INTERPOSER_MAX_AXES),
        ("final_alignment_padding", ctypes.c_uint8 * 6)
    ]

# Get the size of the C-compatible struct
EXPECTED_C_STRUCT_SIZE = ctypes.sizeof(JsConfigCtypes)
logging.info(f"Expected C js_config_t size (from ctypes): {EXPECTED_C_STRUCT_SIZE} bytes")


ABS_MIN_VAL = -32767
ABS_MAX_VAL = 32767
# EVDEV triggers are often 0-255 or 0-1023; the maximum may also be ABS_MAX_VAL
# depending on what the driver expects.
ABS_TRIGGER_MIN_VAL = 0
ABS_TRIGGER_MAX_VAL = 255
ABS_HAT_MIN_VAL = -1
ABS_HAT_MAX_VAL = 1

STANDARD_XPAD_CONFIG = {
    "name": "Microsoft X-Box 360 pad",
    "vendor_id": 0x045e,
    "product_id": 0x028e,
    "version": 0x0114,

    # EVDEV codes. The order here defines our internal abstract button indices:
    # 0 A, 1 B, 2 X, 3 Y, 4 Left Bumper, 5 Right Bumper, 6 Back, 7 Start,
    # 8 Xbox Guide, 9 Left Stick Click, 10 Right Stick Click.
    "btn_map": [
        BTN_A,
        BTN_B,
        BTN_X,
        BTN_Y,
        BTN_TL,
        BTN_TR,
        BTN_SELECT,
        BTN_START,
        BTN_MODE,
        BTN_THUMBL,
        BTN_THUMBR,
    ],

    # EVDEV codes for axes. The order defines internal abstract axis indices:
    # 0 Left Stick X, 1 Left Stick Y, 2 Left Trigger, 3 Right Stick X,
    # 4 Right Stick Y, 5 Right Trigger, 6 D-Pad X, 7 D-Pad Y.
    "axes_map": [
        ABS_X,
        ABS_Y,
        ABS_Z,
        ABS_RX,
        ABS_RY,
        ABS_RZ,
        ABS_HAT0X,
        ABS_HAT0Y
    ],

    "mapping": {
        # Maps client button numbers to our internal abstract button *indices*
        # (client_btn_idx -> internal_abstract_btn_idx). Client A, B, X, Y, LB and
        # RB are 0-5; Select/Back is 8, Start 9, Left Stick Press 10, Right Stick
        # Press 11 and Xbox/Home 16.
        "btns": {
            0: 0,
            1: 1,
            2: 2,
            3: 3,
            4: 4,
            5: 5,
            8: 6,
            9: 7,
            10: 9,
            11: 10,
            16: 8,
        },
        # client_axis_idx -> internal_abstract_axis_idx. Client Left Stick X and Y
        # are 0 and 1; Right Stick X and Y are 2 and 3.
        "axes": {
            0: 0,
            1: 1,
            2: 3,
            3: 4,
        },
        # Client buttons that map to an internal abstract axis: client button 6 is
        # LT (internal axis 2, ABS_Z) and 7 is RT (internal axis 5, ABS_RZ).
        "client_btns_to_internal_axes": {
            6: 2,
            7: 5,
        },
        # Client DPad buttons map to internal abstract HAT axes
        "dpad_to_hat": {
            # client_btn_idx -> (internal_abstract_axis_idx_for_HAT, hat_direction_value)
            # Client buttons 12-15 are Up, Down, Left and Right.
            12: (7, -1),
            13: (7, 1),
            14: (6, -1),
            15: (6, 1),
        },
        "trigger_internal_abstract_axis_indices": [2, 5],
        "hat_internal_abstract_axis_indices": [6, 7],
    }
}

# --- Event Packing Functions ---
def get_js_event_packed(ev_type, number, value):
    """Packs a js_event struct."""
    # struct js_event { __u32 time; __s16 value; __u8 type; __u8 number; };
    # `type` is __u8, so pack it as 'B' — 'b' (signed) raises struct.error the
    # moment the 0x80 JS_EVENT_INIT flag is OR'd into the type (value >= 128).
    # Mask so the millisecond timestamp fits in u32.
    ts_ms = int(time.time() * 1000) & 0xFFFFFFFF
    return struct.pack("=IhBB", ts_ms, int(value), ev_type, number)

def get_evdev_events_packed(ev_type, ev_code, ev_value, client_arch_bits):
    """Packs an input_event struct and a SYN_REPORT, using client architecture for timeval."""
    # struct input_event { struct timeval time; __u16 type; __u16 code; __s32 value; };
    # struct timeval { time_t tv_sec; suseconds_t tv_usec; };
    # time_t and suseconds_t are 'long' on 32-bit, 'long long' (usually) on 64-bit for tv_sec,
    # and 'long' for tv_usec. The C interposer sends sizeof(unsigned long).
    
    now = time.time()
    ts_sec = int(now)
    ts_usec = int((now - ts_sec) * 1_000_000)

    # Assume 'long' is 8 bytes for timeval members on a 64-bit client, so tv_sec and
    # tv_usec are long long, and 4 bytes (plain long) on a 32-bit client.
    if client_arch_bits == 64:
        timeval_fmt = "qq"
    else:
        timeval_fmt = "ll"
    
    # Native byte order, timeval, type, code, value.
    event_fmt = f"={timeval_fmt}HHi"

    event_data = struct.pack(event_fmt, ts_sec, ts_usec, ev_type, ev_code, int(ev_value))
    syn_event_data = struct.pack(event_fmt, ts_sec, ts_usec, EV_SYN, SYN_REPORT, 0)
    return event_data + syn_event_data

def normalize_axis_value(client_value, is_trigger, is_hat, for_js_event=False):
    """
    Normalizes client axis value.
    If for_js_event is True and is_hat is True, it scales to the full axis range.
    """
    if is_hat:
        hat_val = int(max(ABS_HAT_MIN_VAL, min(ABS_HAT_MAX_VAL, round(client_value))))
        if for_js_event:
            # For JS, D-pad axes need to be full range, not -1/0/1
            return hat_val * ABS_MAX_VAL
        else:
            # For EVDEV, HAT values are -1, 0, or 1
            return hat_val
    # The client sends 0.0 to 1.0 for triggers.
    if is_trigger:
        # For JS and EVDEV, triggers are often treated as regular axes.
        # Map 0..1 to -32k..+32k for consistency, some drivers map to 0..255.
        # This mapping ensures it works like an analog input.
        return int(ABS_MIN_VAL + client_value * (ABS_MAX_VAL - ABS_MIN_VAL))
    # Regular axis: client sends -1.0 to 1.0
    return int(ABS_MIN_VAL + ((client_value + 1) / 2) * (ABS_MAX_VAL - ABS_MIN_VAL))


class GamepadMapper:
    def __init__(self, config_template, client_input_name, client_num_btns, client_num_axes):
        self.config = config_template
        self.client_input_name = client_input_name

    def get_mapped_events(self, client_event_idx, client_value, is_button_event):
        internal_abstract_idx = -1
        is_trigger_axis = False
        is_hat_axis = False
        target_evdev_type = None
        # final_value ends up as the raw value from the client or the dpad direction.
        final_value = 0

        if is_button_event:
            if client_event_idx in self.config["mapping"]["dpad_to_hat"]:
                internal_abstract_idx, hat_direction_value = self.config["mapping"]["dpad_to_hat"][client_event_idx]
                is_hat_axis = True
                target_evdev_type = EV_ABS
                final_value = hat_direction_value * int(client_value)
            elif client_event_idx in self.config["mapping"]["client_btns_to_internal_axes"]:
                internal_abstract_idx = self.config["mapping"]["client_btns_to_internal_axes"][client_event_idx]
                is_trigger_axis = internal_abstract_idx in self.config["mapping"]["trigger_internal_abstract_axis_indices"]
                target_evdev_type = EV_ABS
                final_value = client_value
            else:
                internal_abstract_idx = self.config["mapping"]["btns"].get(client_event_idx)
                target_evdev_type = EV_KEY
                final_value = int(client_value)
        # Axis event.
        else:
            internal_abstract_idx = self.config["mapping"]["axes"].get(client_event_idx)
            is_trigger_axis = internal_abstract_idx in self.config["mapping"]["trigger_internal_abstract_axis_indices"]
            is_hat_axis = internal_abstract_idx in self.config["mapping"]["hat_internal_abstract_axis_indices"]
            target_evdev_type = EV_ABS
            final_value = client_value

        if internal_abstract_idx is None or internal_abstract_idx < 0:
            return None

        # 2. Get EVDEV code and normalized values for both JS and EVDEV
        evdev_code = -1
        js_event_value = 0
        evdev_event_value = 0

        if target_evdev_type == EV_KEY:
            if 0 <= internal_abstract_idx < len(self.config["btn_map"]):
                evdev_code = self.config["btn_map"][internal_abstract_idx]
                # Button values are 0 or 1.
                js_event_value = evdev_event_value = final_value
            else: return None
        elif target_evdev_type == EV_ABS:
            if 0 <= internal_abstract_idx < len(self.config["axes_map"]):
                evdev_code = self.config["axes_map"][internal_abstract_idx]
                # Calculate values separately for JS and EVDEV
                js_event_value = normalize_axis_value(final_value, is_trigger_axis, is_hat_axis, for_js_event=True)
                evdev_event_value = normalize_axis_value(final_value, is_trigger_axis, is_hat_axis, for_js_event=False)
            else: return None
        else:
            return None

        # 3. Create event data/templates
        if evdev_code != -1:
            js_event_type = JS_EVENT_BUTTON if target_evdev_type == EV_KEY else JS_EVENT_AXIS
            js_event_data = get_js_event_packed(js_event_type, internal_abstract_idx, js_event_value)
            
            evdev_event_template = (target_evdev_type, evdev_code, evdev_event_value)
            
            return {'js_event_data': js_event_data, 'evdev_event_template': evdev_event_template}
        
        return None

UINPUT_PATH = "/dev/uinput"
UINPUT_SYSFS_BASE = "/sys/devices/virtual/input"
UINPUT_MAX_NAME_SIZE = 80
BUS_USB = 0x03

# asm-generic ioctl encoding, which is what every architecture Selkies builds for
# (x86_64, aarch64) uses. The exotic layouts (alpha, mips, ppc, sparc) differ.
_IOC_WRITE = 1
_IOC_READ = 2
_IOC_TYPESHIFT = 8
_IOC_SIZESHIFT = 16
_IOC_DIRSHIFT = 30


def _uinput_ioc(direction, number, size):
    return ((direction << _IOC_DIRSHIFT) | (ord("U") << _IOC_TYPESHIFT) |
            number | (size << _IOC_SIZESHIFT))


# struct uinput_setup { struct input_id id; char name[80]; __u32 ff_effects_max; }
UINPUT_SETUP_FMT = "=HHHH80sI"
# struct uinput_abs_setup { __u16 code; struct input_absinfo absinfo; }
UINPUT_ABS_SETUP_FMT = "=H2x6i"
UINPUT_SYSNAME_LEN = 64

UI_DEV_CREATE = _uinput_ioc(0, 1, 0)
UI_DEV_DESTROY = _uinput_ioc(0, 2, 0)
UI_DEV_SETUP = _uinput_ioc(_IOC_WRITE, 3, struct.calcsize(UINPUT_SETUP_FMT))
UI_ABS_SETUP = _uinput_ioc(_IOC_WRITE, 4, struct.calcsize(UINPUT_ABS_SETUP_FMT))
UI_SET_EVBIT = _uinput_ioc(_IOC_WRITE, 100, 4)
UI_SET_KEYBIT = _uinput_ioc(_IOC_WRITE, 101, 4)
UI_SET_ABSBIT = _uinput_ioc(_IOC_WRITE, 103, 4)
UI_GET_SYSNAME = _uinput_ioc(_IOC_READ, 44, UINPUT_SYSNAME_LEN)

# (minimum, maximum, fuzz, flat, resolution) per axis, matching what the
# interposer answers EVIOCGABS with so an application cannot tell the two
# backends apart.
UINPUT_ABS_INFO_DEFAULT = (ABS_MIN_VAL, ABS_MAX_VAL, 16, 128, 1)
UINPUT_ABS_INFO = {
    ABS_HAT0X: (ABS_HAT_MIN_VAL, ABS_HAT_MAX_VAL, 0, 0, 0),
    ABS_HAT0Y: (ABS_HAT_MIN_VAL, ABS_HAT_MAX_VAL, 0, 0, 0),
}

LOCAL_ARCH_BITS = 64 if struct.calcsize("P") == 8 else 32


def uinput_writable():
    """Whether this process can create kernel input devices."""
    try:
        fd = os.open(UINPUT_PATH, os.O_WRONLY | os.O_NONBLOCK)
    except OSError:
        return False
    os.close(fd)
    return True


def interposer_configured():
    """Whether this session preloads the Joystick Interposer into applications,
    which already delivers gamepad events without any kernel device."""
    if os.environ.get("SELKIES_INTERPOSER"):
        return True
    return "selkies_joystick_interposer" in os.environ.get("LD_PRELOAD", "")


def uinput_gamepads_enabled(mode):
    """Resolve the uinput_gamepad setting to a decision, logging why.

    'auto' makes kernel gamepads the fallback for hosts that do not preload the
    interposer: it stays off wherever the interposer is set up, so no
    application ever sees the same pad through both backends at once.
    """
    mode = str(mode or "auto").strip().lower()
    if mode in ("false", "0", "no", "off"):
        return False
    forced = mode in ("true", "1", "yes", "on")
    if not forced and mode != "auto":
        logger_selkies_gamepad.warning(f"Unrecognized uinput_gamepad value '{mode}'; using 'auto'.")
    if not forced and interposer_configured():
        logger_selkies_gamepad.info(
            "Joystick Interposer is configured for this session; kernel gamepads stay off."
        )
        return False
    if not uinput_writable():
        log = logger_selkies_gamepad.error if forced else logger_selkies_gamepad.info
        log(
            f"{UINPUT_PATH} is missing or not writable, so gamepads reach applications only "
            "through the Joystick Interposer. Load the uinput module and grant this user "
            "write access to enable kernel gamepads."
        )
        return False
    return True


class UInputGamepad:
    """One slot's kernel gamepad, created through /dev/uinput.

    Applications discover it as an ordinary controller, so neither the Joystick
    Interposer nor fake-udev is involved. It carries the evdev event stream the
    interposer socket carries, presented as the same Xbox pad.
    """

    def __init__(self, label):
        self.label = label
        self.fd = None
        self.device_nodes = []

    def create(self):
        fd = os.open(UINPUT_PATH, os.O_WRONLY | os.O_NONBLOCK)
        try:
            fcntl.ioctl(fd, UI_SET_EVBIT, EV_KEY)
            fcntl.ioctl(fd, UI_SET_EVBIT, EV_ABS)
            for code in STANDARD_XPAD_CONFIG["btn_map"]:
                fcntl.ioctl(fd, UI_SET_KEYBIT, code)
            for code in STANDARD_XPAD_CONFIG["axes_map"]:
                fcntl.ioctl(fd, UI_SET_ABSBIT, code)
                minimum, maximum, fuzz, flat, resolution = UINPUT_ABS_INFO.get(
                    code, UINPUT_ABS_INFO_DEFAULT
                )
                fcntl.ioctl(fd, UI_ABS_SETUP, struct.pack(
                    UINPUT_ABS_SETUP_FMT, code, 0, minimum, maximum, fuzz, flat, resolution
                ))
            fcntl.ioctl(fd, UI_DEV_SETUP, struct.pack(
                UINPUT_SETUP_FMT,
                BUS_USB,
                STANDARD_XPAD_CONFIG["vendor_id"],
                STANDARD_XPAD_CONFIG["product_id"],
                STANDARD_XPAD_CONFIG["version"],
                STANDARD_XPAD_CONFIG["name"].encode("utf-8")[:UINPUT_MAX_NAME_SIZE - 1],
                0,
            ))
            fcntl.ioctl(fd, UI_DEV_CREATE)
        except OSError:
            os.close(fd)
            raise
        self.fd = fd
        self.device_nodes = self._resolve_device_nodes()
        return self.device_nodes

    def _resolve_device_nodes(self):
        """The /dev/input nodes the kernel registered for this device: event*
        always, js* as well when joydev is loaded."""
        buffer = bytearray(UINPUT_SYSNAME_LEN)
        try:
            fcntl.ioctl(self.fd, UI_GET_SYSNAME, buffer, True)
        except OSError:
            return []
        sysname = bytes(buffer).split(b"\0", 1)[0].decode("utf-8", "replace")
        if not sysname:
            return []
        sysdir = os.path.join(UINPUT_SYSFS_BASE, sysname)
        try:
            entries = os.listdir(sysdir)
        except OSError:
            return []
        return sorted(
            os.path.join("/dev/input", entry)
            for entry in entries
            if entry.startswith(("event", "js"))
        )

    def emit(self, ev_type, ev_code, ev_value):
        os.write(self.fd, get_evdev_events_packed(ev_type, ev_code, ev_value, LOCAL_ARCH_BITS))

    def destroy(self):
        if self.fd is None:
            return
        try:
            fcntl.ioctl(self.fd, UI_DEV_DESTROY)
        except OSError as e:
            logger_selkies_gamepad.warning(f"Gamepad {self.label}: could not destroy the kernel device: {e}")
        try:
            os.close(self.fd)
        except OSError:
            pass
        self.fd = None
        self.device_nodes = []


# Process-wide virtual gamepad instances, keyed by slot index. Apps open the
# interposer sockets ONCE at their own startup (the .so presents them as
# /dev/input devices), so the instances — and the bound sockets — must outlive
# every per-service input handler: a transport mode switch (websockets <->
# webrtc) tears one service down and starts the other, and closing/rebinding
# the sockets there would leave every running app holding a dead fd until the
# app itself restarts. Process exit reclaims the fds; the next server start
# unlinks stale socket files before binding.
_persistent_gamepads = {}


class SelkiesGamepad:
    def __init__(self, js_interposer_socket_path, evdev_interposer_socket_path, loop=None,
                 uinput_enabled=False):
        self.js_sock_path = js_interposer_socket_path
        self.evdev_sock_path = evdev_interposer_socket_path
        self.loop = loop or asyncio.get_running_loop()

        # Kernel device for this slot, created on first use so an unused slot is
        # not a phantom controller in every application.
        self.uinput_enabled = uinput_enabled
        self.uinput = None
        
        # Both are populated by set_config: the button/axis mapper for this pad
        # and the cached js_config_t payload handed to interposer clients.
        self.mapper = None
        self.config_payload_cache = None

        self.js_server = None
        self.evdev_server = None
        # Both client maps are {writer: {'arch_bits': bits}}.
        self.js_clients = {}
        self.evdev_clients = {}
        
        # Bounded so a single stalled gamepad client (slow writer.drain) can't let
        # this queue grow without limit and wedge event delivery for every client.
        # On overflow we drop the OLDEST event (see send_event) — for a gamepad the
        # freshest axis/button state matters, stale samples are worthless.
        self.events_queue = asyncio.Queue(maxsize=4096)
        self.running = False
        self._event_processor_task = None

        # Client controls (is_button, index) currently driven non-neutral, so a
        # lost association can release exactly what is held (see reset_state).
        self._held_controls = set()
        # Last queued js value per internal control (ev_type, number) — the
        # source for init_state_burst. Updated at queue time, so the snapshot
        # stays truthful even for events the bounded queue drops.
        self._js_state = {}

    def set_config(self, client_input_name, client_num_btns, client_num_axes):
        self.mapper = GamepadMapper(STANDARD_XPAD_CONFIG, client_input_name, client_num_btns, client_num_axes)
        
        js_idx = 0 
        match = re.search(r"selkies_js(\d+)\.sock$", self.js_sock_path)
        if match:
            js_idx = int(match.group(1))
        else:
            logger_selkies_gamepad.warning(
                f"Failed to parse js_index from {self.js_sock_path}, "
                f"defaulting to 0 for payload name generation if needed."
            )

        payload_controller_config = {
            "name": STANDARD_XPAD_CONFIG.get("name", f"Selkies Virtual JS{js_idx}"),
            "vendor_id": STANDARD_XPAD_CONFIG.get("vendor_id", 0x0000),
            "product_id": STANDARD_XPAD_CONFIG.get("product_id", 0x0000),
            "version": STANDARD_XPAD_CONFIG.get("version", 0x0114),
            "buttons": STANDARD_XPAD_CONFIG.get("btn_map", []), 
            "axes": STANDARD_XPAD_CONFIG.get("axes_map", [])
        }
        
        self.config_payload_cache = self._make_interposer_config_payload(js_idx, payload_controller_config)
        
        logger_selkies_gamepad.info(
            f"Gamepad configured. JS socket: {self.js_sock_path}, EVDEV socket: {self.evdev_sock_path}. "
            f"Using fixed config: {STANDARD_XPAD_CONFIG['name']}"
        )

    def ensure_uinput(self):
        """Bring this slot's kernel device up, once, if kernel gamepads are on.
        A failure downgrades the slot to the interposer sockets rather than
        killing input."""
        if not self.uinput_enabled or self.uinput is not None:
            return
        device = UInputGamepad(os.path.basename(self.js_sock_path))
        try:
            nodes = device.create()
        except OSError as e:
            self.uinput_enabled = False
            logger_selkies_gamepad.error(
                f"Gamepad {self.js_sock_path}: could not create a kernel device ({e}); "
                "this slot now reaches applications only through the Joystick Interposer."
            )
            return
        self.uinput = device
        logger_selkies_gamepad.info(
            f"Gamepad {self.js_sock_path}: kernel device ready ({', '.join(nodes) or 'node path unknown'})."
        )
        unreadable = [node for node in nodes if not os.access(node, os.R_OK)]
        if unreadable:
            logger_selkies_gamepad.warning(
                f"Gamepad {self.js_sock_path}: {', '.join(unreadable)} is not readable by this user, "
                "so applications cannot open it. Add the account to the 'input' group."
            )

    def _emit_uinput(self, ev_type, ev_code, ev_value):
        self.ensure_uinput()
        if self.uinput is None:
            return
        try:
            self.uinput.emit(ev_type, ev_code, ev_value)
        except OSError as e:
            logger_selkies_gamepad.error(
                f"Gamepad {self.js_sock_path}: kernel device write failed ({e}); tearing it down."
            )
            self.uinput.destroy()
            self.uinput = None
            self.uinput_enabled = False

    def _make_interposer_config_payload(self, js_index: int, controller_config: dict) -> bytes:
        """
        Creates the configuration payload (js_config_t) to be sent to the C interposer.
        Ensures the payload is exactly C_INTERPOSER_STRUCT_SIZE (1360 bytes).
        """
        struct_fmt = base_struct_fmt = "undefined"
        try:
            name_str = controller_config.get("name", f"Selkies Virtual JS{js_index}")
            name_bytes_utf8 = name_str.encode('utf-8')
            if len(name_bytes_utf8) >= CONTROLLER_NAME_MAX_LEN:
                name_bytes_for_pack = name_bytes_utf8[:CONTROLLER_NAME_MAX_LEN - 1] + b'\0'
            else:
                name_bytes_for_pack = name_bytes_utf8.ljust(CONTROLLER_NAME_MAX_LEN, b'\0')

            if len(name_bytes_for_pack) != CONTROLLER_NAME_MAX_LEN:
                 logging.error(f"CRITICAL: name_bytes_for_pack is not {CONTROLLER_NAME_MAX_LEN} bytes long! Got {len(name_bytes_for_pack)}")
                 return b'\0' * C_INTERPOSER_STRUCT_SIZE

            raw_vendor = controller_config.get("vendor_id")
            if isinstance(raw_vendor, str):
                vendor_id = int(raw_vendor, 16)
            elif isinstance(raw_vendor, int):
                vendor_id = raw_vendor
            # Fall back to the Xbox vendor if the key is missing or the type is wrong.
            else:
                vendor_id = 0x045e
            raw_product = controller_config.get("product_id")
            if isinstance(raw_product, str):
                product_id = int(raw_product, 16)
            elif isinstance(raw_product, int):
                product_id = raw_product
            # Fall back to the Xbox product.
            else:
                product_id = 0x028e
            raw_version = controller_config.get("version")
            if isinstance(raw_version, str):
                version_id = int(raw_version, 16)
            elif isinstance(raw_version, int):
                version_id = raw_version
            # Fall back to the Xbox version.
            else:
                version_id = 0x0114

            buttons_evdev_codes = controller_config.get("buttons", [])
            axes_evdev_codes = controller_config.get("axes", [])

            # Clamp the reported counts to the array capacity so the value packed
            # into the C js_config_t can never exceed the (truncated) btn_map /
            # axes_map array lengths, which would otherwise drive an out-of-bounds
            # read in the C interposer.
            num_actual_btns = min(len(buttons_evdev_codes), INTERPOSER_MAX_BTNS)
            num_actual_axes = min(len(axes_evdev_codes), INTERPOSER_MAX_AXES)

            padded_btn_map_for_pack = list(buttons_evdev_codes)
            if len(padded_btn_map_for_pack) > INTERPOSER_MAX_BTNS:
                logging.warning(f"Controller '{name_str}' has {len(padded_btn_map_for_pack)} buttons, truncating to {INTERPOSER_MAX_BTNS} for config.")
                padded_btn_map_for_pack = padded_btn_map_for_pack[:INTERPOSER_MAX_BTNS]
            else:
                padded_btn_map_for_pack.extend([0] * (INTERPOSER_MAX_BTNS - len(padded_btn_map_for_pack)))

            padded_axes_map_for_pack = list(axes_evdev_codes)
            if len(padded_axes_map_for_pack) > INTERPOSER_MAX_AXES:
                logging.warning(f"Controller '{name_str}' has {len(padded_axes_map_for_pack)} axes, truncating to {INTERPOSER_MAX_AXES} for config.")
                padded_axes_map_for_pack = padded_axes_map_for_pack[:INTERPOSER_MAX_AXES]
            else:
                padded_axes_map_for_pack.extend([0] * (INTERPOSER_MAX_AXES - len(padded_axes_map_for_pack)))

            # Base format string for the actual data fields
            base_struct_fmt = f"={CONTROLLER_NAME_MAX_LEN}sxHHHHH{INTERPOSER_MAX_BTNS}H{INTERPOSER_MAX_AXES}B"
            
            # Calculate size of the base structure without any explicit end padding
            # (1353 bytes with the current constants)
            size_without_explicit_end_padding = struct.calcsize(base_struct_fmt)

            # Calculate how much padding is needed to reach the C struct's total size
            padding_needed = C_INTERPOSER_STRUCT_SIZE - size_without_explicit_end_padding

            if padding_needed < 0:
                logging.error(
                    f"CRITICAL STRUCT SIZE ERROR: Python base packed size ({size_without_explicit_end_padding}) "
                    f"is larger than C interposer expected size ({C_INTERPOSER_STRUCT_SIZE}). "
                    f"This means constants (MAX_BTNS, MAX_AXES, NAME_LEN) or field types/order "
                    f"differ between Python 'base_struct_fmt' and C 'js_config_t'."
                )
                return b'\0' * C_INTERPOSER_STRUCT_SIZE

            # Final format string including the calculated padding at the end
            struct_fmt = f"{base_struct_fmt}{padding_needed}x"
            
            # Verify the final Python packed size matches the C expectation
            python_final_packed_size = struct.calcsize(struct_fmt)
            if python_final_packed_size != C_INTERPOSER_STRUCT_SIZE:
                # This should ideally not be hit if padding_needed was calculated correctly
                logging.error(
                    f"CRITICAL FINAL PYTHON PACKED SIZE MISMATCH for js_config_t! "
                    f"C interposer expects: {C_INTERPOSER_STRUCT_SIZE}, "
                    f"Python struct.pack calculated final size: {python_final_packed_size} using format '{struct_fmt}'. "
                    f"This indicates an issue with padding calculation logic or the base_struct_fmt."
                )
                return b'\0' * C_INTERPOSER_STRUCT_SIZE

            logging.debug(f"Using final struct_fmt: '{struct_fmt}' for js_config, packing to size {python_final_packed_size}")

            # In C js_config_t order: char name[CONTROLLER_NAME_MAX_LEN], uint16_t
            # vendor, uint16_t product, uint16_t version, uint16_t num_btns and
            # uint16_t num_axes (both actual counts).
            payload_args = [
                name_bytes_for_pack,
                vendor_id,
                product_id,
                version_id,
                num_actual_btns,
                num_actual_axes,
            ]
            # Add elements of the padded button map array, uint16_t
            # btn_map[INTERPOSER_MAX_BTNS]
            payload_args.extend(padded_btn_map_for_pack)
            # Add elements of the padded axes map array, uint8_t
            # axes_map[INTERPOSER_MAX_AXES]
            payload_args.extend(padded_axes_map_for_pack)
            # The 'x' padding specifier in struct_fmt does not take arguments in payload_args

            payload = struct.pack(struct_fmt, *payload_args)

            log_display_name = name_bytes_for_pack.split(b'\0',1)[0].decode('utf-8', errors='replace')
            logging.info(f"Packed js_config payload for '{name_str}' (js{js_index}): "
                         f"len={len(payload)} bytes. "
                         f"Name='{log_display_name}', "
                         f"Vendor=0x{vendor_id:04x}, Product=0x{product_id:04x}, Version=0x{version_id:04x}, "
                         f"Reported Buttons={num_actual_btns} (Array capacity: {INTERPOSER_MAX_BTNS}), "
                         f"Reported Axes={num_actual_axes} (Array capacity: {INTERPOSER_MAX_AXES})")
            
            if len(payload) != C_INTERPOSER_STRUCT_SIZE:
                logging.error(f"FINAL PAYLOAD SIZE MISMATCH AFTER PACKING! Expected {C_INTERPOSER_STRUCT_SIZE}, got {len(payload)}. This is very bad.")
                return b'\0' * C_INTERPOSER_STRUCT_SIZE
            return payload

        except struct.error as e:
            # Report the most specific format string reached before the failure.
            current_struct_fmt = struct_fmt if struct_fmt != "undefined" else base_struct_fmt
            logging.error(f"Error packing joystick config for js{js_index} with format '{current_struct_fmt}': {e}")
            config_to_log = controller_config if 'controller_config' in locals() else {}
            logging.error(f"Controller config was: {config_to_log}")
            return b'\0' * C_INTERPOSER_STRUCT_SIZE
        except Exception as e:
            config_to_log = controller_config if 'controller_config' in locals() else {}
            logging.exception(f"Unexpected error creating interposer config payload for js{js_index} with config {config_to_log}: {e}")
            return b'\0' * C_INTERPOSER_STRUCT_SIZE

    async def _handle_interposer_client(self, reader, writer, is_evdev_socket):
        peername = writer.get_extra_info('peername') 
        socket_type_str = "EVDEV" if is_evdev_socket else "JS"
        clients_dict = self.evdev_clients if is_evdev_socket else self.js_clients
        sock_path = self.evdev_sock_path if is_evdev_socket else self.js_sock_path
        log_prefix = f"Gamepad {sock_path} Client {peername} ({socket_type_str}):"
        logger_selkies_gamepad.info(f"{log_prefix} Handler started.")

        try:
            # 1. Send config payload
            if not self.config_payload_cache:
                logger_selkies_gamepad.error(f"{log_prefix} Config payload not ready. Aborting handler.")
                return
            logger_selkies_gamepad.info(f"{log_prefix} Preparing to send config payload. Length: {len(self.config_payload_cache)}, Expected C size: {EXPECTED_C_STRUCT_SIZE}, First 16 bytes: {self.config_payload_cache[:16].hex()}")
            writer.write(self.config_payload_cache)
            await writer.drain()
            logger_selkies_gamepad.debug(f"{log_prefix} Sent config payload.")

            # 2. Read 1-byte architecture specifier
            arch_byte = await reader.readexactly(1)
            client_sizeof_long = struct.unpack("=B", arch_byte)[0]
            client_arch_bits = client_sizeof_long * 8
            logger_selkies_gamepad.info(f"{log_prefix} Received arch specifier: {client_sizeof_long} bytes ({client_arch_bits}-bit).")

            if not is_evdev_socket:
                # joydev semantics: replay current state as INIT events, then
                # register — snapshot, write, and registration share one loop
                # step, so no broadcast can interleave and the client's first
                # live event strictly follows its snapshot. (evdev has no
                # in-band INIT; those clients poll state via the interposer's
                # ioctl emulation.)
                writer.write(self.init_state_burst())
            clients_dict[writer] = {'arch_bits': client_arch_bits}
            await writer.drain()
            logger_selkies_gamepad.info(f"{log_prefix} Added to active list. Total {socket_type_str} clients: {len(clients_dict)}.")

            # Keep connection alive
            while self.running and not writer.is_closing():
                await asyncio.sleep(0.1) 
            
            if not self.running:
                logger_selkies_gamepad.info(f"{log_prefix} Exiting handler normally because self.running is False.")
            if writer.is_closing():
                logger_selkies_gamepad.info(f"{log_prefix} Exiting handler normally because writer.is_closing() is True (client likely closed connection).")

        except (asyncio.IncompleteReadError, ConnectionResetError, BrokenPipeError) as e:
            logger_selkies_gamepad.info(f"{log_prefix} Disconnected (expected error): {type(e).__name__} - {e}")
        except Exception as e:
            logger_selkies_gamepad.error(f"{log_prefix} Unhandled error in handler: {e}", exc_info=True)
        finally:
            logger_selkies_gamepad.info(f"{log_prefix} Entering finally block.")
            if writer in clients_dict:
                del clients_dict[writer]
                logger_selkies_gamepad.info(f"{log_prefix} Removed from active list. Total {socket_type_str} clients now: {len(clients_dict)}.")
            else:
                logger_selkies_gamepad.warning(f"{log_prefix} Writer not found in active list during finally block.")

            if not writer.is_closing():
                logger_selkies_gamepad.info(f"{log_prefix} Explicitly closing writer in finally block.")
                writer.close()
                await writer.wait_closed()
            logger_selkies_gamepad.info(f"{log_prefix} Handler finished.")

    async def _run_single_server(self, interposer_socket_path, is_evdev_socket):
        sock_dir = os.path.dirname(interposer_socket_path)
        if sock_dir and not os.path.exists(sock_dir):
            try: os.makedirs(sock_dir, exist_ok=True)
            except OSError as e:
                logger_selkies_gamepad.error(f"Failed to create directory {sock_dir} for socket: {e}")
                return None
        
        if os.path.exists(interposer_socket_path):
            try:
                os.unlink(interposer_socket_path)
                logger_selkies_gamepad.debug(f"Removed existing socket file: {interposer_socket_path}")
            except OSError as e:
                logger_selkies_gamepad.warning(f"Could not remove existing file at {interposer_socket_path}: {e}. Bind might fail.")

        try:
            server = await asyncio.start_unix_server(
                lambda r, w: self._handle_interposer_client(r, w, is_evdev_socket),
                path=interposer_socket_path
            )
            addr = server.sockets[0].getsockname() if server.sockets else interposer_socket_path
            logger_selkies_gamepad.info(f"{'EVDEV' if is_evdev_socket else 'JS'} interposer server listening on {addr}")
            return server
        except Exception as e:
            logger_selkies_gamepad.error(f"Failed to start {'EVDEV' if is_evdev_socket else 'JS'} server on {interposer_socket_path}: {e}", exc_info=True)
            return None

    async def run_servers(self):
        if not self.mapper:
            logger_selkies_gamepad.error("Mapper not set. Call set_config() before run_servers().")
            return

        self.running = True
        if self._event_processor_task is None or self._event_processor_task.done():
            self._event_processor_task = asyncio.create_task(self._process_event_queue())

        self.js_server = await self._run_single_server(self.js_sock_path, is_evdev_socket=False)
        self.evdev_server = await self._run_single_server(self.evdev_sock_path, is_evdev_socket=True)

        if not self.js_server and not self.evdev_server:
            logger_selkies_gamepad.error("Neither JS nor EVDEV interposer server could be started. Stopping.")
            self.running = False
            if self._event_processor_task and not self._event_processor_task.done():
                self._event_processor_task.cancel()
            return
        
        while self.running:
            await asyncio.sleep(1)
        logger_selkies_gamepad.info("run_servers loop exited.")

    def send_event(self, client_event_idx, client_value, is_button_event):
        if not self.mapper or not self.running:
            return
        event_package = self.mapper.get_mapped_events(client_event_idx, client_value, is_button_event)
        if event_package:
            # Remember non-neutral controls so reset_state can release exactly
            # what is held if the driving client disappears mid-input.
            control = (is_button_event, client_event_idx)
            if client_value:
                self._held_controls.add(control)
            else:
                self._held_controls.discard(control)
            js_data = event_package.get('js_event_data')
            if js_data:
                _, value, ev_type, number = struct.unpack("=IhBB", js_data)
                self._js_state[(ev_type, number)] = value
            logger_selkies_gamepad.debug(f"Gamepad {self.js_sock_path}: Queuing event: {event_package}")
            try:
                self.events_queue.put_nowait(event_package)
            except asyncio.QueueFull:
                # Drop the oldest queued event to make room for this newer one, so a
                # stalled client draining slowly can't back-pressure into unbounded
                # growth. The shutdown sentinel (None) is re-enqueued if evicted.
                try:
                    dropped = self.events_queue.get_nowait()
                    self.events_queue.task_done()
                    if dropped is None:
                        self.events_queue.put_nowait(None)
                        return
                except asyncio.QueueEmpty:
                    pass
                try:
                    self.events_queue.put_nowait(event_package)
                except asyncio.QueueFull:
                    logger_selkies_gamepad.warning(
                        f"Gamepad {self.js_sock_path}: event queue full; dropping event."
                    )

    def reset_state(self):
        """Emit a neutral value for every control still held non-neutral, so a
        dropped association leaves no stuck button or off-center axis behind on
        the app driving this pad."""
        for is_button_event, client_event_idx in list(self._held_controls):
            self.send_event(client_event_idx, 0, is_button_event)

    def init_state_burst(self):
        """joydev-parity state replay for a newly connected JS client: every
        control's current value as JS_EVENT_INIT-flagged events, so an app
        opening the pad mid-hold starts from the true state (and input during
        the connect handshake is covered as state, not lost edges). Buttons
        rest at 0, stick/hat axes at center, triggers at the mapper's released
        value."""
        mapping = STANDARD_XPAD_CONFIG["mapping"]
        parts = []
        for idx in range(len(STANDARD_XPAD_CONFIG["btn_map"])):
            value = self._js_state.get((JS_EVENT_BUTTON, idx), 0)
            parts.append(get_js_event_packed(JS_EVENT_BUTTON | JS_EVENT_INIT, idx, value))
        for idx in range(len(STANDARD_XPAD_CONFIG["axes_map"])):
            rest = normalize_axis_value(
                0,
                idx in mapping["trigger_internal_abstract_axis_indices"],
                idx in mapping["hat_internal_abstract_axis_indices"],
                for_js_event=True,
            )
            value = self._js_state.get((JS_EVENT_AXIS, idx), rest)
            parts.append(get_js_event_packed(JS_EVENT_AXIS | JS_EVENT_INIT, idx, value))
        return b"".join(parts)

    async def _process_event_queue(self):
        logger_selkies_gamepad.info(f"Gamepad {self.js_sock_path}: Event processor started.")
        while self.running:
            try:
                event_package = await self.events_queue.get()
                # None is the sentinel for shutdown.
                if event_package is None:
                    self.events_queue.task_done()
                    break
                
                logger_selkies_gamepad.debug(f"Gamepad {self.js_sock_path}: Dequeued event: {event_package}")
                
                js_data = event_package.get('js_event_data')
                evdev_template = event_package.get('evdev_event_template') 

                # Send to JS clients
                if js_data:
                    for i, (writer, _client_info) in enumerate(list(self.js_clients.items())):
                        if not writer.is_closing():
                            try:
                                writer.write(js_data)
                                # Bounded: a game that stops reading its socket must
                                # not freeze this gamepad's event processor for the
                                # other consumers.
                                await asyncio.wait_for(writer.drain(), timeout=1.0)
                                logger_selkies_gamepad.debug(f"Gamepad {self.js_sock_path}: JS event drained to client #{i}.")
                            except asyncio.TimeoutError:
                                logger_selkies_gamepad.warning(f"Gamepad {self.js_sock_path}: JS client #{i} stalled; closing it.")
                                writer.close()
                            except (ConnectionResetError, BrokenPipeError): pass
                            except Exception as e:
                                logger_selkies_gamepad.error(f"Error sending to JS client #{i}: {e}", exc_info=True)
                
                # Send to EVDEV clients
                if evdev_template:
                    ev_type, ev_code, ev_value = evdev_template
                    self._emit_uinput(ev_type, ev_code, ev_value)
                    for i, (writer, client_info) in enumerate(list(self.evdev_clients.items())):
                        if not writer.is_closing():
                            try:
                                client_arch_bits = client_info.get('arch_bits', 64) 
                                evdev_data = get_evdev_events_packed(ev_type, ev_code, ev_value, client_arch_bits)
                                writer.write(evdev_data)
                                await asyncio.wait_for(writer.drain(), timeout=1.0)
                                logger_selkies_gamepad.debug(f"Gamepad {self.js_sock_path}: EVDEV event drained to client #{i}.")
                            except asyncio.TimeoutError:
                                logger_selkies_gamepad.warning(f"Gamepad {self.js_sock_path}: EVDEV client #{i} stalled; closing it.")
                                writer.close()
                            except (ConnectionResetError, BrokenPipeError): pass
                            except Exception as e:
                                logger_selkies_gamepad.error(f"Error sending to EVDEV client #{i}: {e}", exc_info=True)
                
                self.events_queue.task_done()
            except asyncio.CancelledError:
                logger_selkies_gamepad.info(f"Gamepad {self.js_sock_path}: Event processor task cancelled.")
                break
            except Exception as e:
                logger_selkies_gamepad.error(f"Gamepad {self.js_sock_path}: Unhandled error in event processor: {e}", exc_info=True)
        logger_selkies_gamepad.info(f"Gamepad {self.js_sock_path}: Event processor stopped.")


    async def close(self):
        logger_selkies_gamepad.info(f"Closing gamepad services for JS:{self.js_sock_path}, EVDEV:{self.evdev_sock_path}")
        self.running = False

        if self.js_server:
            self.js_server.close()
            await self.js_server.wait_closed()
            self.js_server = None
            logger_selkies_gamepad.info(f"JS interposer server {self.js_sock_path} closed.")
        if self.evdev_server:
            self.evdev_server.close()
            await self.evdev_server.wait_closed()
            self.evdev_server = None
            logger_selkies_gamepad.info(f"EVDEV interposer server {self.evdev_sock_path} closed.")

        for writer in list(self.js_clients.keys()):
            if not writer.is_closing(): writer.close()
        self.js_clients.clear()
        for writer in list(self.evdev_clients.keys()):
            if not writer.is_closing(): writer.close()
        self.evdev_clients.clear()
        
        if self._event_processor_task and not self._event_processor_task.done():
            try:
                self.events_queue.put_nowait(None) 
                await asyncio.wait_for(self._event_processor_task, timeout=2.0)
            except asyncio.TimeoutError:
                logger_selkies_gamepad.warning("Event processor task timed out on close, cancelling.")
                self._event_processor_task.cancel()
            except asyncio.CancelledError:
                pass 
            except Exception as e:
                logger_selkies_gamepad.error(f"Exception stopping event processor: {e}")
        self._event_processor_task = None
        
        for sock_path in [self.js_sock_path, self.evdev_sock_path]:
            if sock_path and os.path.exists(sock_path):
                try:
                    os.unlink(sock_path)
                    logger_selkies_gamepad.info(f"Removed socket file: {sock_path}")
                except OSError as e:
                    logger_selkies_gamepad.warning(f"Could not remove socket file {sock_path} on close: {e}")

        if self.uinput is not None:
            self.uinput.destroy()
            self.uinput = None

        logger_selkies_gamepad.info("Gamepad services fully closed.")


# --- WebRTCInput Class ---
class WebRTCInputError(Exception): pass

class WebRTCInput:
    def __init__(
        self,
        rtc_app,
        uinput_mouse_socket_path="",
        js_socket_path_prefix="/tmp", 
        enable_clipboard="",
        enable_binary_clipboard="",
        enable_cursors=True,
        cursor_size=16, 
        cursor_scale=1.0,
        cursor_debug=False,
        max_cursor_size=32,
        data_server_instance=None,
        upload_dir=None,
        is_wayland=False,
        wayland_socket_index=0,
        app_wayland_display="",
        uinput_gamepad="auto",
    ):
        self.wayland_socket_index = wayland_socket_index
        # Socket of the compositor apps run under (input + clipboard target) when
        # it differs from the pixelflux capture compositor; resolved lazily since
        # a nested session comes up after this process.
        self.app_wayland_display = app_wayland_display
        self._app_wl_display_cached = None
        self._x_reconnect_thread = None
        self._x11_monitor_build_lock = asyncio.Lock()
        # Event-driven wake for X consumers (cursor monitor, keymap watch): a
        # loop reader on the input connection's fd sets this Event, so those
        # loops block with zero wakeups instead of polling the socket.
        self._x_event_wake = None
        self._x_watcher_fd = None
        # Negative cache: the auto-detect sweep stays uncached until a distinct app
        # compositor appears, and it is consulted from per-key native_inject, so a
        # TTL floors the directory relist until then.
        self._app_wl_negcache = None
        self._app_wl_negcache_at = 0.0
        # True once a resolved app compositor is confirmed distinct from the capture
        # compositor; lets _has_separate_app_compositor answer without re-resolving.
        self._app_wl_is_separate = False
        self.active_shortcut_modifiers = set()
        self.SHORTCUT_MODIFIER_XKEY_NAMES = {
            'Control_L', 'Control_R', 
            'Alt_L', 'Alt_R', 
            'Super_L', 'Super_R',
            'Meta_L', 'Meta_R'
        }
        self.active_modifiers = set()
        self.atomically_typed_keys = set()
        # Tracks translated keysyms.
        self.translated_keys = set()
        self.ACTION_MODIFIER_KEYSYMS = {65507, 65508, 65513, 65514, 65511, 65512,
                                        65515, 65516, 65517, 65518}
        # Shift_L/R, ISO_Level3_Shift, Mode_switch: the level-selecting
        # modifiers whose client-held state the injectors consult in place of a
        # per-press server query.
        self.LEVEL_MODIFIER_KEYSYMS = frozenset({0xFFE1, 0xFFE2, 0xFE03, 0xFF7E})
        self.MODIFIER_KEYSYMS = {
            # Shift_L, Shift_R
            65505, 65506,
            # Control_L, Control_R
            65507, 65508,
            # Alt_L, Alt_R
            65513, 65514,
            # ISO_Level3_Shift (AltGr)
            65027,
            # Meta_L, Meta_R
            65511, 65512,
            # The client maps the Meta/Windows key to Super, not Meta, so Super
            # (and Hyper) must be treated as modifiers too — otherwise they get
            # armed for auto-repeat and misrouted as ordinary keys.
            # Super_L, Super_R
            65515, 65516,
            # Hyper_L, Hyper_R
            65517, 65518,
        }
        self.rtc_app = rtc_app
        self.loop = asyncio.get_running_loop()
        self.js_socket_path_prefix = js_socket_path_prefix
        self.num_gamepads = 4
        self.gamepad_instances = {}
        self.client_gamepad_associations = {}
        # Resolved once: the decision (and the reason for it) is logged at startup
        # rather than per gamepad slot.
        self.uinput_gamepads = uinput_gamepads_enabled(uinput_gamepad)

        self.clipboard_running = False
        # Serializes update_binary_clipboard_setting so its cancel+reassign of the
        # monitor task is atomic (two rapid toggles can't interleave at the await).
        self._binary_clipboard_lock = asyncio.Lock()
        # Singleton guard: only one start_clipboard poll loop may run at a time.
        self._clipboard_monitor_active = False
        self.uinput_mouse_socket_path = uinput_mouse_socket_path
        self.uinput_mouse_socket = None
        self.enable_clipboard = enable_clipboard
        self.enable_binary_clipboard = enable_binary_clipboard
        self.enable_cursors = enable_cursors
        self.cursors_running = False
        self.cursor_scale = cursor_scale
        self.cursor_size = cursor_size
        self.cursor_debug = cursor_debug
        # An explicit cursor_size raises the remote-cursor capture cap so the
        # requested size survives the transport instead of being resized down.
        if isinstance(cursor_size, int) and cursor_size > 0:
            max_cursor_size = max(max_cursor_size, cursor_size)
        self.max_cursor_size = max_cursor_size
        self.system_dpi = 96.0
        self.cursor_size_cap = max_cursor_size
        self.keyboard = None
        self.mouse = None
        self.xdisplay = None
        self.button_mask = 0
        self.last_x = -1
        self.last_y = -1
        self.ping_start = None

        self.upload_dir = upload_dir
        self.upload_dir_path = None

        async def _unhandled_video_bitrate(bitrate, display_id="primary"):
            logger_webrtc_input.warning(f"unhandled on_video_encoder_bit_rate: {bitrate}")
        self.on_video_encoder_bit_rate = _unhandled_video_bitrate
        async def _unhandled_audio_bitrate(bitrate):
            logger_webrtc_input.warning(f"unhandled on_audio_encoder_bit_rate: {bitrate}")
        self.on_audio_encoder_bit_rate = _unhandled_audio_bitrate
        async def _unhandled_mouse_pointer(visible):
            logger_webrtc_input.warning(f"unhandled on_mouse_pointer_visible: {visible}")
        self.on_mouse_pointer_visible = _unhandled_mouse_pointer
        self.on_clipboard_read = self._on_clipboard_read
        self.on_set_fps = lambda fps, display_id="primary": logger_webrtc_input.warning("unhandled on_set_fps")
        self.on_request_keyframe = lambda display_id="primary": logger_webrtc_input.warning("unhandled on_request_keyframe")
        self.on_set_enable_resize = lambda enable_resize, res: logger_webrtc_input.warning("unhandled on_set_enable_resize")
        self.on_client_fps = lambda fps: logger_webrtc_input.warning("unhandled on_client_fps")
        self.on_client_latency = lambda latency: logger_webrtc_input.warning("unhandled on_client_latency")
        self.on_resize = lambda res, display_id="primary": logger_webrtc_input.warning("unhandled on_resize")
        self.on_scaling_ratio = lambda res: logger_webrtc_input.warning("unhandled on_scaling_ratio")
        self.on_ping_response = lambda latency: logger_webrtc_input.warning("unhandled on_ping_response")
        self.on_cursor_change = self._on_cursor_change
        async def _unhandled_webrtc_stats(webrtc_stat_type, webrtc_stats):
            logger_webrtc_input.debug(f"unhandled on_client_webrtc_stats: {webrtc_stat_type}")
        self.on_client_webrtc_stats = _unhandled_webrtc_stats
        self.clipboard_monitor_task = None
        self.multipart_clipboard_buffer = None
        self.multipart_clipboard_mime_type = "text/plain"
        self.multipart_clipboard_total_size = 0
        self.multipart_clipboard_in_progress = False
        self.multipart_clipboard_id = None
        self.multipart_clipboard_kind = None
        self.data_server_instance = data_server_instance
        self.on_update_settings = lambda settings_json, display_id="primary": logger_webrtc_input.warning("unhandled update_settings")
        self.is_wayland = is_wayland
        self.wayland_input = None
        # Last applied client keyboardLayout hint (SETTINGS), both transports.
        self._client_kb_layout = None
        # Keysym policy lives here, not in the compositor: built lazily from the
        # compositor's keymap, retried on a cooldown if that read fails.
        self._wl_keymap_owner = None
        self._wl_keymap_owner_lock = asyncio.Lock()
        self._wl_keymap_retry_at = 0.0
        # One-shot zwp_virtual_keyboard_v1 injection via pixelflux, serialized so
        # text commits keep their order. A compositor that lacks the protocol is
        # re-probed on a cooldown only, so per-keystroke fallbacks stay cheap.
        self._wl_typer_lock = asyncio.Lock()
        self._wl_typer_retry_at = 0.0
        # Clipboard-paste text injection (the KWin route): serialized so one
        # save/write/paste/restore cycle finishes before the next, with a
        # reentrancy latch so the paste chord's own key path can't recurse.
        self._clipboard_inject_lock = asyncio.Lock()
        self._clipboard_inject_active = False
        # Change-detection baseline shared by the monitor AND write_clipboard: content
        # this server just wrote must never be re-broadcast (client<->server echo loop),
        # and the baseline survives client reconnects so nothing is resent unchanged.
        self._clipboard_last_bytes = None
        self._x11_clipboard_monitor = None
        self._x11_monitor_retry_at = 0.0
        self._x11_monitor_unavail_logged = False
        self._xclip_missing_warned = False
        # Debounce REQUEST_CLIPBOARD (Ctrl/Cmd+C): coalesce bursts so a keypress
        # storm can't stack clipboard reads. Keyed per requesting connection so
        # one client's copy can't suppress another client's read. The map is
        # conn key -> last request (monotonic) and the debounce is in seconds.
        self._last_clipboard_request_ts = {}
        self._clipboard_request_debounce = 0.25
        # Strong refs for fire-and-forget tasks: asyncio only weakly references
        # running tasks, so an unreferenced one can be garbage-collected mid-flight.
        self._bg_tasks = set()
        self.keyboard_queue = asyncio.Queue(maxsize=4096)
        self.keyboard_worker_task = None
        # Keysyms whose kd became buffered text on the Wayland worker (nested app
        # compositor): their ku must be swallowed, not released.
        self._wl_text_routed = {}
        # Stuck-key recovery: client heartbeats each held key ('kh'); the sweep
        # auto-releases any key whose heartbeat stops (key-up lost to congestion).
        # keysym -> last heartbeat (monotonic).
        self.pressed_keys = {}
        # Atomic (non-alpha) keys reaped by the sweep were never physically held, so
        # a late 'ku' would emit a spurious X11 keyup. Track them to swallow it; a
        # fresh 'kd' clears the entry (the key is live again).
        self.reaped_atomic_keys = set()
        # Cap tracked held keys so a kd-flood can't grow the dict unbounded.
        self.max_pressed_keys = 1024
        # Stale window: a key unseen for this long is released. Clients heartbeat
        # every 100ms but hidden tabs throttle to >=1s, so 2.0s avoids
        # false-releasing a held key while backgrounded.
        self.key_stale_window = 2.0
        self.key_sweep_interval = 0.1
        self.key_sweep_task = None
        # Server-side key auto-repeat (X11 only). XTEST/xdotool
        # synthetic presses do not trigger the X server's native auto-repeat, so a held
        # key would emit a single character. We re-emit held repeatable keys here at the
        # configured rate. Disabled on Wayland: the focused app repeats held
        # virtual-keyboard keys itself via wl_keyboard repeat_info, so a server-side
        # repeat would double it.
        self.key_repeat_enabled = not self.is_wayland
        # Seconds a key must stay held before repeating, seconds between repeats
        # (~25 Hz), and the repeat loop's poll period.
        self.key_repeat_delay = 0.5
        self.key_repeat_interval = 0.04
        self.key_repeat_tick = 0.02
        # Pause repeat when the held key's last heartbeat is older than this (stalled
        # stream / hidden tab). Keep >~3x the client's 100ms heartbeat.
        self.key_repeat_heartbeat_grace = 0.3
        # keysym -> monotonic time of its next due repeat.
        self.key_repeat_state = {}
        self.key_repeat_task = None
        # MappingNotify consumer for sessions where the cursor monitor (the
        # normal X event consumer) is disabled.
        self.keymap_watch_task = None
        self.on_update_rate_control_mode = lambda mode, display_id="primary": logger_webrtc_input.warning("unhandled on_update_rate_control_mode")
        self.on_update_crf = lambda value, display_id="primary": logger_webrtc_input.warning("unhandled on_update_crf")

        if self.is_wayland:
            try:
                if ScreenCapture is None:
                    raise RuntimeError("pixelflux is not installed")
                self.wayland_input = ScreenCapture()
                logger_webrtc_input.info("Wayland input injection initialized.")
            except Exception as e:
                logger_webrtc_input.error(f"Failed to initialize Wayland input: {e}")

    async def _on_clipboard_read(self, data, mime_type="text/plain"):
        await self.send_clipboard_data(data, mime_type)
    def _on_cursor_change(self, data): self.send_cursor_data(data)
    async def send_clipboard_data(self, data, mime_type="text/plain"):
        # Mode router only: each transport owns its one chunked sender
        # (SelkiesStreamingApp.send_ws_clipboard_data / RTCApp.send_clipboard_data).
        if self.rtc_app.mode == "websockets":
            await self.rtc_app.send_ws_clipboard_data(data, mime_type)
        else:
            await self.rtc_app.send_clipboard_data(data, mime_type)
    def send_cursor_data(self, data):
        if self.rtc_app.mode == "websockets": self.rtc_app.send_ws_cursor_data(data)
        else: self.rtc_app.send_cursor_data(data)

    def __keyboard_connect(self): self.keyboard = _XTestKeyboard(self.xdisplay) if self.xdisplay else None

    def _apply_input_x_reply_bound(self):
        """Bound the wait for an X REPLY on the shared input connection so an
        unresponsive server (driver hang, a foreign client's server grab) raises
        ConnectionClosedError instead of freezing the event loop forever. XTEST
        injection (mouse motion/buttons, key press) is a no-reply request and is
        unaffected — only the modifier query (query_keymap) and the cursor-image
        fetch block, and those recover via _reconnect_xdisplay(). Event waits stay
        unbounded (a quiet server sending no cursor events is not an error)."""
        if self.xdisplay is None:
            return
        try:
            self.xdisplay.display.blocking_timeout = INPUT_X_REPLY_TIMEOUT_S
        except Exception:
            pass

    def _arm_x_event_watcher(self):
        """(Re)register the event-loop reader that wakes X consumers when the
        input connection's socket goes readable. Idempotent; re-arms when the fd
        changes under us (reconnect)."""
        if self._x_event_wake is None:
            return
        fd = None
        if self.xdisplay is not None:
            try:
                fd = self.xdisplay.fileno()
            except Exception:
                fd = None
        if fd is not None and fd < 0:
            fd = None
        if fd == self._x_watcher_fd:
            return
        if self._x_watcher_fd is not None:
            try:
                self.loop.remove_reader(self._x_watcher_fd)
            except Exception:
                pass
        self._x_watcher_fd = fd
        if fd is not None:
            try:
                self.loop.add_reader(fd, self._x_event_wake.set)
            except Exception as e:
                logger_webrtc_input.debug(f"X event watcher unavailable ({e}); consumers poll.")
                self._x_watcher_fd = None

    def _disarm_x_event_watcher(self):
        if self._x_watcher_fd is not None:
            try:
                self.loop.remove_reader(self._x_watcher_fd)
            except Exception:
                pass
            self._x_watcher_fd = None

    async def _wait_x_event(self, timeout=1.0):
        """Sleep until the X socket signals readability or the failsafe elapses.
        Callers clear the Event BEFORE re-checking event availability, so an
        event arriving between the check and the wait is never lost. With no
        reader armed (add_reader unsupported or failed) nothing will ever set the
        Event, so fall back to a short poll rather than idling out the failsafe."""
        wake = self._x_event_wake
        if wake is None:
            await asyncio.sleep(timeout)
            return
        if self._x_watcher_fd is None:
            await asyncio.sleep(min(timeout, INPUT_X_EVENT_POLL_S))
            return
        try:
            await asyncio.wait_for(wake.wait(), timeout)
        except asyncio.TimeoutError:
            pass

    def _reconnect_xdisplay(self):
        """Rebuild the input X connection after a bounded reply-wait closed it.
        Fire-and-forget: the rebuild runs on a worker thread and installs via the
        loop (_install_reconnected_xdisplay), so xdisplay stays None — and input
        degraded (xdotool fallbacks) — until the attempt lands. Callers just
        continue; the next X failure retries."""
        self._disarm_x_event_watcher()
        if self._x_reconnect_thread is not None and self._x_reconnect_thread.is_alive():
            return
        old = self.xdisplay
        self.xdisplay = None
        self.keyboard = None
        self.mouse = None

        def _attempt():
            # Worker thread: every caller sits on the event loop, and against a
            # server hung under another client's grab — the main condition this
            # reconnect exists to survive — close() and the connection setup would
            # otherwise freeze the loop for the whole outage. The handshake itself
            # is bounded so a permanently dead server can't pin this thread forever.
            try:
                if old is not None:
                    try:
                        old.close()
                    except Exception:
                        pass
                disp = display.Display(blocking_timeout=INPUT_X_REPLY_TIMEOUT_S)
            except Exception as e:
                logger_webrtc_input.error(f"Could not reconnect input X display: {e}")
                return
            try:
                self.loop.call_soon_threadsafe(self._install_reconnected_xdisplay, disp)
            except RuntimeError:
                try:
                    disp.close()
                except Exception:
                    pass

        self._x_reconnect_thread = threading.Thread(
            target=_attempt, name="x-input-reconnect", daemon=True
        )
        self._x_reconnect_thread.start()

    def _install_reconnected_xdisplay(self, disp):
        """Loop-side half of _reconnect_xdisplay: wire the fresh connection into
        every consumer in one step so nothing observes a half-initialized display."""
        if self.xdisplay is not None:
            # An earlier attempt already landed; keep it and drop this connection.
            try:
                disp.close()
            except Exception:
                pass
            return
        self.xdisplay = disp
        self._apply_input_x_reply_bound()
        self._arm_x_event_watcher()
        self.__keyboard_connect()
        if not self.is_wayland:
            self.mouse = _XTestMouse(self.xdisplay)
        if self.cursors_running:
            try:
                screen = self.xdisplay.screen()
                self.xdisplay.xfixes_select_cursor_input(
                    screen.root, xfixes.XFixesDisplayCursorNotifyMask
                )
            except Exception as e:
                logger_webrtc_input.warning(f"Could not re-arm cursor monitor after reconnect: {e}")
        logger_webrtc_input.warning("Input X connection was unresponsive; reconnected.")

    def _is_x_conn_closed(self, exc):
        """True if `exc` is the connection-closed error the reply bound raises."""
        return xlib_error is not None and isinstance(exc, xlib_error.ConnectionClosedError)

    async def _load_server_autorepeat_rate(self):
        """Best-effort: adopt the X server's configured autorepeat delay/rate for our
        synthetic server-side repeat, so a held key feels native. python-xlib in some
        builds lacks the XKB controls API, so read it once at connect from `xset q`
        (one-time, not per-event). Any failure or out-of-range value keeps the sane
        defaults set in __init__."""
        if self.is_wayland:
            return
        try:
            process = await subprocess.create_subprocess_exec(
                "xset", "q", stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            out, _err = await self._communicate_or_kill(process, 0.5, "xset q autorepeat")
            if process.returncode != 0 or not out:
                return
            text = out.decode("utf-8", "replace") if isinstance(out, (bytes, bytearray)) else str(out)
            m = re.search(r"auto repeat delay:\s*(\d+)\s*repeat rate:\s*(\d+)", text)
            if not m:
                return
            delay_ms = int(m.group(1))
            rate_hz = int(m.group(2))
            # Sanity-clamp: reject nonsense (e.g. 0) that would busy-repeat or never repeat.
            if 100 <= delay_ms <= 2000:
                self.key_repeat_delay = delay_ms / 1000.0
            if 1 <= rate_hz <= 100:
                self.key_repeat_interval = 1.0 / rate_hz
            logger_webrtc_input.info(
                f"Server autorepeat: delay {self.key_repeat_delay:.3f}s, "
                f"interval {self.key_repeat_interval:.3f}s."
            )
        except Exception as e:
            logger_webrtc_input.debug(f"Could not read server autorepeat rate (using defaults): {e}")
    def __mouse_connect(self):
        if self.uinput_mouse_socket_path:
            logger_webrtc_input.info(f"Connecting to uinput mouse socket: {self.uinput_mouse_socket_path}")
            self.uinput_mouse_socket = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        if not self.is_wayland and self.xdisplay:
            self.mouse = _XTestMouse(self.xdisplay)
    def __mouse_disconnect(self):
        if self.mouse: del self.mouse; self.mouse = None
        if self.uinput_mouse_socket is not None:
            try:
                self.uinput_mouse_socket.close()
            except OSError:
                pass
            self.uinput_mouse_socket = None
    def __mouse_emit(self, *args, **kwargs):
        if self.uinput_mouse_socket_path:
            cmd = {"args": args, "kwargs": kwargs}
            data = msgpack.packb(cmd, use_bin_type=True)
            self.uinput_mouse_socket.sendto(data, self.uinput_mouse_socket_path)

    async def __gamepad_connect(self, gamepad_idx, client_name, client_num_btns, client_num_axes, conn_id=None):
        if not (0 <= gamepad_idx < self.num_gamepads):
            logger_webrtc_input.error(f"Client association: Gamepad index {gamepad_idx} out of range (0-{self.num_gamepads-1}).")
            return

        if gamepad_idx not in self.gamepad_instances:
            logger_webrtc_input.error(
                f"Client association: No persistent gamepad instance found for index {gamepad_idx}. "
                f"This should not happen if _initialize_persistent_gamepads ran correctly."
            )
            return

        # Log the association
        logger_webrtc_input.info(
            f"Client controller '{client_name}' ({client_num_btns}b, {client_num_axes}a) "
            f"is now associated with persistent virtual gamepad slot {gamepad_idx}."
        )

        self.client_gamepad_associations[gamepad_idx] = {
            "client_name": client_name,
            "client_num_btns": client_num_btns,
            "client_num_axes": client_num_axes,
            "association_time": time.time(),
            "conn_id": conn_id,
        }

        # Kernel device up front, so applications see a plug event before the
        # first input rather than a controller that appears mid-press.
        self.gamepad_instances[gamepad_idx].ensure_uinput()

    async def release_gamepads_for_conn(self, conn_id):
        """Disassociate (and neutralize, via reset_state) every gamepad slot whose
        association was made by this transport connection. This is the ungraceful
        path — a tab that dies mid-press never sends 'js,d', and only the transport
        knows the connection is gone."""
        if conn_id is None:
            return
        for idx, info in list(self.client_gamepad_associations.items()):
            if info.get("conn_id") == conn_id:
                await self.__gamepad_disconnect(idx)

    async def __gamepad_disconnect(self, gamepad_idx=None):
        # Disassociate all if no specific index.
        if gamepad_idx is None:
            indices_to_disassociate = list(self.client_gamepad_associations.keys())
            logger_webrtc_input.info("Disassociating all client gamepads from persistent slots.")
        elif not (0 <= gamepad_idx < self.num_gamepads):
            logger_webrtc_input.error(f"Client disassociation: Gamepad index {gamepad_idx} out of range.")
            return
        else:
            indices_to_disassociate = [gamepad_idx]

        for idx in indices_to_disassociate:
            if idx in self.client_gamepad_associations:
                associated_info = self.client_gamepad_associations.pop(idx)
                # Release anything still held on the persistent pad: an ungraceful
                # client drop (a tab closed mid-press) would otherwise leave the
                # in-desktop app with a stuck button or deflected stick until a new
                # client re-sends state.
                gamepad = self.gamepad_instances.get(idx)
                if gamepad is not None:
                    gamepad.reset_state()
                logger_webrtc_input.info(
                    f"Client controller '{associated_info.get('client_name', 'Unknown')}' "
                    f"disassociated from persistent virtual gamepad slot {idx}."
                )
            # Only log if a specific, non-associated index was requested.
            elif gamepad_idx is not None:
                 logger_webrtc_input.warning(
                    f"Client disassociation: No active client association found for gamepad slot {idx} to disassociate."
                )

    def __gamepad_emit_btn(self, gamepad_idx, client_btn_num, client_btn_val):
        gamepad = self.gamepad_instances.get(gamepad_idx)
        if gamepad:
            gamepad.send_event(client_btn_num, client_btn_val, is_button_event=True)

    def __gamepad_emit_axis(self, gamepad_idx, client_axis_num, client_axis_val):
        gamepad = self.gamepad_instances.get(gamepad_idx)
        if gamepad:
            gamepad.send_event(client_axis_num, client_axis_val, is_button_event=False)
            
    async def connect(self):
        if not self.is_wayland and X11_LIBS_AVAILABLE:
            # Bounded handshake: a server hung under another client's grab at
            # startup must surface as a failure, not freeze the loop.
            try: self.xdisplay = display.Display(blocking_timeout=INPUT_X_REPLY_TIMEOUT_S)
            except Exception as e: logger_webrtc_input.error(f"Failed to connect to X display: {e}"); self.xdisplay = None
            self._apply_input_x_reply_bound()
            if self._x_event_wake is None:
                self._x_event_wake = asyncio.Event()
            self._arm_x_event_watcher()
        if self.xdisplay:
            try:
                screen = self.xdisplay.screen()
                width_mm = screen.width_in_mms
                height_mm = screen.height_in_mms
                if width_mm > 0 and height_mm > 0:
                    dpi_x = (screen.width_in_pixels * 25.4) / width_mm
                    dpi_y = (screen.height_in_pixels * 25.4) / height_mm
                    self.system_dpi = (dpi_x + dpi_y) / 2.0
                dpi_scale_factor = self.system_dpi / 96.0
                self.cursor_size_cap = int(self.max_cursor_size * dpi_scale_factor)
                logger_webrtc_input.info(
                    f"System DPI detected as ~{self.system_dpi:.0f}. "
                    f"Cursor size cap set to {self.cursor_size_cap}x{self.cursor_size_cap}px."
                )
            except Exception as e:
                logger_webrtc_input.warning(f"Could not determine system DPI, using default 96. Error: {e}")
        if not self.is_wayland and X11_LIBS_AVAILABLE:
            self.__keyboard_connect()
        if self.xdisplay:
            await self._load_server_autorepeat_rate()
            await self.reset_keyboard()
        self.__mouse_connect()
        
        # Initialize persistent gamepad instances
        await self._initialize_persistent_gamepads()

        if self.is_wayland:
            self.keyboard_worker_task = asyncio.create_task(self._keyboard_worker())
            await self._push_wayland_base_layout()
        if self.key_sweep_task is None:
            self.key_sweep_task = asyncio.create_task(self._key_stale_sweep())
        if self.key_repeat_enabled and self.key_repeat_task is None:
            self.key_repeat_task = asyncio.create_task(self._key_repeat_loop())
        if self.xdisplay is not None and self.keymap_watch_task is None:
            self.keymap_watch_task = asyncio.create_task(self._keymap_watch_loop())

    async def _initialize_persistent_gamepads(self):
        logger_webrtc_input.info(f"Initializing {self.num_gamepads} persistent gamepad instances...")
        if not os.path.exists(self.js_socket_path_prefix):
            try:
                os.makedirs(self.js_socket_path_prefix, exist_ok=True)
                logger_webrtc_input.info(f"Created directory for gamepad sockets: {self.js_socket_path_prefix}")
            except OSError as e:
                logger_webrtc_input.error(f"Failed to create directory {self.js_socket_path_prefix} for gamepad sockets: {e}")
                # Cannot proceed if directory creation fails.
                return

        for i in range(self.num_gamepads):
            # Should not happen on the initial call, but good for robustness.
            if i in self.gamepad_instances:
                logger_webrtc_input.warning(f"Gamepad instance for index {i} already exists. Skipping re-initialization.")
                continue

            # Adopt the process-wide instance when one is live: its sockets are what
            # already-running apps hold open, so a service restart (transport mode
            # switch) must reuse them — rebinding would orphan those apps' fds.
            existing = _persistent_gamepads.get(i)
            if existing is not None and existing.running:
                self.gamepad_instances[i] = existing
                logger_webrtc_input.info(
                    f"Adopted live persistent gamepad instance for index {i} (JS: {existing.js_sock_path})."
                )
                continue

            js_ip_sock_path = os.path.join(self.js_socket_path_prefix, f"selkies_js{i}.sock")
            evdev_ip_sock_path = os.path.join(self.js_socket_path_prefix, f"selkies_event{1000+i}.sock")

            gamepad = SelkiesGamepad(
                js_ip_sock_path, evdev_ip_sock_path, self.loop,
                uinput_enabled=self.uinput_gamepads,
            )

            # Use standardized name and capabilities from STANDARD_XPAD_CONFIG
            gamepad_name_for_interposer = STANDARD_XPAD_CONFIG.get("name", f"Selkies Virtual Gamepad {i}")
            std_num_btns = len(STANDARD_XPAD_CONFIG["btn_map"])
            std_num_axes = len(STANDARD_XPAD_CONFIG["axes_map"])

            # Pass the standardized name to set_config.
            gamepad.set_config(gamepad_name_for_interposer, std_num_btns, std_num_axes)

            self._spawn_task(gamepad.run_servers())
            _persistent_gamepads[i] = gamepad
            self.gamepad_instances[i] = gamepad
            logger_webrtc_input.info(f"Initialized and started persistent gamepad instance for index {i} (Name: '{gamepad_name_for_interposer}', JS: {js_ip_sock_path}, EVDEV: {evdev_ip_sock_path}).")

    async def disconnect(self):
        # The persistent gamepad instances (and their interposer sockets) outlive
        # this handler: apps hold those fds open across client sessions AND
        # transport mode switches, and would go permanently silent if the sockets
        # closed here. Only the per-session client->slot associations are ours.
        logger_webrtc_input.info("Releasing gamepad associations (persistent instances stay up).")
        await self.__gamepad_disconnect()
        self.gamepad_instances = {}
        # Before the pointer backends go away: a button still held here would
        # otherwise stay pressed in the desktop with nothing left to release it.
        await self.release_mouse_buttons()
        self.__mouse_disconnect()
        self._disarm_x_event_watcher()
        # Closed, not just dropped: the keyboard shim holds the same Display and
        # python-xlib's root-window back-reference makes the graph a cycle with no
        # finalizer, so a dropped connection keeps its X client slot until a cyclic
        # collection happens to run. Every transport switch builds a new handler.
        old_display, self.xdisplay, self.keyboard = self.xdisplay, None, None
        if old_display is not None:
            try:
                await asyncio.to_thread(old_display.close)
            except Exception as e:
                logger_webrtc_input.debug(f"closing the input X connection failed: {e}")

        if self.keyboard_worker_task:
            self.keyboard_worker_task.cancel()
            self.keyboard_worker_task = None
        if self.key_sweep_task:
            self.key_sweep_task.cancel()
            self.key_sweep_task = None
        if self.key_repeat_task:
            self.key_repeat_task.cancel()
            self.key_repeat_task = None
        if self.keymap_watch_task:
            self.keymap_watch_task.cancel()
            self.keymap_watch_task = None
        self.pressed_keys.clear()
        self.reaped_atomic_keys.clear()
        self.key_repeat_state.clear()
        # Drop any half-received multipart clipboard so a new connection can't inherit it.
        self._reset_multipart_clipboard()

    async def _key_stale_sweep(self):
        """Auto-release keys whose heartbeats stopped (lost key-up), so a key is
        never stuck held when the network drops packets."""
        try:
            while True:
                await asyncio.sleep(self.key_sweep_interval)
                if not self.pressed_keys:
                    continue
                now = time.monotonic()
                stale = [k for k, seen in self.pressed_keys.items() if now - seen > self.key_stale_window]
                for keysym in stale:
                    # Re-check: a heartbeat or re-press during a prior await may
                    # have refreshed this key, so don't release a now-live key.
                    seen = self.pressed_keys.get(keysym)
                    if seen is None or time.monotonic() - seen <= self.key_stale_window:
                        continue
                    was_atomic = keysym in self.atomically_typed_keys
                    self.pressed_keys.pop(keysym, None)
                    self.key_repeat_state.pop(keysym, None)
                    logger_webrtc_input.warning(f"Auto-releasing key {keysym} (heartbeat lost).")
                    # An atomically-typed key was never physically held on X11.
                    if was_atomic and not self.is_wayland:
                        self.atomically_typed_keys.discard(keysym)
                        # Remember it so a late, legit 'ku' is swallowed instead of
                        # injecting a spurious X11 keyup. Bound the set like
                        # pressed_keys so it can't grow without limit.
                        if len(self.reaped_atomic_keys) < self.max_pressed_keys:
                            self.reaped_atomic_keys.add(keysym)
                        continue
                    try:
                        if self.is_wayland:
                            # Wayland injection is serialized through keyboard_queue;
                            # no shared X11 state is touched across an await here.
                            self.active_modifiers.discard(keysym)
                            self.atomically_typed_keys.discard(keysym)
                            self._keyboard_enqueue(("ku", keysym))
                        else:
                            # X11 injection isn't queue-serialized: defer the modifier/atomic
                            # state discard until after the release so a concurrent kd still
                            # sees correct active_modifiers. The keysym was popped above, so a
                            # non-None entry here means a concurrent kd re-pressed it. That kd
                            # already injected its own keydown, so on any re-press we must not
                            # re-inject a down (would double-press); we just abandon our release.
                            if self.pressed_keys.get(keysym) is not None:
                                # kd raced us before the keyup: skip both injections; the kd
                                # owns the key (and its modifier/atomic state) now.
                                continue
                            await self.send_x11_keypress(keysym, down=False)
                            if self.pressed_keys.get(keysym) is not None:
                                # kd raced us during the keyup await: it already re-pressed
                                # the key, so abandon the heal (no down) and leave its
                                # modifier/atomic state intact for the live press.
                                continue
                            self.active_modifiers.discard(keysym)
                            self.atomically_typed_keys.discard(keysym)
                    except Exception as e:
                        logger_webrtc_input.warning(f"Failed to auto-release key {keysym}: {e}")
        except asyncio.CancelledError:
            pass

    async def _key_repeat_loop(self):
        """X11 server-side key auto-repeat for held keys.

        XTEST/xdotool synthetic presses don't trigger the X server's native
        auto-repeat, so without this a held key types a single character. We re-emit the
        most-recently-pressed still-held repeatable key at key_repeat_interval after an
        initial key_repeat_delay -- exactly like a physical keyboard, where only the last
        key pressed repeats and releasing it resumes the previously-held one. Modifiers
        are never armed, so the repeated key carries whatever modifiers are currently
        held (Shift+Arrow selection, Ctrl+Backspace word-delete, Ctrl+Z, etc. all repeat
        like native -- no special shortcut suppression); atomically-typed keys
        (digits/punctuation) are armed and repeat through the atomic path below.
        Repeats are KeyPress-only (no synthetic KeyRelease),
        matching X11 detectable auto-repeat, so state-based games keep the key held with
        no movement stutter and ignore the extra presses. Wayland is excluded (the
        focused app repeats held virtual-keyboard keys itself via wl_keyboard
        repeat_info, so a server-side repeat would double it)."""
        try:
            while True:
                await asyncio.sleep(self.key_repeat_tick)
                if not self.key_repeat_state:
                    continue
                # Drop keys released/reaped since arming (mirrors the stale-sweep race
                # guard, so we never inject a down after the key-up).
                for k in [k for k in self.key_repeat_state if k not in self.pressed_keys]:
                    self.key_repeat_state.pop(k, None)
                if not self.key_repeat_state:
                    continue
                # Only the newest still-held key repeats: key_repeat_state is
                # insertion-ordered and arming moves a key to the end, so the last entry
                # is the most recent. Releasing it lets the previous key resume next tick.
                keysym = next(reversed(self.key_repeat_state))
                now = time.monotonic()
                if now < self.key_repeat_state[keysym]:
                    continue
                # Heartbeats stopped (stalled stream or hidden tab): pause repeat until
                # they resume. The key stays held, bounding run-on to ~grace instead of
                # the whole stale window.
                last_seen = self.pressed_keys.get(keysym)
                if last_seen is None or (now - last_seen) > self.key_repeat_heartbeat_grace:
                    continue
                try:
                    if keysym in self.atomically_typed_keys:
                        # This key was typed once atomically (digit/punctuation) rather
                        # than as a physical KeyPress. Repeat it in-process via XTEST at
                        # the right shift level instead of re-forking `xdotool type` every
                        # tick. A self-contained press+release (not a bare KeyPress) is
                        # used because the 'ku' path injects no key-up for atomic keys, so
                        # a lone press would leave the key stuck down. Fall back to the
                        # co,end path when the keysym has no keycode in the layout or sits
                        # only on an AltGr level.
                        injected = False
                        if self.keyboard is not None:
                            try:
                                # Repeat via the XTEST shim, which resolves the keymap
                                # level and synthesizes Shift/AltGr (and overlay-binds
                                # unmapped keysyms). A self-contained press+release since
                                # the 'ku' path injects no key-up for atomic keys.
                                self.keyboard.press(
                                    keysym,
                                    held_keysyms=(self.active_modifiers
                                                  & self.LEVEL_MODIFIER_KEYSYMS))
                                self.keyboard.release(keysym)
                                injected = True
                            except Exception as e:
                                logger_webrtc_input.debug(
                                    f"XTEST atomic repeat failed for keysym {keysym}; falling back: {e}"
                                )
                                if self._is_x_conn_closed(e):
                                    self._reconnect_xdisplay()
                        if not injected:
                            unicode_codepoint = (keysym & 0x00FFFFFF
                                                 if (keysym & 0xFF000000) == 0x01000000 else keysym)
                            char_to_type = chr(unicode_codepoint)
                            await self.on_message(f"co,end,{char_to_type}")
                    else:
                        await self.send_x11_keypress(keysym, down=True)
                except Exception as e:
                    logger_webrtc_input.warning(f"Key auto-repeat failed for {keysym}: {e}")
                    self.key_repeat_state.pop(keysym, None)
                    continue
                # A 'ku' during the await released the key: stop repeating it (the extra
                # down we just sent is healed by the real key-up / stale-sweep).
                if keysym in self.pressed_keys:
                    self.key_repeat_state[keysym] = time.monotonic() + self.key_repeat_interval
                else:
                    self.key_repeat_state.pop(keysym, None)
        except asyncio.CancelledError:
            pass

    async def reset_keyboard(self):
        if self.is_wayland:
            if self.wayland_input:
                # Release common modifiers
                # Ctrl, Shift, Alt, AltGr, Meta, Super, Hyper (the client maps the
                # Meta/Windows key to Super, so Super must be released here too).
                modifiers = [65507, 65505, 65513, 65508, 65506, 65514, 65027,
                             65511, 65512, 65515, 65516, 65517, 65518]
                owner = self._wl_keymap_owner
                if owner is not None:
                    for k in modifiers:
                        try:
                            owner.release(k)
                        except Exception:
                            pass
                    try:
                        owner.reset()
                    except Exception:
                        pass
            # Release any in-flight translated (Cyrillic) keys before clearing the
            # map, else the injected QWERTY key stays down after reset. The original
            # keysym down=False routes through send_x11_keypress's translation.
            for k in list(self.translated_keys):
                try: await self.send_x11_keypress(k, down=False)
                except Exception: pass
            # Release every still-held key (not just modifiers/hotkeys): a held
            # non-modifier key (e.g. 'w' in a game) would otherwise stay pressed
            # in the compositor forever once pressed_keys is cleared below, since
            # the stale-sweep is the only other releaser and it never runs after
            # the clear. Atomically-typed (single-shot) keys were never physically
            # held, so skip them.
            for keysym in list(self.pressed_keys):
                if keysym in self.atomically_typed_keys:
                    continue
                try: await self.send_x11_keypress(keysym, down=False)
                except Exception as e: logger_webrtc_input.warning(f"Error releasing held key {keysym}: {e}")
            # Clear server-side key state so a reset can't leave stuck-modifier desync.
            self.active_modifiers.clear()
            self.active_shortcut_modifiers.clear()
            self.atomically_typed_keys.clear()
            self.translated_keys.clear()
            # Drop heartbeat-tracked keys too; otherwise the stale-sweep would
            # auto-release a key the reset just cleared (mirrors disconnect()).
            self.pressed_keys.clear()
            self.reaped_atomic_keys.clear()
            # X11 parity: normalize a stuck Lock. The client resolves letter case
            # itself (XK_a vs XK_A), so an engaged compositor Caps Lock inverts
            # every letter. get_keyboard_state mods bit 4 is caps_lock; toggle it
            # off with a virtual Caps_Lock press+release (keysym 0xffe5).
            try:
                if self.wayland_input and hasattr(self.wayland_input, 'get_keyboard_state'):
                    _pressed, mods = self.wayland_input.get_keyboard_state()
                    if mods & 0x10:
                        keymap_owner = self._wl_keymap_owner
                        if keymap_owner is not None:
                            keymap_owner.press(0xffe5)
                            await asyncio.sleep(0.02)
                            keymap_owner.release(0xffe5)
            except Exception as e:
                logger_webrtc_input.debug(f"Wayland caps-lock normalization skipped: {e}")
            return

        if not self.keyboard or not self.xdisplay :
            logger_webrtc_input.warning("Cannot reset keyboard, X display or keyboard controller not available.")
            return
        logger_webrtc_input.info("Resetting keyboard modifiers.")
        lctrl, lshift, lalt, altgr = 65507, 65505, 65513, 65027
        rctrl, rshift, ralt = 65508, 65506, 65514
        lmeta, rmeta, keyf, keyF, keym, keyM, escape = 65511, 65512, 102, 70, 109, 77, 65307
        # Super/Hyper included: the client maps the Meta/Windows key to Super.
        lsuper, rsuper, lhyper, rhyper = 65515, 65516, 65517, 65518
        for k in [lctrl, lshift, lalt, altgr, rctrl, rshift, ralt, lmeta, rmeta,
                  lsuper, rsuper, lhyper, rhyper, keyf, keyF, keym, keyM, escape]:
            try: await self.send_x11_keypress(k, down=False)
            except Exception as e: logger_webrtc_input.warning(f"Error resetting key {k}: {e}")
        # Release every still-held key, not just the modifier/hotkey list above: a
        # held non-modifier key (e.g. 'w' in a game) would otherwise stay pressed in
        # the X server forever once pressed_keys is cleared below (the stale-sweep,
        # the only other releaser, never runs after the clear). Atomically-typed
        # (single-shot, non-alpha) keys were never physically held on X11, so skip
        # them to avoid a spurious keyup.
        for keysym in list(self.pressed_keys):
            if keysym in self.atomically_typed_keys:
                continue
            try: await self.send_x11_keypress(keysym, down=False)
            except Exception as e: logger_webrtc_input.warning(f"Error releasing held key {keysym}: {e}")
        # Release any in-flight translated (Cyrillic) keys before clearing the map,
        # else the injected QWERTY key stays physically down after reset. Passing the
        # original keysym down=False makes send_x11_keypress emit the translated keyup.
        for k in list(self.translated_keys):
            try: await self.send_x11_keypress(k, down=False)
            except Exception as e: logger_webrtc_input.warning(f"Error releasing translated key {k}: {e}")
        # Normalize a stuck Lock (Caps Lock) modifier. The client resolves letter
        # case itself and sends the final keysym (XK_a vs XK_A), so an engaged
        # server Lock inverts every letter — typing uppercase, with Shift yielding
        # lowercase. CapsLock is not forwarded from the browser, but a prior session
        # or the desktop's own startup can leave Lock engaged; toggle it back off.
        try:
            if self.xdisplay.screen().root.query_pointer().mask & Xlib.X.LockMask:
                caps_kc = self.xdisplay.keysym_to_keycode(0xffe5)
                if caps_kc:
                    xtest.fake_input(self.xdisplay, Xlib.X.KeyPress, caps_kc)
                    xtest.fake_input(self.xdisplay, Xlib.X.KeyRelease, caps_kc)
                    self.xdisplay.flush()
        except Exception as e:
            logger_webrtc_input.warning(f"Could not normalize Lock modifier: {e}")
        # Clear server-side key state (after the release loop consumes it) to avoid stuck-modifier desync.
        self.active_modifiers.clear()
        self.active_shortcut_modifiers.clear()
        self.atomically_typed_keys.clear()
        self.translated_keys.clear()
        # Drop heartbeat-tracked keys too; otherwise the stale-sweep would
        # auto-release a key the reset just cleared (mirrors disconnect()).
        self.pressed_keys.clear()
        self.reaped_atomic_keys.clear()
        self.key_repeat_state.clear()

    async def release_mouse_buttons(self):
        """Release every pointer button still held server-side.

        The ungraceful pointer path, mirroring release_gamepads_for_conn and the
        key stale-sweep: a client that dies mid-drag never sends the mask with the
        button cleared, so the desktop would keep the drag or selection alive until
        some future client happens to diff the bit away. The releases ride the
        normal mask-diff loop, so X11 and Wayland both heal; the zero-delta
        relative move leaves the pointer exactly where it is (and injects no motion
        at all on Wayland)."""
        if not self.button_mask:
            return
        try:
            await self.send_x11_mouse(0, 0, 0, 0, relative=True)
        except Exception as e:
            logger_webrtc_input.warning(f"Failed to release held mouse buttons: {e}")

    def send_mouse(self, action, data):
        if action == MOUSE_POSITION:
            if self.mouse: self.mouse.position = data
        elif action == MOUSE_MOVE:
            x, y = data
            if self.uinput_mouse_socket_path:
                self.__mouse_emit(UINPUT_REL_X, x, syn=False)
                self.__mouse_emit(UINPUT_REL_Y, y)
            elif self.xdisplay:
                xtest.fake_input(self.xdisplay, Xlib.X.MotionNotify, detail=True, root=Xlib.X.NONE, x=x, y=y)
                # flush() (send, no round-trip) suffices — XTEST needs no reply; sync()
                # would add a blocking server round-trip on every mouse move.
                self.xdisplay.flush()
        elif action == MOUSE_SCROLL_UP:
            # The XTest/Wayland backends (the defaults) map this action to a physical
            # wheel-DOWN (button 5 / REL_WHEEL -1) — the MOUSE_SCROLL_* constants are
            # named for the client button, not the physical direction. uinput must
            # match, so REL_WHEEL is -1 here, not +1 (which scrolled the wrong way).
            if self.uinput_mouse_socket_path: self.__mouse_emit(UINPUT_REL_WHEEL, -1)
            elif self.mouse: self.mouse.scroll(0, -1)
        elif action == MOUSE_SCROLL_DOWN:
            if self.uinput_mouse_socket_path: self.__mouse_emit(UINPUT_REL_WHEEL, 1)
            elif self.mouse: self.mouse.scroll(0, 1)
        elif action == MOUSE_SCROLL_LEFT:
            # Horizontal wheel goes through the same device as the vertical one.
            # REL_HWHEEL is signed the way the client names it (negative = left),
            # matching X core buttons 6/7, so no direction flip is needed here.
            if self.uinput_mouse_socket_path: self.__mouse_emit(UINPUT_REL_HWHEEL, -1)
            elif self.mouse: self.mouse.scroll(-1, 0)
        elif action == MOUSE_SCROLL_RIGHT:
            if self.uinput_mouse_socket_path: self.__mouse_emit(UINPUT_REL_HWHEEL, 1)
            elif self.mouse: self.mouse.scroll(1, 0)
        elif action == MOUSE_BUTTON: 
            btn_map_key = "uinput" if self.uinput_mouse_socket_path else "x11"
            btn_uinput_or_x11 = MOUSE_BUTTON_MAP[data[1]][btn_map_key]
            if data[0] == MOUSE_BUTTON_PRESS:
                if self.uinput_mouse_socket_path: self.__mouse_emit(btn_uinput_or_x11, 1)
                elif self.mouse: self.mouse.press(btn_uinput_or_x11)
            else:
                if self.uinput_mouse_socket_path: self.__mouse_emit(btn_uinput_or_x11, 0)
                elif self.mouse: self.mouse.release(btn_uinput_or_x11)

    async def send_x11_keypress(self, keysym, down=True):
        if down:
            if (self.active_modifiers & self.ACTION_MODIFIER_KEYSYMS) and keysym in CYRILLIC_TO_QWERTY_KEYSYM:
                self.translated_keys.add(keysym)
                keysym = CYRILLIC_TO_QWERTY_KEYSYM[keysym]
        else:
            if keysym in self.translated_keys:
                self.translated_keys.discard(keysym)
                keysym = CYRILLIC_TO_QWERTY_KEYSYM[keysym]

        # A conflicting client-held Shift/AltGr is lifted around plain
        # keystrokes only: while a chord modifier (Ctrl/Alt/Super/...) is down,
        # every held modifier is part of the chord and must pass through.
        neutralize = (keysym not in self.MODIFIER_KEYSYMS
                      and not (self.active_modifiers & self.ACTION_MODIFIER_KEYSYMS))
        held_level_mods = frozenset(self.active_modifiers & self.LEVEL_MODIFIER_KEYSYMS)

        if self.is_wayland and self.wayland_input:
            # Wayland keymap contract: selkies owns keysym policy; the compositor
            # exposes only inject_key + set_keymap_string. Layout keys resolve with
            # Shift/AltGr synthesis; anything the layout lacks — the Unicode plane,
            # Euro, IME output — binds to a dynamic overlay keycode. Every keysym
            # flows ordered through the one compositor channel; the
            # virtual-keyboard/clipboard paths below are error fallbacks.
            owner = await self._ensure_wayland_keymap_owner()
            if owner is not None:
                try:
                    if down:
                        owner.press(keysym, neutralize=neutralize)
                    else:
                        owner.release(keysym)
                    return
                except Exception as e:
                    logger_webrtc_input.warning(
                        f"Wayland keymap injection failed for keysym {keysym}; falling back: {e}"
                    )
            await self._type_keysym_fallback(keysym, down)
            return

        is_printable = (0x20 <= keysym <= 0xFF) or ((keysym & 0xFF000000) == 0x01000000)
        action = "keydown" if down else "keyup"
        command = None
        use_keyboard_for_printable = False
        # Whether this keysym may be injected via in-process XTEST instead of a
        # per-event xdotool fork. Not eligible for the --clearmodifiers case (XTEST
        # can't force the base keysym while a modifier is held), so that stays on
        # xdotool below.
        allow_xtest = False
        if is_printable:
            unicode_codepoint = keysym & 0x00FFFFFF if (keysym & 0xFF000000) == 0x01000000 else keysym
            try:
                char = chr(unicode_codepoint)
                if char.isalpha():
                    use_keyboard_for_printable = True
                else:
                    xdotool_arg = f"U{unicode_codepoint:04X}"
                    if not self.active_shortcut_modifiers:
                        # Type via in-process XTEST, which resolves the keymap level and
                        # synthesizes Shift/AltGr as needed -- no per-character xdotool
                        # fork (and no silent drop when a fork fails). Falls back to
                        # xdotool below if the keysym can't be resolved.
                        use_keyboard_for_printable = True
                    else:
                        command = ["xdotool", action, xdotool_arg]
                        allow_xtest = True
            except ValueError:
                use_keyboard_for_printable = True

        else:
            map_entry = X11_KEYSYM_MAP.get(keysym)
            if map_entry:
                xdotool_arg = map_entry.get('xkey_name')
                if xdotool_arg:
                    command = ["xdotool", action, xdotool_arg]
                    allow_xtest = True
                    if xdotool_arg in self.SHORTCUT_MODIFIER_XKEY_NAMES:
                        if down:
                            self.active_shortcut_modifiers.add(xdotool_arg)
                        else:
                            self.active_shortcut_modifiers.discard(xdotool_arg)

        if command:
            # Fast path: for keysyms that resolve to a keycode in the current keymap,
            # inject directly through the already-open display via XTEST. This avoids a
            # ~15ms xdotool subprocess fork on every shortcut/arrow/function key. Falls
            # through to the xdotool subprocess below when there is no keycode (e.g. a
            # keysym absent from the current layout that xdotool can still synthesize).
            if allow_xtest and xtest is not None and self.xdisplay is not None:
                try:
                    keycode = self.xdisplay.keysym_to_keycode(keysym)
                    if keycode:
                        xtest.fake_input(
                            self.xdisplay,
                            X.KeyPress if down else X.KeyRelease,
                            keycode,
                        )
                        self.xdisplay.flush()
                        return
                    if self.keyboard:
                        # In the map but not in the current layout (e.g. Cyrillic
                        # keysyms on a US keymap): the shim overlay-binds it once
                        # and reuses the binding — never a per-key xdotool fork,
                        # whose transient rebind floods MappingNotify and lags
                        # the whole input queue behind real typing.
                        if down:
                            self.keyboard.press(keysym, neutralize=neutralize,
                                                held_keysyms=held_level_mods)
                        else:
                            self.keyboard.release(keysym)
                        return
                except Exception as e:
                    logger_webrtc_input.debug(
                        f"XTEST inject failed for keysym {keysym}; falling back to xdotool: {e}"
                    )
            try:
                process = await subprocess.create_subprocess_exec(
                    *command, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                await self._communicate_or_kill(process, 0.5, "xdotool key")
                if process.returncode == 0:
                    return
                logger_webrtc_input.warning(
                    f"xdotool {action} failed (rc={process.returncode}) for keysym {keysym}")
            except Exception:
                pass

        if use_keyboard_for_printable or not command:
            try:
                if not self.keyboard:
                    await self._type_keysym_fallback(keysym, down)
                    return

                # Inject the printable keysym through the bundled Xlib XTEST
                # keyboard shim; on an unmapped keysym it raises and we fall
                # back to xdotool below.
                if down:
                    self.keyboard.press(keysym, neutralize=neutralize,
                                        held_keysyms=held_level_mods)
                else:
                    self.keyboard.release(keysym)
            except Exception as e:
                if self._is_x_conn_closed(e):
                    self._reconnect_xdisplay()
                await self._type_keysym_fallback(keysym, down)

    def _type_text_xtest(self, text, neutralize=False):
        """Type a string in-process via the XTEST shim: each char as a press+release
        of its keysym (mapped -> shift-synthesized; unmapped -> spare-keycode
        overlay). With neutralize, conflicting held Shift/AltGr are lifted around
        the whole run (one keymap query, not one per char). Returns True on full
        success, False (having typed nothing) if the shim is unavailable or any
        char can't be resolved, so the caller can fall back to xdotool without
        double-typing."""
        if not self.keyboard or not text:
            return False
        # Pre-resolve every char so a mid-string failure doesn't type a partial line.
        keysyms = []
        for ch in text:
            cp = ord(ch)
            keysyms.append(cp if 0x20 <= cp <= 0xFF else (0x01000000 | cp))
        try:
            # One batched bind for every unmapped char (O(1) MappingNotify
            # broadcasts instead of one per char); nothing typed on failure.
            if not self.keyboard.prebind(keysyms):
                return False
            lifted = []
            if neutralize:
                down = self.keyboard._down_mod_keycodes(
                    self.active_modifiers & self.LEVEL_MODIFIER_KEYSYMS)
                lifted = self.keyboard._mods_to_lift(set(), down)
            for m in lifted:
                xtest.fake_input(self.keyboard._d, Xlib.X.KeyRelease, m)
            try:
                for ks in keysyms:
                    self.keyboard.press(ks)
                    self.keyboard.release(ks)
            finally:
                for m in reversed(lifted):
                    xtest.fake_input(self.keyboard._d, Xlib.X.KeyPress, m)
                if lifted:
                    self.keyboard._d.flush()
            return True
        except Exception as e:
            logger_webrtc_input.debug(f"in-process type failed ({e}); falling back to xdotool")
            return False


    def _spawn_task(self, coro, name=None):
        """create_task with a keep-alive reference and error logging."""
        task = asyncio.create_task(coro, name=name)
        self._bg_tasks.add(task)

        def _done(t):
            self._bg_tasks.discard(t)
            if not t.cancelled() and t.exception() is not None:
                logger_webrtc_input.error(f"Background task {t.get_name()} failed: {t.exception()}")

        task.add_done_callback(_done)
        return task

    async def _push_wayland_base_layout(self):
        """Set the compositor seat's BASE xkb layout at session start from the
        deployment's XKB env config (XKB_DEFAULT_LAYOUT et al.), so common
        non-US keysyms resolve as base keys instead of overlay binds. The
        compositor re-splices its overlay binds on top with unchanged keycodes;
        the keymap owner is dropped so it rebuilds from the new base."""
        layout = os.environ.get("XKB_DEFAULT_LAYOUT", "")
        setter = getattr(self.wayland_input, 'set_xkb_layout', None)
        if not layout or setter is None:
            return
        variant = os.environ.get("XKB_DEFAULT_VARIANT", "")
        options = os.environ.get("XKB_DEFAULT_OPTIONS", "")
        model = os.environ.get("XKB_DEFAULT_MODEL", "")
        rules = os.environ.get("XKB_DEFAULT_RULES", "")
        try:
            ok = await asyncio.to_thread(
                setter, layout, variant, options, model, rules)
        except Exception as e:
            logger_webrtc_input.warning(f"Wayland base layout push failed: {e}")
            return
        if ok:
            self._wl_keymap_owner = None
            logger_webrtc_input.info(
                f"Wayland base layout set to '{layout}'"
                + (f" ({variant})" if variant else ""))
        else:
            logger_webrtc_input.warning(
                f"Wayland base layout '{layout}' rejected by the compositor; "
                "keeping the default.")

    async def apply_client_keyboard_layout(self, layout_hint):
        """Client SETTINGS 'keyboardLayout' hint ("de", "ch(fr)", ...). On
        pixelflux Wayland it becomes the compositor seat's BASE xkb layout
        (set_xkb_layout), so the client's physical layout resolves as base keys
        instead of per-keysym overlay binds; on X11 it is informational only
        (the X keymap is deployment-owned). Idempotent per value — clients
        re-assert SETTINGS on reconnects and broadcasts."""
        hint = str(layout_hint or "").strip()
        m = re.fullmatch(r"([A-Za-z0-9_,\- ]{1,32})(?:\(([A-Za-z0-9_,\- ]{1,32})\))?", hint)
        if not m:
            if hint:
                logger_webrtc_input.warning(
                    f"Ignoring malformed keyboardLayout hint: {hint[:48]!r}")
            return
        if hint == self._client_kb_layout:
            return
        layout, variant = m.group(1).strip(), (m.group(2) or "").strip()
        if not self.is_wayland:
            self._client_kb_layout = hint
            logger_webrtc_input.info(
                f"Client keyboard layout hint '{hint}' noted (X11 keymap is "
                "deployment-owned; not applied).")
            return
        setter = getattr(self.wayland_input, 'set_xkb_layout', None) if self.wayland_input else None
        if setter is None:
            logger_webrtc_input.warning(
                f"Client keyboard layout '{hint}' not applied: compositor "
                "keymap control unavailable.")
            return
        try:
            ok = await asyncio.to_thread(setter, layout, variant, "", "", "")
        except Exception as e:
            logger_webrtc_input.warning(f"Wayland base layout push failed: {e}")
            return
        if ok:
            self._client_kb_layout = hint
            # The keymap owner caches keycode resolution against the old base;
            # drop it so it rebuilds from the new one.
            self._wl_keymap_owner = None
            logger_webrtc_input.info(
                f"Wayland base layout set to '{layout}'"
                + (f" ({variant})" if variant else "") + " from client hint")
        else:
            logger_webrtc_input.warning(
                f"Wayland base layout '{hint}' rejected by the compositor; "
                "keeping the current layout.")

    async def _ensure_wayland_keymap_owner(self):
        """Get-or-build the keymap owner. Reading the compositor keymap blocks
        (bounded) and compiling it costs milliseconds, so both run off the loop;
        after that, press/release are sync dict work + channel sends."""
        if self._wl_keymap_owner is not None:
            return self._wl_keymap_owner
        if not hasattr(self.wayland_input, 'set_keymap_string'):
            return None
        now = time.monotonic()
        if now < self._wl_keymap_retry_at:
            return None
        async with self._wl_keymap_owner_lock:
            if self._wl_keymap_owner is not None:
                return self._wl_keymap_owner
            loop = asyncio.get_running_loop()
            try:
                def _build():
                    text = self.wayland_input.get_xkb_keymap_string()
                    return _WaylandKeymapOwner(self.wayland_input, text)
                self._wl_keymap_owner = await loop.run_in_executor(None, _build)
                logger_webrtc_input.info(
                    f"Wayland keymap owner ready ({len(self._wl_keymap_owner._map)} keysyms).")
            except Exception as e:
                self._wl_keymap_retry_at = time.monotonic() + 5.0
                logger_webrtc_input.warning(
                    f"Wayland keymap owner unavailable ({e}); retrying in 5s.")
            return self._wl_keymap_owner

    async def _wl_type_text(self, text):
        """Inject text through the app compositor's zwp_virtual_keyboard_manager_v1
        via pixelflux's one-shot in-process client: the first fallback rung under
        the seat keymap, above the clipboard paste. Raises when the compositor
        lacks the protocol or the injection fails, so callers can drop to the
        next rung the same way they would on any injection error."""
        async with self._wl_typer_lock:
            if time.monotonic() < self._wl_typer_retry_at:
                raise RuntimeError(
                    "compositor does not advertise zwp_virtual_keyboard_manager_v1"
                    " (retry pending)")
            display = self._app_wayland_display()
            try:
                typer = getattr(self.wayland_input, 'type_keysyms_wayland', None)
                if typer is not None:
                    await asyncio.get_running_loop().run_in_executor(
                        None, typer, display, text_to_wayland_keysyms(text))
                else:
                    await asyncio.get_running_loop().run_in_executor(
                        None, self.wayland_input.type_text_wayland, display, text)
            except PixelfluxVkUnavailable:
                self._wl_typer_retry_at = time.monotonic() + 30.0
                raise
            except Exception:
                if self._app_wl_is_separate:
                    # The socket is unreachable (an auto-detected app compositor
                    # died or restarted on a different name); re-detect next time
                    # rather than keep aiming at a dead socket.
                    self._invalidate_app_wl_display()
                raise

    async def _inject_text_via_clipboard(self, text):
        """Type `text` by replacing the clipboard with it, pasting via
        Shift+Insert, and restoring what was copied before. The route for
        compositors with no zwp_virtual_keyboard (KWin): the chord's two
        keysyms exist in every base layout, so this needs nothing beyond the
        data-control clipboard and ordinary key events. Held modifiers are
        lifted around the chord so they cannot corrupt the paste, and
        write_clipboard's baseline keeps the monitor from echoing the injected
        text back to clients. Returns True once the paste chord is sent."""
        if self._clipboard_inject_active:
            return False
        async with self._clipboard_inject_lock:
            self._clipboard_inject_active = True
            shift_keysym = 0xFFE1
            insert_keysym = 0xFF63
            held_modifiers = list(self.active_modifiers)
            try:
                for mod_keysym in held_modifiers:
                    await self.send_x11_keypress(mod_keysym, down=False)
                old_data, old_mime = await self.read_clipboard(use_binary=True)
                if not await self.write_clipboard(text):
                    return False
                # The write returns with the selection taken; the sleeps are the
                # margins for the focused app to receive the new offer and to
                # finish fetching the payload before the selection is restored.
                await asyncio.sleep(0.02)
                await self.send_x11_keypress(shift_keysym, down=True)
                await self.send_x11_keypress(insert_keysym, down=True)
                await self.send_x11_keypress(insert_keysym, down=False)
                await self.send_x11_keypress(shift_keysym, down=False)
                await asyncio.sleep(0.05)
                if old_data is not None:
                    await self.write_clipboard(old_data, old_mime or "text/plain")
                elif self.is_wayland:
                    await self._clear_injected_clipboard()
                return True
            except Exception as e:
                logger_webrtc_input.error(f"Clipboard text injection failed: {e}")
                return False
            finally:
                for mod_keysym in held_modifiers:
                    if mod_keysym in self.active_modifiers:
                        await self.send_x11_keypress(mod_keysym, down=True)
                self._clipboard_inject_active = False

    async def _clear_injected_clipboard(self):
        """Drop the selection the injection left behind when there was nothing
        to restore (an empty clipboard stays empty for the user)."""
        try:
            if self._has_separate_app_compositor():
                clear_fn = getattr(self.wayland_input, 'clipboard_clear_app', None)
                if clear_fn is not None:
                    await asyncio.get_running_loop().run_in_executor(
                        None, clear_fn, self._app_wayland_display())
            else:
                self.wayland_input.set_clipboard("text/plain", b"")
        except Exception as e:
            logger_webrtc_input.debug(f"post-injection clipboard clear failed: {e}")

    async def _type_keysym_fallback(self, keysym_number, down=True):
        """Deliver a keysym the primary injector could not, resolving the newest
        mechanism first and degrading rung by rung. Wayland is subprocess-free:
        the keysym becomes text and goes through the in-process virtual-keyboard
        client, then the clipboard paste. X11 falls from the in-process XTEST
        shim to an xdotool key, then an xdotool type of the plain character."""
        if self.is_wayland:
            if not down:
                return
            char_to_type = keysym_to_character(keysym_number)

            if char_to_type:
                try:
                    await self._wl_type_text(char_to_type)
                except Exception as e:
                    if not await self._inject_text_via_clipboard(char_to_type):
                        logger_webrtc_input.warning(f"virtual-keyboard fallback failed: {e}")

            return

        if not self.xdisplay:
            return

        xdotool_key_arg = None
        char_for_type_cmd_fallback = None
        keysym_name_from_xlib = None

        if (keysym_number & 0xFF000000) == 0x01000000:
            unicode_codepoint = keysym_number & 0x00FFFFFF
            if 0 <= unicode_codepoint <= 0x10FFFF:
                xdotool_key_arg = f"U{unicode_codepoint:04X}"
                try:
                    char_for_type_cmd_fallback = chr(unicode_codepoint)
                except ValueError:
                    pass
            else:
                return
        else:
            keysym_name_from_xlib = XK.keysym_to_string(keysym_number)

            if keysym_name_from_xlib is None:
                # A keysym is only a codepoint in the Latin-1 range; beyond it
                # the number means nothing as a character, so the keysym is
                # DECODED (legacy planes included) rather than chr()'d — the
                # latter typed Gujarati for the publishing block.
                char = keysym_to_character(keysym_number)
                if char is None:
                    return
                keysym_name_from_xlib = char
                char_for_type_cmd_fallback = char
            else:
                if len(keysym_name_from_xlib) == 1:
                    char_for_type_cmd_fallback = keysym_name_from_xlib
            
            xdotool_key_arg = keysym_name_from_xlib

            if len(keysym_name_from_xlib) == 1:
                char_code = ord(keysym_name_from_xlib)
                if char_code >= 0x80 or (char_code == keysym_number and char_code != 0x00):
                    xdotool_key_arg = f"U{char_code:04X}"
            # XK_sterling.
            elif keysym_number == 0x00a3:
                xdotool_key_arg = "sterling"
                if not char_for_type_cmd_fallback:
                    try: char_for_type_cmd_fallback = chr(0xA3)
                    except ValueError: pass

        if xdotool_key_arg is None:
            return

        action = "keydown" if down else "keyup"
        command_key = ["xdotool", action, xdotool_key_arg]

        try:
            process_key = await subprocess.create_subprocess_exec(
                *command_key,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout_key, stderr_key = await self._communicate_or_kill(process_key, 1.0, "xdotool keydown")
            if process_key.returncode != 0 or (stderr_key and (b"No such key name" in stderr_key or b"Error:" in stderr_key.lower())):
                char_to_type = char_for_type_cmd_fallback
                if not char_to_type and keysym_name_from_xlib and len(keysym_name_from_xlib) == 1:
                    char_to_type = keysym_name_from_xlib
                
                if down and char_to_type and (0x20 <= ord(char_to_type) <= 0x7E or ord(char_to_type) >= 0xA0) and char_to_type.isprintable():
                    command_type = ["xdotool", "type", "--clearmodifiers", char_to_type]
                    try:
                        process_type = await subprocess.create_subprocess_exec(
                            *command_type,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE
                        )
                        await self._communicate_or_kill(process_type, 1.0, "xdotool type")
                    except (asyncio.TimeoutError, FileNotFoundError, Exception):
                        pass
        except (FileNotFoundError, asyncio.TimeoutError, Exception):
            pass

    async def send_x11_mouse(self, x, y, button_mask, scroll_magnitude, relative=False, display_id='primary'):
        # Clamp client-controlled magnitude so the X11 scroll loop can't block the event loop (DoS).
        try:
            scroll_magnitude = max(0, min(int(scroll_magnitude), 64))
        except (TypeError, ValueError):
            scroll_magnitude = 0
        # A pen eraser arrives as Pointer Events button 5. Neither the X11 core
        # pointer nor wl_pointer has an eraser button, so fold it into the primary
        # button: eraser contact clicks and drags like the pen tip instead of
        # injecting nothing. OR-ing it (rather than giving it its own button)
        # keeps press/release balanced if the tip bit is set at the same time.
        if button_mask & MOUSE_MASK_BIT_ERASER:
            button_mask = (button_mask | MOUSE_MASK_BIT_PRIMARY) & ~MOUSE_MASK_BIT_ERASER
        if relative:
            final_x = self.last_x + x
            final_y = self.last_y + y
        else:
            offset_x = 0
            offset_y = 0
            if self.data_server_instance and hasattr(self.data_server_instance, 'display_layouts'):
                # Sockets with no registered display (shared viewers, input
                # handoff) render the primary stream: map them with the
                # primary's offset, which is non-zero in left/up arrangements.
                lookup_id = display_id or 'primary'
                layout = self.data_server_instance.display_layouts.get(lookup_id)
                if layout:
                    offset_x = layout.get('x', 0)
                    offset_y = layout.get('y', 0)
                elif lookup_id != 'primary':
                    # A secondary with no laid-out region (layout pending, or the
                    # extension was refused) must not inject at a zero offset:
                    # its clicks would land on the primary's region instead. A
                    # button it left held self-heals on the next mask diff from
                    # any other display's mouse message.
                    return
            final_x = x + offset_x
            final_y = y + offset_y

        position_changed = (final_x != self.last_x or final_y != self.last_y)
        self.last_x = final_x
        self.last_y = final_y

        if self.wayland_input:
            is_static_relative = relative and (x == 0 and y == 0)
            
            if not is_static_relative:
                if relative:
                    if hasattr(self.wayland_input, 'inject_relative_mouse_move'):
                        self.wayland_input.inject_relative_mouse_move(float(x), float(y))
                    else:
                        self.wayland_input.inject_mouse_move(float(final_x), float(final_y))
                else:
                    self.wayland_input.inject_mouse_move(float(final_x), float(final_y))
            
            if button_mask != self.button_mask:
                for bit_index in range(8):
                    current_button_bit_value = (1 << bit_index)
                    button_state_changed = ((self.button_mask & current_button_bit_value) != \
                                            (button_mask & current_button_bit_value))

                    if button_state_changed:
                        is_pressed_now = (button_mask & current_button_bit_value) != 0
                        state = 1 if is_pressed_now else 0
                        mag = float(max(1, scroll_magnitude))

                        # Left.
                        if bit_index == 0:
                            self.wayland_input.inject_mouse_button(272, state)
                        # Middle.
                        elif bit_index == 1:
                            self.wayland_input.inject_mouse_button(274, state)
                        # Right.
                        elif bit_index == 2:
                            self.wayland_input.inject_mouse_button(273, state)
                        
                        elif bit_index == 3:
                            if scroll_magnitude > 0:
                                if is_pressed_now:
                                    self.wayland_input.inject_mouse_scroll(0.0, 10.0 * mag)
                            else:
                                if is_pressed_now:
                                    # Back: Alt+Left must queue behind any pending
                                    # keys like every other key event (direct
                                    # injection could interleave between a queued
                                    # kd and its ku and produce stray chords).
                                    self._keyboard_enqueue_chord((
                                        (KEYSYM_ALT_L, True), (KEYSYM_LEFT_ARROW, True),
                                        (KEYSYM_LEFT_ARROW, False), (KEYSYM_ALT_L, False)))

                        elif bit_index == 4:
                            if scroll_magnitude > 0:
                                if is_pressed_now:
                                    self.wayland_input.inject_mouse_scroll(0.0, -10.0 * mag)
                            else:
                                if is_pressed_now:
                                    # Forward: Alt+Right, same queue ordering.
                                    self._keyboard_enqueue_chord((
                                        (KEYSYM_ALT_L, True), (KEYSYM_RIGHT_ARROW, True),
                                        (KEYSYM_RIGHT_ARROW, False), (KEYSYM_ALT_L, False)))

                        elif bit_index == 6:
                            if scroll_magnitude > 0 and is_pressed_now:
                                self.wayland_input.inject_mouse_scroll(-10.0 * mag, 0.0)
                        elif bit_index == 7:
                            if scroll_magnitude > 0 and is_pressed_now:
                                self.wayland_input.inject_mouse_scroll(10.0 * mag, 0.0)

            self.button_mask = button_mask
            return
        if relative:
            self.send_mouse(MOUSE_MOVE, (x, y))
        elif position_changed or button_mask != self.button_mask:
            # Button transitions warp unconditionally: the X pointer may have
            # been moved by an application/tool since the last event, and a
            # press must land where the client aims, not where the pointer sits.
            self.send_mouse(MOUSE_POSITION, (final_x, final_y))
        self.last_x = final_x
        self.last_y = final_y
        if button_mask != self.button_mask:
            for bit_index in range(8):
                current_button_bit_value = (1 << bit_index)
                button_state_changed = ((self.button_mask & current_button_bit_value) != \
                                        (button_mask & current_button_bit_value))

                if button_state_changed:
                    is_pressed_now = (button_mask & current_button_bit_value) != 0
                    
                    action_to_send = None
                    data_to_send = None
                    is_scroll_action = False
                    performed_keyboard_combo = False 

                    if bit_index == 0:
                        action_to_send = MOUSE_BUTTON
                        data_to_send = (MOUSE_BUTTON_PRESS if is_pressed_now else MOUSE_BUTTON_RELEASE, MOUSE_BUTTON_LEFT_ID)
                    elif bit_index == 1:
                        action_to_send = MOUSE_BUTTON
                        data_to_send = (MOUSE_BUTTON_PRESS if is_pressed_now else MOUSE_BUTTON_RELEASE, MOUSE_BUTTON_MIDDLE_ID)
                    elif bit_index == 2:
                        action_to_send = MOUSE_BUTTON
                        data_to_send = (MOUSE_BUTTON_PRESS if is_pressed_now else MOUSE_BUTTON_RELEASE, MOUSE_BUTTON_RIGHT_ID)
                    
                    elif bit_index == 3:
                        if scroll_magnitude > 0:
                            if is_pressed_now:
                                action_to_send = MOUSE_SCROLL_UP
                                is_scroll_action = True
                        else:
                            if is_pressed_now:
                                if self.keyboard:
                                    logger_webrtc_input.debug("Sending Alt+Left Arrow for Back")
                                    await self.send_x11_keypress(KEYSYM_ALT_L, down=True)
                                    await self.send_x11_keypress(KEYSYM_LEFT_ARROW, down=True)
                                    await self.send_x11_keypress(KEYSYM_LEFT_ARROW, down=False)
                                    await self.send_x11_keypress(KEYSYM_ALT_L, down=False)
                                    performed_keyboard_combo = True
                                else:
                                    logger_webrtc_input.warning("Keyboard not available for Alt+Left.")
                    elif bit_index == 4:
                        if scroll_magnitude > 0:
                            if is_pressed_now:
                                action_to_send = MOUSE_SCROLL_DOWN
                                is_scroll_action = True
                        else:
                            if is_pressed_now:
                                if self.keyboard:
                                    logger_webrtc_input.debug("Sending Alt+Right Arrow for Forward")
                                    await self.send_x11_keypress(KEYSYM_ALT_L, down=True)
                                    await self.send_x11_keypress(KEYSYM_RIGHT_ARROW, down=True)
                                    await self.send_x11_keypress(KEYSYM_RIGHT_ARROW, down=False)
                                    await self.send_x11_keypress(KEYSYM_ALT_L, down=False)
                                    performed_keyboard_combo = True
                                else:
                                    logger_webrtc_input.warning("Keyboard not available for Alt+Right.")
                    elif bit_index == 6:
                        if scroll_magnitude > 0 and is_pressed_now:
                            action_to_send = MOUSE_SCROLL_LEFT
                            is_scroll_action = True
                    elif bit_index == 7:
                        if scroll_magnitude > 0 and is_pressed_now:
                            action_to_send = MOUSE_SCROLL_RIGHT
                            is_scroll_action = True
                    if not performed_keyboard_combo and action_to_send is not None:
                        if is_scroll_action:
                            for _ in range(max(1, scroll_magnitude)):
                                self.send_mouse(action_to_send, None)
                        else:
                            self.send_mouse(action_to_send, data_to_send)
                
            self.button_mask = button_mask

        if not relative and self.xdisplay:
            # flush() (send, no round-trip) suffices for the injected events; sync()
            # would add a blocking server round-trip per mouse event.
            self.xdisplay.flush()
    async def update_binary_clipboard_setting(self, enabled: bool):
        """Asynchronously updates the binary clipboard setting and restarts the monitor if it's running."""
        # Hold the lock across the whole check+cancel+reassign: the await on task
        # cancellation is a suspension point, so without serialization two rapid
        # differing toggles can both pass the early-return and spawn duplicate monitors.
        async with self._binary_clipboard_lock:
            new_setting_str = "true" if enabled else "false"
            if self.enable_binary_clipboard == new_setting_str:
                return
            logger_webrtc_input.info(f"Binary clipboard setting changing to: {enabled}. Restarting monitor.")
            self.enable_binary_clipboard = new_setting_str
            if self.clipboard_monitor_task and not self.clipboard_monitor_task.done():
                # Signal the loop to exit.
                self.stop_clipboard()
                self.clipboard_monitor_task.cancel()
                try:
                    await self.clipboard_monitor_task
                except asyncio.CancelledError:
                    pass
                self.clipboard_monitor_task = asyncio.create_task(self.start_clipboard())
    def _wayland_display_name(self):
        """The compositor's REAL socket name. The pixelflux compositor auto-picks
        the first free wayland-N socket, so the running backend is authoritative;
        the process env is next (stream_server mirrors the name there at bring-up)
        and --wayland-socket-index survives only as a legacy hint."""
        try:
            from pixelflux import get_wayland_display_name
            name = get_wayland_display_name()
            if name:
                return name
        except Exception:
            pass
        return (os.environ.get("WAYLAND_DISPLAY")
                or f"wayland-{self.wayland_socket_index}")

    def _app_wayland_display(self):
        """Socket of the compositor applications run under — the target for input
        injection and clipboard. It equals the capture compositor for a plain
        pixelflux session, but a nested session that pixelflux
        captures owns the apps on its own socket, so input and clipboard aimed at
        the capture compositor never reach them. Resolution order: the explicit
        app_wayland_display setting; else the single other wayland-* socket in
        XDG_RUNTIME_DIR besides the capture compositor's; else the capture socket.
        A distinct result is cached permanently; the capture fallback is negative-
        cached with a short TTL, so a nested compositor that appears after startup
        is still picked up within a couple seconds without relisting per call."""
        if self._app_wl_display_cached is not None:
            return self._app_wl_display_cached
        now = time.monotonic()
        if (self._app_wl_negcache is not None
                and (now - self._app_wl_negcache_at) < 2.0):
            return self._app_wl_negcache
        self._app_wl_negcache_at = now
        capture = self._wayland_display_name()
        override = (self.app_wayland_display or "").strip()
        if override:
            return self._adopt_app_wl_display(override, capture, "configured")
        resolved = None
        try:
            import stat as _stat
            runtime = os.environ.get("XDG_RUNTIME_DIR")
            cap_base = os.path.basename(capture)
            if runtime and os.path.isdir(runtime):
                others = sorted(
                    n for n in os.listdir(runtime)
                    if n.startswith("wayland-") and not n.endswith(".lock")
                    and n != cap_base
                    and _stat.S_ISSOCK(os.stat(os.path.join(runtime, n)).st_mode))
                # Only a socket that actually accepts a connection qualifies: a stale
                # wayland-* file left by a dead compositor would otherwise be adopted
                # and silently break clipboard + input in an ordinary session.
                others = [n for n in others
                          if self._wl_socket_live(os.path.join(runtime, n))]
                if len(others) == 1:
                    resolved = others[0]
                elif len(others) > 1:
                    # A compositor's socket is wayland-<N>; a differently named
                    # one beside it is a relay a session listens on, not a
                    # session of its own. Falling back to the capture compositor
                    # over one aims every overlay keysym and the selection at a
                    # keymap and clipboard the applications never see.
                    numbered = [n for n in others
                                if n[len("wayland-"):].isdigit()]
                    if len(numbered) == 1:
                        resolved = numbered[0]
                    else:
                        logger_webrtc_input.warning(
                            "Multiple candidate app-compositor sockets %s; set "
                            "app_wayland_display to choose. Using capture compositor.",
                            others)
        except Exception as e:
            logger_webrtc_input.debug(f"App-compositor autodetect failed: {e}")
        if resolved and resolved != capture:
            return self._adopt_app_wl_display(resolved, capture, "auto-detected")
        self._app_wl_negcache = capture
        return capture

    @staticmethod
    def _wl_socket_live(path):
        """True if a Wayland socket accepts a connection right now (rejecting a
        stale socket file with no listener)."""
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.settimeout(0.2)
            try:
                s.connect(path)
                return True
            finally:
                s.close()
        except OSError:
            return False

    def _adopt_app_wl_display(self, resolved, capture, how):
        """Cache the resolved app compositor and, when it is distinct from the
        capture compositor, hand it to pixelflux over the Python ABI so its
        Computer-Use backend targets the same session. pixelflux keeps its own
        PIXELFLUX_APP_WAYLAND_DISPLAY env fallback for standalone use without
        selkies."""
        self._app_wl_display_cached = resolved
        self._app_wl_negcache = None
        self._app_wl_is_separate = resolved != capture
        if self._app_wl_is_separate:
            logger_webrtc_input.info(
                f"Wayland app compositor '{resolved}' ({how}); routing input + "
                f"clipboard there, capture stays on '{capture}'.")
            try:
                self.wayland_input.set_app_wayland_display(resolved)
            except Exception as e:
                logger_webrtc_input.debug(
                    f"pixelflux set_app_wayland_display failed: {e}")
            self._schedule_session_scale()
            self._schedule_spare_screen_hold()
        return resolved

    def _invalidate_app_wl_display(self):
        """Drop the cached app-compositor resolution so the next call re-detects
        it — used when a connection to it fails (a nested compositor that died or
        restarted on a different socket name)."""
        if self._app_wl_display_cached:
            try:
                self.wayland_input.clipboard_unwatch_app(self._app_wl_display_cached)
            except Exception:
                pass
        self._app_wl_display_cached = None
        self._app_wl_is_separate = False
        self._app_wl_negcache = None
        self._app_wl_negcache_at = 0.0

    def _has_separate_app_compositor(self):
        """True when apps live under a compositor distinct from pixelflux's own,
        so pixelflux's keymap overlay and its selection never reach them. Resolves
        (throttled) then reads the cached flag, so it costs no per-call FFI once
        settled."""
        self._app_wayland_display()
        return self._app_wl_is_separate

    async def realize_wayland_dpi(self, dpi, display_index=0):
        """Apply a DPI on the Wayland backend and return the capture output
        scale it leaves behind.

        Applications draw larger when the compositor they are on scales its own
        output, so a nested session is scaled through its output management and
        the capture keeps 1.0: scaling the capture instead would halve the
        logical size the session is handed and upscale the whole desktop. A
        session that manages no outputs for clients (KWin) takes the capture
        output's scale, which it follows, and so does a plain pixelflux session,
        where the capture output is the only screen there is. XWayland
        applications need nothing merged: they run in the compositor's logical
        space and are scaled with it."""
        try:
            scale = max(0.1, float(dpi) / 96.0)
        except (TypeError, ValueError):
            return 1.0
        try:
            if not self._has_separate_app_compositor():
                return scale
            display = self._app_wayland_display()
            applied = await asyncio.to_thread(
                self.wayland_input.set_app_output_scale, display, display_index, scale)
        except Exception as e:
            logger_webrtc_input.debug(f"Session output scale failed: {e}")
            return scale
        if applied:
            logger_webrtc_input.info(
                f"Session compositor screen {display_index} scaled to {scale}.")
            return 1.0
        return scale

    # A session screen held at a real screen's size while nothing watches it.
    # Small enough to leave the desktop's centre on the screen that is shown,
    # large enough for a compositor to lay out on.
    SPARE_SCREEN_SIZE = (320, 240)

    def _schedule_spare_screen_hold(self):
        """A nested session opens the screens it was started with, whether or
        not the capture drives that many: the extra ones stretch its desktop
        onto a screen nobody sees, which is where a client that centres itself
        then lands. Hold them small until a display arrives for them —
        pixelflux resizes one to its full size the moment it gets an output,
        and back when it loses one."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        loop.create_task(self._hold_spare_screens())

    async def _hold_spare_screens(self):
        display = self._app_wayland_display()
        try:
            keep = max(1, len(await asyncio.to_thread(self.wayland_input.list_outputs)))
            held = await asyncio.to_thread(
                self.wayland_input.hold_spare_app_screens, display, keep,
                *self.SPARE_SCREEN_SIZE)
        except Exception as e:
            logger_webrtc_input.debug(f"Holding spare session screens failed: {e}")
            return
        if held:
            logger_webrtc_input.info(
                f"Session compositor has {held} screen(s) with no capture output; "
                f"held at {self.SPARE_SCREEN_SIZE[0]}x{self.SPARE_SCREEN_SIZE[1]}.")

    def _schedule_session_scale(self):
        """A session compositor was just adopted: hand it the effective DPI as
        its output scale. A scale applied before it existed landed on the
        capture output, which the session does not follow. An operator-set DPI
        governs the desktop (client syncs never reach it then); otherwise the
        last client-synced DPI does. 96 is unity, so nothing to apply."""
        try:
            if settings._overridden.get("scaling_dpi", False):
                dpi = int(float(settings.scaling_dpi))
            else:
                dpi = int(float(getattr(self, "system_dpi", 96) or 96))
        except (TypeError, ValueError, AttributeError):
            return
        if dpi == 96:
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        loop.create_task(self.realize_wayland_dpi(dpi))

    async def _get_file(self, file_path, target_mime):
        max_clipboard_file_size = 10 * 1024 * 1024
        try:
            file_size = await asyncio.to_thread(os.path.getsize, file_path)
            if file_size > max_clipboard_file_size:
                logger_webrtc_input.warning(
                    "Skipping clipboard file %s: %d bytes exceeds 10MB limit", 
                    file_path, file_size
                )
                return None, None
            async with aiofiles.open(file_path, 'rb') as f:
                file_data = await f.read(max_clipboard_file_size + 1)
                if len(file_data) > max_clipboard_file_size:
                    logger_webrtc_input.warning(
                        "Skipping clipboard file %s: file grew beyond 10MB limit during read (%d bytes)",
                        file_path, len(file_data)
                    )
                    return None, None
                return file_data, target_mime
        except OSError as e:
            logger_webrtc_input.warning("Failed to access clipboard file %s: %s", file_path, e)
            return None, None

    async def _kill_and_reap_process(self, proc, description):
        logger_webrtc_input.warning(
            "Timed out waiting for clipboard command '%s' pid=%s; killing it.",
            description,
            getattr(proc, "pid", "unknown"),
        )
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(proc.wait(), timeout=1.0)
        except (asyncio.TimeoutError, ProcessLookupError):
            logger_webrtc_input.warning(
                "Timed-out clipboard command '%s' pid=%s could not be reaped promptly.",
                description,
                getattr(proc, "pid", "unknown"),
            )

    async def _communicate_or_kill(self, proc, timeout, description, input=None):
        try:
            return await asyncio.wait_for(proc.communicate(input=input), timeout=timeout)
        except asyncio.TimeoutError:
            await self._kill_and_reap_process(proc, description)
            raise

    def _clipboard_has_consumers(self):
        if getattr(self.rtc_app, "mode", None) != "websockets":
            return True
        server = self.data_server_instance or getattr(self.rtc_app, "data_streaming_server", None)
        return bool(server and getattr(server, "clients", None))

    async def _app_clipboard_read(self, use_binary):
        """Read the selection of the compositor the apps use over the pixelflux
        data-control ABI; (None, None) when it is empty or unreadable."""
        read_fn = getattr(self.wayland_input, 'clipboard_read_app', None)
        types_fn = getattr(self.wayland_input, 'clipboard_types_app', None)
        if read_fn is None or types_fn is None:
            # pixelflux builds without the app-compositor data-control ABI
            # report no data rather than failing the clipboard path.
            return None, None
        display = self._app_wayland_display()
        loop = asyncio.get_running_loop()
        try:
            available_types = await loop.run_in_executor(
                None, types_fn, display)
            if use_binary:
                image_mimes = ['image/png', 'image/jpeg', 'image/bmp', 'image/webp',
                               'image/svg+xml', 'image/svg']
                target_mime = next((m for m in image_mimes if m in available_types), None)
                if target_mime:
                    data = await loop.run_in_executor(
                        None, read_fn, display, target_mime)
                    if data:
                        return bytes(data), target_mime
            text_mimes = ['text/plain;charset=utf-8', 'text/plain',
                          'UTF8_STRING', 'STRING', 'TEXT']
            source_mime = next((m for m in text_mimes if m in available_types), None)
            if source_mime:
                data = await loop.run_in_executor(None, read_fn, display, source_mime)
                if data is not None:
                    return data.decode('utf-8', errors='replace'), 'text/plain'
        except Exception as e:
            logger_webrtc_input.warning(f"data-control clipboard read failed: {e}")
        return None, None

    async def read_clipboard(self, use_binary=False):
        """Reads clipboard. Wayland is fully native (compositor cache, else the
        data-control client); X11 uses the XFixes monitor with an xclip fallback."""
        if self.is_wayland:
            # The compositor callback caches the capture compositor's selection;
            # with a separate app compositor that cache is the wrong session, so
            # the data-control client reads whichever socket the apps use.
            cached = (None if self._has_separate_app_compositor()
                      else getattr(self, '_wl_native_last', None))
            if cached is not None:
                raw, native_mime = cached
                if native_mime.startswith('image/'):
                    if use_binary:
                        return bytes(raw), native_mime
                else:
                    return bytes(raw).decode('utf-8', errors='replace'), 'text/plain'
            return await self._app_clipboard_read(use_binary)
        monitor = await self._ensure_x11_clipboard_monitor_async()
        if monitor is not None:
            try:
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(None, monitor.read, use_binary)
            except Exception as e:
                logger_webrtc_input.warning(f"native X11 clipboard read failed, using xclip: {e}")
        try:
            proc_targets = await subprocess.create_subprocess_exec(
                "xclip", "-selection", "clipboard", "-o", "-t", "TARGETS",
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            stdout_targets, _ = await self._communicate_or_kill(proc_targets, 1, "xclip TARGETS")
            if proc_targets.returncode != 0:
                return None, None
            targets = stdout_targets.decode().strip().split('\n')
            if use_binary:
                for mime_type in ['image/png', 'image/jpeg', 'image/bmp', 'image/webp',
                                  'image/svg+xml', 'image/svg']:
                    if mime_type in targets:
                        proc_data = await subprocess.create_subprocess_exec(
                            "xclip", "-selection", "clipboard", "-o", "-t", mime_type,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE
                        )
                        stdout_data, _ = await self._communicate_or_kill(proc_data, 3, f"xclip {mime_type}")
                        if proc_data.returncode == 0 and stdout_data:
                            return stdout_data, mime_type

                # Allow copying of images from file managers
                if 'text/uri-list' in targets:
                    proc_data = await subprocess.create_subprocess_exec(
                        "xclip", "-selection", "clipboard", "-o", "-t", "text/uri-list",
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE
                    )
                    stdout_data, _ = await self._communicate_or_kill(proc_data, 1, "xclip text/uri-list")
                    if proc_data.returncode == 0 and stdout_data:
                        lines = stdout_data.decode("utf-8", errors="replace").splitlines()
                        for line in lines:
                            line = line.strip()
                            if not line or line.startswith("#"):
                                continue
                            parsed_uri = urllib.parse.urlparse(line)
                            if parsed_uri.scheme == 'file':
                                file_path = urllib.request.url2pathname(parsed_uri.path)
                                if os.path.isfile(file_path):
                                    ext = os.path.splitext(file_path)[1].lower()
                                    mime_map = {
                                        '.png': 'image/png', '.jpg': 'image/jpeg',
                                        '.jpeg': 'image/jpeg', '.bmp': 'image/bmp',
                                        '.webp': 'image/webp', '.svg': 'image/svg+xml'
                                    }
                                    if ext in mime_map:
                                        target_mime = mime_map[ext]
                                        return await self._get_file(file_path, target_mime)
                                
            if 'UTF8_STRING' in targets:
                proc_text = await subprocess.create_subprocess_exec(
                    "xclip", "-selection", "clipboard", "-o", "-t", "UTF8_STRING",
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                stdout_text, _ = await self._communicate_or_kill(proc_text, 1, "xclip UTF8_STRING")
                if proc_text.returncode == 0:
                    return stdout_text.decode(), 'text/plain'
            return None, None
        except FileNotFoundError:
            if not self._xclip_missing_warned:
                self._xclip_missing_warned = True
                logger_webrtc_input.warning(
                    "xclip is not installed; the clipboard polling rung has "
                    "nothing to read with.")
            return None, None
        except Exception as e:
            logger_webrtc_input.warning(f"Error reading clipboard with xclip: {e}", exc_info=True)
            return None, None

    async def write_clipboard(self, data, mime_type="text/plain"):
        if not data:
            return True
        input_bytes = data if isinstance(data, bytes) else data.encode('utf-8')
        # Client-supplied content becomes the monitor baseline BEFORE the write: the
        # ownership change fires the monitor immediately, and re-broadcasting what a
        # client just sent is the echo loop that saturates the transport.
        self._clipboard_last_bytes = input_bytes

        if self.is_wayland:
            # pixelflux's own selection is set in-process; a separate app
            # compositor's through the data-control client.
            if not self._has_separate_app_compositor():
                try:
                    self.wayland_input.set_clipboard(mime_type, input_bytes)
                    return True
                except Exception as e:
                    logger_webrtc_input.warning(f"native wayland clipboard set failed: {e}")
                    return False
            # Apps paste whichever mime they prefer, so text is offered under
            # every conventional text target.
            if mime_type == "text/plain":
                entries = [(m, input_bytes) for m in (
                    "text/plain;charset=utf-8", "text/plain",
                    "UTF8_STRING", "STRING", "TEXT")]
            else:
                entries = [(mime_type, input_bytes)]
            try:
                await asyncio.get_running_loop().run_in_executor(
                    None, self.wayland_input.clipboard_write_app,
                    self._app_wayland_display(), entries)
                return True
            except Exception as e:
                logger_webrtc_input.warning(f"data-control clipboard write failed: {e}")
                return False

        env = os.environ.copy()
        if 'LANG' not in env or env['LANG'] == 'C':
            env['LANG'] = 'C.UTF-8'
        # Native first: own the selection on the monitor's connection; the xclip -i
        # fork below is the fallback (e.g. unsupported mime, monitor unavailable).
        monitor = await self._ensure_x11_clipboard_monitor_async()
        if monitor is not None:
            try:
                loop = asyncio.get_running_loop()
                ok = await loop.run_in_executor(None, monitor.offer, input_bytes, mime_type)
                if ok:
                    return True
            except Exception as e:
                logger_webrtc_input.warning(f"native X11 clipboard offer failed, using xclip: {e}")
        try:
            is_text = mime_type == "text/plain"
            target_mime = "UTF8_STRING" if is_text else mime_type
            process = await subprocess.create_subprocess_exec(
                "xclip", "-selection", "clipboard", "-i", "-t", target_mime,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=env
            )
            # One deadline covers the whole stdin write plus exit, so a payload
            # larger than the pipe buffer cannot wedge on a stalled xclip.
            await self._communicate_or_kill(
                process, 2.0, f"xclip -i {target_mime}", input_bytes)
            return_code = process.returncode
            if return_code == 0:
                return True
            else:
                logger_webrtc_input.warning(f"xclip process exited with non-zero code: {return_code}")
                return False
        except asyncio.TimeoutError:
            logger_webrtc_input.warning("Timeout waiting for xclip process to terminate.")
            return False
        except FileNotFoundError:
            if not self._xclip_missing_warned:
                self._xclip_missing_warned = True
                logger_webrtc_input.warning(
                    "xclip is not installed; the clipboard polling rung has "
                    "nothing to write with.")
            return False
        except Exception:
            logger_webrtc_input.warning("Error writing to clipboard with xclip", exc_info=True)
            return False
    def _ensure_x11_clipboard_monitor(self):
        """Get-or-create the event-driven X11 monitor; None if unavailable."""
        if self._x11_clipboard_monitor is not None:
            return self._x11_clipboard_monitor
        if self.is_wayland or not X11_LIBS_AVAILABLE:
            return None
        try:
            self._x11_clipboard_monitor = _X11ClipboardMonitor()
            self._x11_monitor_unavail_logged = False
            logger_webrtc_input.info("X11 clipboard: XFixes event monitor active (no polling).")
        except Exception as e:
            log = (logger_webrtc_input.debug if self._x11_monitor_unavail_logged
                   else logger_webrtc_input.info)
            log(f"X11 clipboard: XFixes monitor unavailable ({e}); falling back to polling.")
            self._x11_monitor_unavail_logged = True
            self._x11_clipboard_monitor = None
        return self._x11_clipboard_monitor

    async def _ensure_x11_clipboard_monitor_async(self):
        """Off-loop get-or-create: construction opens its own X connection, and a
        server disrupted mid-session (the respawn case) would stall the event loop
        for the whole bounded handshake. The lock keeps concurrent callers from
        racing two monitors into existence. A failed build backs off before the
        next attempt, so pollers do not hammer a dead display with connection
        attempts — and a display that comes up later is still re-probed."""
        if self._x11_clipboard_monitor is not None:
            return self._x11_clipboard_monitor
        if time.monotonic() < self._x11_monitor_retry_at:
            return None
        async with self._x11_monitor_build_lock:
            if self._x11_clipboard_monitor is not None:
                return self._x11_clipboard_monitor
            monitor = await asyncio.to_thread(self._ensure_x11_clipboard_monitor)
            if monitor is None:
                self._x11_monitor_retry_at = time.monotonic() + 10.0
            return monitor

    def _arm_wayland_native_clipboard(self):
        """Register the compositor clipboard callback (fork-free watch+read);
        returns the delivery queue, or None when the API is unavailable."""
        if not (self.wayland_input is not None
                and hasattr(self.wayland_input, 'set_clipboard_callback')):
            return None
        try:
            loop = asyncio.get_running_loop()
            queue = asyncio.Queue(maxsize=4)

            def _on_clip(mime, data):
                # Cache for on-demand reads (cr/REQUEST_CLIPBOARD): the compositor
                # already handed us the current selection.
                self._wl_native_last = (bytes(data), mime)

                def _put():
                    if queue.full():
                        queue.get_nowait()
                    queue.put_nowait((data, mime))
                loop.call_soon_threadsafe(_put)

            # Kept on self so the monitor loop can re-arm the SAME callback after
            # capture cycles (the compositor drops callbacks on StopCapture).
            self._wl_native_deliver = _on_clip
            self.wayland_input.set_clipboard_callback(_on_clip)
            logger_webrtc_input.info("Wayland clipboard: native compositor callback active (no polling).")
            return queue
        except Exception as e:
            logger_webrtc_input.warning(f"Wayland clipboard: native callback failed to arm ({e}).")
            return None

    def _arm_app_compositor_watch(self):
        """Selection-change signals from the app compositor over the pixelflux
        data-control ABI (fork-free); returns the signal queue, or None when
        arming failed (retried by the monitor loop)."""
        watch_fn = getattr(self.wayland_input, 'clipboard_watch_app', None)
        if watch_fn is None:
            # Without the app-compositor data-control ABI, the native callback
            # monitor covers this display.
            return None
        try:
            loop = asyncio.get_running_loop()
            queue = asyncio.Queue(maxsize=4)

            def _on_change(mimes):
                def _put():
                    if queue.full():
                        queue.get_nowait()
                    queue.put_nowait(mimes)
                loop.call_soon_threadsafe(_put)

            watch_fn(self._app_wayland_display(), _on_change)
            logger_webrtc_input.info(
                "Wayland clipboard: app-compositor data-control watch active (no forks).")
            return queue
        except Exception as e:
            logger_webrtc_input.warning(
                f"Wayland clipboard: app-compositor watch failed to arm ({e}).")
            return None

    async def start_clipboard(self):
        if self.enable_clipboard not in ["true", "out"]:
            logger_webrtc_input.info("Skipping outbound clipboard service."); return

        # Singleton guard with a grace window: a mode switch stops the old monitor and
        # starts the new one immediately — wait briefly for the old loop to unwind
        # instead of refusing (which left sessions with no outbound clipboard until
        # the user toggled the setting).
        for _ in range(50):
            if not self._clipboard_monitor_active:
                break
            await asyncio.sleep(0.1)
        if self._clipboard_monitor_active:
            logger_webrtc_input.info("Clipboard monitor already running; not starting a second instance.")
            return
        self._clipboard_monitor_active = True

        logger_webrtc_input.info(f"Clipboard monitor running (binary mode: {self.enable_binary_clipboard in ['true', 'out']})")
        self.clipboard_running = True
        x11_monitor = await self._ensure_x11_clipboard_monitor_async()
        # The compositor callback watches the capture compositor's selection; with
        # a separate app compositor the apps' copies land on its selection, watched
        # through the data-control client instead.
        wl_native_queue = (self._arm_wayland_native_clipboard()
                           if self.is_wayland and not self._has_separate_app_compositor()
                           else None)
        wl_native_item = None
        # Data-control watch on the app compositor; (re)armed inside the loop so a
        # nested session appearing after startup — or restarting on a new socket —
        # is picked up.
        app_watch_queue = None
        app_watch_display = None
        # Prime the change signal so the first pass publishes current content once.
        first_pass = True
        had_consumers = False
        try:
            while self.clipboard_running:
                try:
                    # Event-driven wait (XFixes / compositor callback / data-control
                    # watch); the timeout only re-checks liveness flags. Polling
                    # remains as the last fallback.
                    wl_native_item = None
                    if self.is_wayland and self._has_separate_app_compositor():
                        disp = self._app_wayland_display()
                        if app_watch_queue is None or disp != app_watch_display:
                            q = self._arm_app_compositor_watch()
                            if q is not None:
                                app_watch_queue, app_watch_display = q, disp
                    elif self.is_wayland and wl_native_queue is None:
                        # Direct mode reached only now (a nested compositor died
                        # or never appeared): arm the compositor callback late.
                        wl_native_queue = self._arm_wayland_native_clipboard()
                    if first_pass:
                        changed = True
                        first_pass = False
                    elif x11_monitor is not None:
                        if not x11_monitor.alive():
                            # The dedicated X connection/event thread exited (display
                            # disruption, XFixes error). Rebuild it in place so outbound
                            # clipboard heals on its own instead of staying dead until
                            # the user toggles the binary-clipboard setting.
                            logger_webrtc_input.warning(
                                "X11 clipboard monitor thread exited; respawning.")
                            try:
                                x11_monitor.close()
                            except Exception:
                                pass
                            self._x11_clipboard_monitor = None
                            x11_monitor = await self._ensure_x11_clipboard_monitor_async()
                            if x11_monitor is None:
                                await asyncio.sleep(0.5)
                                changed = False
                            else:
                                # Republish current content on the fresh monitor; the
                                # baseline compare below still suppresses no-op sends.
                                changed = True
                        else:
                            changed = await x11_monitor.wait_change(2.0)
                    elif wl_native_queue is not None and not self._has_separate_app_compositor():
                        try:
                            wl_native_item = await asyncio.wait_for(wl_native_queue.get(), 2.0)
                            changed = True
                        except asyncio.TimeoutError:
                            changed = False
                            # The compositor drops its callbacks on every capture stop
                            # (interpreter-finalization safety), and captures cycle with
                            # client connects. Re-arming is an idempotent channel send;
                            # doing it each idle tick keeps the watch alive across cycles.
                            try:
                                self.wayland_input.set_clipboard_callback(
                                    self._wl_native_deliver)
                            except Exception:
                                pass
                    elif app_watch_queue is not None:
                        try:
                            await asyncio.wait_for(app_watch_queue.get(), 2.0)
                            changed = True
                        except asyncio.TimeoutError:
                            changed = False
                    elif self.is_wayland:
                        # Neither watch armed yet (compositor briefly absent);
                        # the arming above retries on the next tick.
                        await asyncio.sleep(0.5)
                        changed = False
                    else:
                        # Poll cadence: read + compare below. The XFixes rung is
                        # re-probed on its cooldown, so an X server that answers
                        # later upgrades polling back to events.
                        x11_monitor = await self._ensure_x11_clipboard_monitor_async()
                        await asyncio.sleep(0.5)
                        changed = True

                    has_consumers = self._clipboard_has_consumers()
                    if has_consumers and not had_consumers:
                        # First consumer after a consumer-less stretch: publish the
                        # current selection once, since change events during that
                        # stretch were skipped (a copy made before any client
                        # connected would otherwise never arrive). The baseline
                        # compare below still suppresses unchanged re-sends.
                        changed = True
                    had_consumers = has_consumers
                    if not changed:
                        continue
                    if not has_consumers:
                        continue

                    use_binary = self.enable_binary_clipboard in ["true", "out"]
                    if wl_native_item is not None:
                        # The compositor callback already delivered the bytes.
                        raw, native_mime = wl_native_item
                        if native_mime.startswith('image/') and use_binary:
                            curr_data, curr_mime = bytes(raw), native_mime
                        elif not native_mime.startswith('image/'):
                            curr_data = bytes(raw).decode('utf-8', errors='replace')
                            curr_mime = 'text/plain'
                        else:
                            curr_data, curr_mime = None, None
                    elif x11_monitor is not None:
                        loop = asyncio.get_running_loop()
                        curr_data, curr_mime = await loop.run_in_executor(
                            None, x11_monitor.read, use_binary)
                    else:
                        curr_data, curr_mime = await self.read_clipboard(use_binary=use_binary)
                    if curr_data is None:
                        curr_data_bytes = None
                    else:
                        curr_data_bytes = curr_data.encode('utf-8') if isinstance(curr_data, str) else curr_data
                    if curr_data_bytes is not None and curr_data_bytes != self._clipboard_last_bytes:
                        logger_webrtc_input.info(f"Clipboard changed. Sending content ({curr_mime})")
                        self._clipboard_last_bytes = curr_data_bytes
                        await self.on_clipboard_read(curr_data, curr_mime)
                except asyncio.CancelledError:
                    logger_webrtc_input.info("Clipboard monitor task cancelled.")
                    break
                except Exception as e:
                    logger_webrtc_input.error(f"Error in clipboard monitor loop: {e}", exc_info=True)
                    await asyncio.sleep(2)
        finally:
            self.clipboard_running = False
            self._clipboard_monitor_active = False
            logger_webrtc_input.info("Clipboard monitor stopped")

    def stop_clipboard(self):
        self.clipboard_running = False
        # Release the dedicated X connection + event thread; a mode switch builds a
        # fresh input handler and must not leak one monitor per transition.
        if self._x11_clipboard_monitor is not None:
            self._x11_clipboard_monitor.close()
            self._x11_clipboard_monitor = None
        logger_webrtc_input.info("Stopping clipboard monitor")


    def _handle_mapping_notify(self, event):
        """Keep the python-xlib keymap cache and the XTEST overlay coherent with
        server-side keymap changes. Every in-session layout switch (setxkbmap,
        desktop layout applets, fcitx-xkb) lands here as a MappingNotify; without
        the refresh, keysym_to_keycode resolves against the dead layout and the
        overlay trusts bindings the switch wiped."""
        kb = self.keyboard
        if event.request == X.MappingModifier:
            # A modifier remap moves Shift/AltGr keycodes but not the overlay;
            # our own overlay binds also surface as Modifier notifies on some
            # servers, so clearing the overlay here would loop bind->notify->
            # clear forever.
            if kb is not None:
                kb.refresh_modifier_keycodes()
            return
        if event.request != X.MappingKeyboard:
            return
        try:
            self.xdisplay.refresh_keyboard_mapping(event)
        except Exception as e:
            logger_webrtc_input.warning(f"keymap cache refresh failed: {e}")
        if kb is None:
            return
        if kb.bindings_intact():
            # Our own overlay bind (or a change that left the overlay alone):
            # the bookkeeping is authoritative, keep it.
            return
        logger_webrtc_input.info(
            "Foreign keymap change detected (request=%d, keycodes %d+%d): "
            "invalidating XTEST overlay state.",
            event.request, event.first_keycode, event.count)
        kb.invalidate_mapping()

    async def _keymap_watch_loop(self):
        """Drain X events for MappingNotify when the cursor monitor is not the
        event consumer (pixelflux delivers cursors natively then). Two consumers
        must never race next_event(), so this loop idles while cursors_running."""
        while True:
            if self.cursors_running or self.xdisplay is None:
                # Idle poll only: the event wake is not armed for this consumer
                # when nothing drives it, and a foreign remap is not urgent here.
                await asyncio.sleep(0.5)
                continue
            wake = self._x_event_wake
            if wake is not None:
                wake.clear()
            if self.xdisplay.pending_events() == 0:
                self._arm_x_event_watcher()
                await self._wait_x_event(timeout=2.0)
            if self.cursors_running or self.xdisplay is None:
                continue
            try:
                while self.xdisplay.pending_events():
                    event = self.xdisplay.next_event()
                    if event.type == X.MappingNotify:
                        self._handle_mapping_notify(event)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                if self._is_x_conn_closed(e):
                    self._reconnect_xdisplay()
                else:
                    logger_webrtc_input.debug(f"keymap watch: {e}")

    async def start_cursor_monitor(self):
        if self.is_wayland:
            logger_webrtc_input.info("Wayland mode: Cursor monitor disabled (handled by compositor callback).")
            return
        if pixelflux_x11_cursor():
            logger_webrtc_input.info(
                "X11 cursor monitor disabled (pixelflux cursor callback active)."
            )
            return
        if not self.xdisplay.has_extension("XFIXES"):
            if self.xdisplay.query_extension("XFIXES") is None:
                logger_webrtc_input.error(
                    "XFIXES extension not supported, cannot watch cursor changes"
                )
                return
        xfixes_version = self.xdisplay.xfixes_query_version()
        logger_webrtc_input.info(
            "Found XFIXES version %s.%s",
            xfixes_version.major_version,
            xfixes_version.minor_version,
        )
        logger_webrtc_input.info("starting cursor monitor")
        self.cursors_running = True
        screen = self.xdisplay.screen()
        self.xdisplay.xfixes_select_cursor_input(
            screen.root, xfixes.XFixesDisplayCursorNotifyMask
        )
        logger_webrtc_input.info("watching for cursor changes")
        try:
            cursor_image = self.xdisplay.xfixes_get_cursor_image(screen.root)
            # The X fetch must stay on this thread (python-xlib connections are not
            # thread-safe and the loop also injects input on this display), but the
            # PIL resize + PNG encode is pure CPU: keep it off the event loop.
            cursor_data = await asyncio.to_thread(self.cursor_to_msg, cursor_image)
            self.on_cursor_change(cursor_data)
        except Exception as e:
            logger_webrtc_input.warning("exception from fetching initial cursor image: %s", e)
            if self._is_x_conn_closed(e):
                self._reconnect_xdisplay()

        while self.cursors_running:
            if self.xdisplay is None:
                # A background reconnect is in flight (or failed); wait for the
                # fresh connection — its xfixes arm happened at install — and
                # rebind our screen to it.
                await asyncio.sleep(0.5)
                if self.xdisplay is not None:
                    screen = self.xdisplay.screen()
                continue
            wake = self._x_event_wake
            if wake is not None:
                wake.clear()
            if self.xdisplay.pending_events() == 0:
                # Idle until the X socket goes readable; the 1s failsafe bounds
                # the wait if the loop reader was lost to a reconnect.
                self._arm_x_event_watcher()
                await self._wait_x_event(timeout=1.0)
                continue

            event = self.xdisplay.next_event()
            if event.type == X.MappingNotify:
                self._handle_mapping_notify(event)
                continue
            if (event.type, 0) == self.xdisplay.extension_event.DisplayCursorNotify:
                try:
                    cursor_image = self.xdisplay.xfixes_get_cursor_image(screen.root)
                    cursor_data = await asyncio.to_thread(self.cursor_to_msg, cursor_image)
                    self.on_cursor_change(cursor_data)
                except Exception as e:
                    logger_webrtc_input.warning(
                        "exception from fetching cursor image on change: %s", e
                    )
                    if self._is_x_conn_closed(e):
                        # The None-guard at the top of the loop rebinds screen
                        # once the background reconnect lands.
                        self._reconnect_xdisplay()
        logger_webrtc_input.info("cursor monitor stopped")

    def stop_cursor_monitor(self):
        logger_webrtc_input.info("stopping cursor monitor")
        self.cursors_running = False

    def get_current_cursor_data(self):
        if self.is_wayland:
            return None
        if not self.enable_cursors or not self.xdisplay:
            return None
        try:
            if not self.xdisplay.has_extension("XFIXES"):
                if self.xdisplay.query_extension("XFIXES") is None:
                    logger_webrtc_input.error(
                        "XFIXES extension not supported, cannot fetch current cursor"
                    )
                    return None
            # XFixes requires per-connection version negotiation before any other
            # request, and this on-demand fetch runs whether or not the cursor
            # monitor is up, so it negotiates once itself.
            if not getattr(self, "_xfixes_negotiated", False):
                self.xdisplay.xfixes_query_version()
                self._xfixes_negotiated = True
            screen = self.xdisplay.screen()
            cursor_image = self.xdisplay.xfixes_get_cursor_image(screen.root)
            return self.cursor_to_msg(cursor_image)
        except Exception as e:
            logger_webrtc_input.warning("exception from fetching current cursor image: %s", e)
            return None

    def _cursor_image_to_pil(self, cursor):
        byte_data = b''.join(p.to_bytes(4, 'little') for p in cursor.cursor_image)
        return Image.frombytes("RGBA", (cursor.width, cursor.height), byte_data, "raw", "BGRA")

    def cursor_to_msg(self, cursor):
        if not cursor or cursor.width == 0 or cursor.height == 0:
            return {
                "curdata": "", "width": 0, "height": 0,
                "hotx": 0, "hoty": 0, "handle": 0,
            }
        im = self._cursor_image_to_pil(cursor)
        bbox = im.getbbox()
        if bbox is None:
            return {
                "curdata": "", "width": 0, "height": 0,
                "hotx": 0, "hoty": 0, "handle": 0,
            }
        cropped_im = im.crop(bbox)
        left, upper, right, lower = bbox
        # The hotspot can precede the visible bbox; browsers clamp negative
        # CSS cursor hotspots to 0 silently, so clamp here where the crop
        # rebase happens and both renderers agree.
        new_hotx = max(0, cursor.xhot - left)
        new_hoty = max(0, cursor.yhot - upper)
        if cropped_im.width > self.cursor_size_cap or cropped_im.height > self.cursor_size_cap:
            if self.cursor_debug:
                logger_webrtc_input.info(f"Cursor ({cropped_im.width}x{cropped_im.height}) exceeds cap ({self.cursor_size_cap}x{self.cursor_size_cap}). Resizing.")
            max_dim = max(cropped_im.width, cropped_im.height)
            scale_factor = self.cursor_size_cap / max_dim
            new_width = int(cropped_im.width * scale_factor)
            new_height = int(cropped_im.height * scale_factor)
            cropped_im = cropped_im.resize(
                (new_width, new_height), resample=Image.Resampling.LANCZOS
            )
            new_hotx = min(round(new_hotx * scale_factor), max(0, new_width - 1))
            new_hoty = min(round(new_hoty * scale_factor), max(0, new_height - 1))
        # XFixes pixels are premultiplied; straighten only after any resize
        # (resampling is linear per channel in premultiplied space), matching
        # the pixelflux monitor's pipeline.
        cropped_im = unpremultiply_rgba(cropped_im)
        with io.BytesIO() as f:
            cropped_im.save(f, "PNG")
            png_data = f.getvalue()
        png_data_b64 = base64.b64encode(png_data)
        return {
            "curdata": png_data_b64.decode(),
            "width": cropped_im.width,
            "height": cropped_im.height,
            "hotx": new_hotx,
            "hoty": new_hoty,
            # Same pixel-content handle space as format_pixelflux_cursor, so
            # the connect-time seed and the live path dedupe one shape to one
            # client cache entry.
            "handle": cursor_content_handle(
                cropped_im.tobytes(), cropped_im.width, cropped_im.height,
                new_hotx, new_hoty),
        }

    async def stop_gamepad_servers(self):
        logger_webrtc_input.info("Stopping all gamepad instances.")
        await self.__gamepad_disconnect()

    def _keyboard_enqueue(self, item):
        """Enqueue input for the keyboard worker, evicting the oldest entry on
        overflow so a message flood can't grow the queue without bound. A held key
        orphaned by an evicted release is recovered by the stale sweep, which only
        covers keysyms tracked in pressed_keys — server-generated sequences are not
        tracked, so they go through _keyboard_enqueue_chord instead."""
        try:
            self.keyboard_queue.put_nowait(item)
        except asyncio.QueueFull:
            try:
                self.keyboard_queue.get_nowait()
                self.keyboard_queue.task_done()
            except asyncio.QueueEmpty:
                pass
            try:
                self.keyboard_queue.put_nowait(item)
            except asyncio.QueueFull:
                logger_webrtc_input.warning("keyboard queue full; dropping input event.")

    def _keyboard_enqueue_chord(self, keys):
        """Enqueue a server-synthesized press/release sequence as ONE entry, so
        overflow eviction can only lose it whole.

        `keys` is a sequence of (keysym, down) pairs the worker injects in order.
        These keysyms never enter pressed_keys (no client 'ku' follows them), so a
        release evicted on its own would leave the modifier held with nothing to
        heal it — the stale sweep only covers tracked keys.
        """
        self._keyboard_enqueue(("chord", tuple(keys)))

    def _route_key_as_text(self, keysym):
        """Record a keysym whose kd became buffered text, so its ku is swallowed
        instead of releasing a key that was never pressed. Bounded like
        pressed_keys, evicting the oldest entry."""
        if len(self._wl_text_routed) >= self.max_pressed_keys:
            self._wl_text_routed.pop(next(iter(self._wl_text_routed)), None)
        self._wl_text_routed[keysym] = True

    async def _keyboard_worker(self):
        unicode_buffer = []

        def native_inject():
            # The keymap owner injects any keysym in order (overlay-bound when
            # needed) through the capture compositor, so text needs no batching --
            # but only when that compositor is also where apps run. With a nested
            # app compositor its overlay never reaches the apps, so fall to the
            # virtual-keyboard batch, which targets the app compositor directly.
            return (bool(self.wayland_input
                         and hasattr(self.wayland_input, 'set_keymap_string'))
                    and not self._has_separate_app_compositor())

        async def flush_buffer():
            if unicode_buffer:
                combined_text = "".join(unicode_buffer)
                unicode_buffer.clear()

                # Buffered text is, by construction, the non-layout-representable keysyms
                # (Latin-1 accents, Euro, Unicode plane) and IME composition strings.
                # Inject it as text through zwp_virtual_keyboard — never through the
                # keymap, whose overlay swap is a non-op outside the English layout —
                # and on a compositor without that protocol (KWin), paste it through
                # the clipboard instead.
                try:
                    await self._wl_type_text(combined_text)
                    return
                except Exception as e:
                    logger_webrtc_input.debug(
                        f"virtual-keyboard batch failed ({e}); pasting via clipboard")
                if not await self._inject_text_via_clipboard(combined_text):
                    logger_webrtc_input.warning(
                        f"Batched text injection failed; {len(combined_text)} chars dropped.")

        while True:
            try:
                if unicode_buffer:
                    try:
                        msg_type, data = await asyncio.wait_for(self.keyboard_queue.get(), timeout=0.05)
                    except asyncio.TimeoutError:
                        await flush_buffer()
                        continue
                else:
                    msg_type, data = await self.keyboard_queue.get()

                try:
                    keysym = data if msg_type in ("kd", "ku") else None
                    is_unicode_fallback = False
                    if keysym is not None:
                        is_unicode_fallback = (0xA0 <= keysym <= 0xFF) or keysym == 0x20AC or ((keysym & 0xFF000000) == 0x01000000)

                    if msg_type == "kd":
                        # Modifier-held unicode normally goes through the seat so
                        # the app sees the chord — but a nested app compositor
                        # never resolves seat-overlay keysyms, so there the text
                        # is typed anyway (plain, via the virtual keyboard)
                        # rather than vanishing.
                        if (is_unicode_fallback and not native_inject()
                                and (not self.active_modifiers
                                     or self._has_separate_app_compositor())):
                            unicode_codepoint = keysym & 0x00FFFFFF if (keysym & 0xFF000000) == 0x01000000 else keysym
                            try:
                                char_to_type = chr(unicode_codepoint)
                                unicode_buffer.append(char_to_type)
                                self._route_key_as_text(keysym)
                                continue
                            except ValueError:
                                pass

                        if keysym == 65288 and unicode_buffer:
                            unicode_buffer.pop()
                            continue

                        if (not is_unicode_fallback
                                and keysym is not None and not native_inject()
                                and keysym not in self.MODIFIER_KEYSYMS
                                and not ((self.active_modifiers & self.ACTION_MODIFIER_KEYSYMS)
                                         and keysym in CYRILLIC_TO_QWERTY_KEYSYM)):
                            # Legacy-plane keysyms (Cyrillic, Arabic, Hebrew, Greek,
                            # Thai, ...) the base layout lacks would need a seat
                            # overlay bind, which a nested app compositor
                            # re-translates through its OWN keymap — the key
                            # arrives with no symbol at best. Any such keysym that
                            # spells a character rides the text batch to the app
                            # compositor instead; chord-translated Cyrillic stays
                            # on the seat, where its QWERTY keysym resolves under
                            # any latin-based keymap. Control/navigation keysyms
                            # spell no character, so the owner is never consulted
                            # for them.
                            char_to_type = keysym_to_character(keysym)
                            if char_to_type is not None:
                                owner = await self._ensure_wayland_keymap_owner()
                                if owner is None or not owner.resolves(keysym):
                                    unicode_buffer.append(char_to_type)
                                    self._route_key_as_text(keysym)
                                    continue

                        await flush_buffer()

                        if keysym in self.MODIFIER_KEYSYMS:
                            self.active_modifiers.add(keysym)

                        await self.send_x11_keypress(keysym, down=True)

                    elif msg_type == "ku":
                        if keysym is not None and self._wl_text_routed.pop(keysym, None):
                            # Its kd became buffered text: typed atomically, so
                            # there is no held key to release — regardless of how
                            # the topology looks by now.
                            continue
                        if is_unicode_fallback and not native_inject():
                            # Buffered text was typed atomically; there is no held key.
                            continue

                        if keysym in self.MODIFIER_KEYSYMS:
                            self.active_modifiers.discard(keysym)
                        if keysym in self.atomically_typed_keys:
                            self.atomically_typed_keys.discard(keysym)
                        else:
                            await self.send_x11_keypress(keysym, down=False)

                    elif msg_type == "chord":
                        # A whole server-synthesized sequence in one entry: its
                        # presses and releases are injected back-to-back, so no
                        # other queued key can land between them.
                        await flush_buffer()
                        for chord_keysym, down in data:
                            if chord_keysym in self.MODIFIER_KEYSYMS:
                                if down:
                                    self.active_modifiers.add(chord_keysym)
                                else:
                                    self.active_modifiers.discard(chord_keysym)
                            await self.send_x11_keypress(chord_keysym, down=down)

                    elif msg_type == "kr":
                        self._wl_text_routed.clear()
                        await flush_buffer()
                        await self.reset_keyboard()

                    elif msg_type == "co_end":
                        if native_inject():
                            # One batch: every missing keysym binds in a single
                            # compositor keymap swap, then the taps flow ordered
                            # through the compositor channel. The per-char path
                            # below is the fallback when a char is unbindable.
                            typed = False
                            owner = await self._ensure_wayland_keymap_owner()
                            if owner is not None:
                                try:
                                    typed = await asyncio.to_thread(
                                        owner.type_text, data,
                                        not (self.active_modifiers
                                             & self.ACTION_MODIFIER_KEYSYMS))
                                except Exception as e:
                                    logger_webrtc_input.warning(
                                        f"Batched Wayland composition type failed; "
                                        f"falling back per-char: {e}")
                            if not typed:
                                for ch in data:
                                    cp = ord(ch)
                                    ks = cp if 0x20 <= cp <= 0xFF else (0x01000000 | cp)
                                    await self.send_x11_keypress(ks, down=True)
                                    await self.send_x11_keypress(ks, down=False)
                        else:
                            unicode_buffer.append(data)

                finally:
                    self.keyboard_queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger_webrtc_input.error(f"Error in keyboard worker: {e}", exc_info=True)

    def _reset_multipart_clipboard(self):
        """Reset all multi-part clipboard receive state to its idle defaults.

        Used on completion/abort so no field (size, mime type, buffer, id, kind)
        is left stale to bleed into the next cbs/cws transfer.
        """
        self.multipart_clipboard_buffer = None
        self.multipart_clipboard_in_progress = False
        self.multipart_clipboard_id = None
        self.multipart_clipboard_kind = None
        self.multipart_clipboard_total_size = 0
        self.multipart_clipboard_mime_type = "text/plain"

    async def on_message(self, msg: str, display_id='primary', conn_id=None):
        # A malformed client message must not tear down the transport connection.
        try:
            await self._dispatch_message(msg, display_id, conn_id)
        except (IndexError, ValueError) as e:
            logger_webrtc_input.warning(f"Malformed client message {msg[:64]!r}: {e}")
        except Exception as e:
            logger_webrtc_input.error(f"Error handling client message {msg[:64]!r}: {e}", exc_info=True)

    async def _dispatch_message(self, msg: str, display_id='primary', conn_id=None):
        toks = msg.split(",")
        msg_type = toks[0]

        if msg_type == "pong":
            if self.ping_start is None:
                # Not an error: after a transport flip the client of the other mode
                # (WebRTC pings over its data channel; WS has no app-level ping) may
                # still answer — just drop the straggler.
                logger_webrtc_input.debug("received pong before ping; ignoring")
                return
            self.on_ping_response(float("%.3f" % ((time.time() - self.ping_start) / 2 * 1000)))
        elif msg_type == "kd":
            keysym = int(toks[1])
            # Cap the held-key map against a kd-flood. On a new keysym at the cap,
            # evict the oldest (LRU) rather than the new one: the key is always
            # injected below, so an untracked held key would never get auto-released.
            if keysym in self.pressed_keys:
                self.pressed_keys[keysym] = time.monotonic()
            else:
                if len(self.pressed_keys) >= self.max_pressed_keys:
                    oldest_keysym = min(self.pressed_keys, key=self.pressed_keys.get)
                    self.pressed_keys.pop(oldest_keysym, None)
                self.pressed_keys[keysym] = time.monotonic()
            # A fresh press makes the key live again: drop any reaped-atomic marker
            # so its next 'ku' is honored normally (not swallowed as a stale reap).
            self.reaped_atomic_keys.discard(keysym)
            if self.is_wayland:
                self._keyboard_enqueue(("kd", keysym))
            else:
                is_printable = (0x20 <= keysym <= 0xFF) or ((keysym & 0xFF000000) == 0x01000000)
                if keysym in self.MODIFIER_KEYSYMS:
                    self.active_modifiers.add(keysym)
                if is_printable and not self.active_modifiers:
                    unicode_codepoint = keysym & 0x00FFFFFF if (keysym & 0xFF000000) == 0x01000000 else keysym
                    try:
                        char_to_type = chr(unicode_codepoint)
                        if not char_to_type.isalpha() and char_to_type != ' ':
                            await self.on_message(f"co,end,{char_to_type}")
                            self.atomically_typed_keys.add(keysym)
                        else:
                            await self.send_x11_keypress(keysym, down=True)
                    except (ValueError, TypeError):
                        await self.send_x11_keypress(keysym, down=True)
                else:
                    await self.send_x11_keypress(keysym, down=True)
                # Arm X11 server-side auto-repeat for this held key. Only the
                # newest held key repeats, so move it to the end of the insertion-ordered
                # map (pop+insert). Modifiers never repeat. Atomically-typed keys
                # (digits/punctuation typed once via co,end) ARE armed: real keyboards
                # repeat these, and _key_repeat_loop re-dispatches the same atomic type
                # action for them rather than a raw X11 KeyPress.
                if (self.key_repeat_enabled and keysym not in self.MODIFIER_KEYSYMS):
                    self.key_repeat_state.pop(keysym, None)
                    self.key_repeat_state[keysym] = time.monotonic() + self.key_repeat_delay
                else:
                    self.key_repeat_state.pop(keysym, None)
        elif msg_type == "ku":
            keysym = int(toks[1])
            self.pressed_keys.pop(keysym, None)
            self.key_repeat_state.pop(keysym, None)
            if self.is_wayland:
                self._keyboard_enqueue(("ku", keysym))
            else:
                if keysym in self.MODIFIER_KEYSYMS:
                    self.active_modifiers.discard(keysym)
                if keysym in self.reaped_atomic_keys:
                    # The stale-sweep already reaped this atomically-typed key
                    # (which was never physically held on X11). Swallow the late,
                    # legit 'ku' so we don't inject a spurious keyup for it.
                    self.reaped_atomic_keys.discard(keysym)
                elif keysym in self.atomically_typed_keys:
                    # Atomically-typed key was never physically held on X11, so
                    # there is no matching key-up to inject — just clear tracking.
                    self.atomically_typed_keys.discard(keysym)
                else:
                    await self.send_x11_keypress(keysym, down=False)
        elif msg_type == "kr":
            if self.is_wayland:
                self._keyboard_enqueue(("kr", None))
            else:
                await self.reset_keyboard()
        elif msg_type == "kh":
            # Heartbeat for held keys: refresh timestamps only (no injection),
            # so it costs nothing but keeps the stale-sweep from releasing them.
            # Atomically-typed keys (digits/punctuation on X11) are refreshed like
            # any other held key: the client heartbeats only what it still holds,
            # and the X11 repeat loop pauses on a stale heartbeat, so skipping them
            # here would kill their auto-repeat before the first repeat is due.
            now = time.monotonic()
            # Cap the fan-out at the tracked-key limit: refreshing more keys than we
            # can track is meaningless and a client could otherwise pack one frame
            # with tens of thousands of tokens (unbounded int()+dict work, DoS).
            for tok in toks[1:1 + self.max_pressed_keys]:
                try:
                    keysym = int(tok)
                except ValueError:
                    continue
                if keysym in self.pressed_keys:
                    self.pressed_keys[keysym] = now
        elif msg_type in ["m", "m2"]:
            relative = msg_type == "m2"
            try: x, y, button_mask, scroll_magnitude = [int(i) for i in toks[1:]]
            except (ValueError, IndexError): x,y,button_mask,scroll_magnitude = 0,0,self.button_mask,0; relative=False
            try: await self.send_x11_mouse(x, y, button_mask, scroll_magnitude, relative, display_id=display_id)
            except Exception as e: logger_webrtc_input.warning(f"Failed to set mouse cursor: {e}")
        elif msg_type == "p": await self.on_mouse_pointer_visible(bool(int(toks[1])))
        elif msg_type == "vb":
            try:
                # kbps (integer). Per-display: the sending page's channel names
                # the display whose stream it tunes.
                bitrate = int(toks[1])
                if bitrate <= 0:
                    return
                await self.on_video_encoder_bit_rate(bitrate, display_id)
            except Exception as e:
                logger_webrtc_input.error(f"Error video bitrate change: {e}")
        elif msg_type == "ab":
            try:
                bitrate = int(toks[1])
                if bitrate <= 0:
                    return
                await self.on_audio_encoder_bit_rate(bitrate)
            except Exception as e:
                logger_webrtc_input.error(f"Error audio bitrate change: {e}")
        elif msg_type == "js":
            # Deployment policy: when the gamepad add-on is disabled, drop every gamepad
            # message (connect/disconnect/button/axis) server-side so a client can't
            # inject controller input regardless of its own UI state.
            if not settings.gamepad_enabled[0]:
                return
            cmd = toks[1]
            gamepad_idx = int(toks[2])

            if not (0 <= gamepad_idx < self.num_gamepads):
                logger_webrtc_input.error(f"Client message for gamepad index {gamepad_idx} is out of range (0-{self.num_gamepads-1}).")
                return

            # Get the persistent gamepad instance. It should always exist after connect().
            target_gamepad_instance = self.gamepad_instances.get(gamepad_idx)
            if not target_gamepad_instance:
                logger_webrtc_input.error(
                    f"CRITICAL: No persistent SelkiesGamepad instance found for index {gamepad_idx} in on_message. "
                    f"Gamepad system may not be initialized correctly."
                )
                return

            if cmd == "c": 
                try: client_name_decoded = base64.b64decode(toks[3]).decode('latin-1', 'ignore')[:255]
                except Exception as e: client_name_decoded = f"ClientGamepad{gamepad_idx}"; logger_webrtc_input.warning(f"Error decoding client gamepad name: {e}")
                client_num_axes, client_num_btns = int(toks[4]), int(toks[5])
                
                await self.__gamepad_connect(gamepad_idx, client_name_decoded, client_num_btns, client_num_axes, conn_id=conn_id)

            elif cmd == "d": 
                await self.__gamepad_disconnect(gamepad_idx)
            
            elif cmd == "b": 
                button_num = int(toks[3])
                button_val = float(toks[4])
                # Send event to the persistent target_gamepad_instance
                target_gamepad_instance.send_event(button_num, button_val, is_button_event=True)

            elif cmd == "a": 
                axis_num = int(toks[3])
                axis_val = float(toks[4])
                # Send event to the persistent target_gamepad_instance
                target_gamepad_instance.send_event(axis_num, axis_val, is_button_event=False)
            
            else: logger_webrtc_input.warning(f"Unhandled joystick command for slot {gamepad_idx}: js {cmd}")
        elif msg_type == "cws":
            if self.enable_clipboard in ["true", "in"]:
                try:
                    transfer_id = toks[1]
                    declared_size = int(toks[2])
                    if declared_size < 0 or declared_size > MULTIPART_CLIPBOARD_MAX_SIZE:
                        logger_webrtc_input.error(f"Rejecting multi-part clipboard write: declared size {declared_size} out of bounds (max {MULTIPART_CLIPBOARD_MAX_SIZE}).")
                        return
                    if self.multipart_clipboard_in_progress and transfer_id != self.multipart_clipboard_id:
                        logger_webrtc_input.warning(f"Aborting previous in-progress clipboard transfer {self.multipart_clipboard_id} for new transfer {transfer_id}.")
                    self.multipart_clipboard_id = transfer_id
                    self.multipart_clipboard_kind = "text"
                    self.multipart_clipboard_total_size = declared_size
                    self.multipart_clipboard_mime_type = "text/plain"
                    self.multipart_clipboard_buffer = io.BytesIO()
                    self.multipart_clipboard_in_progress = True
                    logger_webrtc_input.info(f"Starting multi-part text clipboard receive, total size: {self.multipart_clipboard_total_size}")
                except Exception as e:
                    logger_webrtc_input.error(f"Invalid cws message: {msg}, error: {e}")
            else:
                logger_webrtc_input.warning("Rejecting multi-part clipboard write: inbound clipboard disabled.")
        elif msg_type == "cbs":
            # Direction gate AND binary gate: honest clients don't send binary while
            # it's off, but the server must enforce its own policy regardless.
            if self.enable_clipboard in ["true", "in"] and self.enable_binary_clipboard in ["true", "in"]:
                try:
                    transfer_id = toks[1]
                    declared_size = int(toks[3])
                    if declared_size < 0 or declared_size > MULTIPART_CLIPBOARD_MAX_SIZE:
                        logger_webrtc_input.error(f"Rejecting multi-part clipboard write: declared size {declared_size} out of bounds (max {MULTIPART_CLIPBOARD_MAX_SIZE}).")
                        return
                    if self.multipart_clipboard_in_progress and transfer_id != self.multipart_clipboard_id:
                        logger_webrtc_input.warning(f"Aborting previous in-progress clipboard transfer {self.multipart_clipboard_id} for new transfer {transfer_id}.")
                    self.multipart_clipboard_id = transfer_id
                    self.multipart_clipboard_kind = "binary"
                    self.multipart_clipboard_mime_type = toks[2]
                    self.multipart_clipboard_total_size = declared_size
                    self.multipart_clipboard_buffer = io.BytesIO()
                    self.multipart_clipboard_in_progress = True
                    logger_webrtc_input.info(f"Starting multi-part binary clipboard receive ({self.multipart_clipboard_mime_type}), total size: {self.multipart_clipboard_total_size}")
                except Exception as e:
                    logger_webrtc_input.error(f"Invalid cbs message: {msg}, error: {e}")
            else:
                logger_webrtc_input.warning("Rejecting multi-part clipboard write: inbound clipboard disabled.")
        elif msg_type == "cwd" or msg_type == "cbd":
            expected_kind = "text" if msg_type == "cwd" else "binary"
            # A well-formed chunk is "<type>,<id>,<b64>" (3 tokens). Validate the
            # token count *before* indexing so a malformed (e.g. comma-less) chunk
            # mid-transfer doesn't raise IndexError and leave the multipart state
            # half-open, accumulating until cwe/overflow.
            if len(toks) < 3:
                logger_webrtc_input.warning(f"Malformed clipboard chunk ({msg_type}): missing fields; aborting transfer.")
                self._reset_multipart_clipboard()
            elif not (self.multipart_clipboard_in_progress and toks[1] == self.multipart_clipboard_id and self.multipart_clipboard_kind == expected_kind):
                logger_webrtc_input.warning(f"Ignoring mismatched clipboard chunk ({msg_type}): id/kind does not match active transfer.")
            else:
                try:
                    chunk_data = base64.b64decode(toks[2])
                    if self.multipart_clipboard_buffer.tell() + len(chunk_data) > self.multipart_clipboard_total_size:
                        logger_webrtc_input.error("Multi-part clipboard exceeded its declared size; aborting transfer.")
                        self._reset_multipart_clipboard()
                        return
                    self.multipart_clipboard_buffer.write(chunk_data)
                except Exception as e:
                    logger_webrtc_input.error(f"Failed to process clipboard data chunk: {e}")
                    self._reset_multipart_clipboard()
        elif msg_type == "cwe" or msg_type == "cbe":
            expected_kind = "text" if msg_type == "cwe" else "binary"
            # A well-formed end is "<type>,<id>" (2 tokens). Guard the count
            # before indexing toks[1] so a malformed end doesn't raise mid-state.
            if len(toks) < 2:
                logger_webrtc_input.warning(f"Malformed clipboard end ({msg_type}): missing id; aborting transfer.")
                self._reset_multipart_clipboard()
            elif not (self.multipart_clipboard_in_progress and toks[1] == self.multipart_clipboard_id and self.multipart_clipboard_kind == expected_kind):
                logger_webrtc_input.warning(f"Ignoring mismatched clipboard end ({msg_type}): id/kind does not match active transfer.")
            else:
                received_size = self.multipart_clipboard_buffer.tell()
                if received_size != self.multipart_clipboard_total_size:
                    logger_webrtc_input.error(f"Multi-part clipboard size mismatch. Expected {self.multipart_clipboard_total_size}, got {received_size}. Aborting.")
                else:
                    logger_webrtc_input.info(f"Finished multi-part clipboard receive. Total size: {received_size}")
                    data = self.multipart_clipboard_buffer.getvalue()
                    mime_type = self.multipart_clipboard_mime_type
                    # Awaited in-line: messages on this channel are ordered, so a paste
                    # keystroke right behind the transfer must find the clipboard already
                    # set (write_clipboard's internals are timeout-bounded). Pass the raw
                    # UTF-8 bytes straight through (write_clipboard accepts bytes and the
                    # native X11 offer runs in a thread) to skip a redundant multi-MB
                    # decode+re-encode round-trip on the event loop for large text.
                    if await self.write_clipboard(data, mime_type=mime_type):
                        if mime_type == "text/plain":
                            logger_webrtc_input.info(f"Set multi-part clipboard content, length: {len(data)}")
                        else:
                            logger_webrtc_input.info(f"Set multi-part binary clipboard content ({mime_type}), size: {len(data)} bytes")
                self._reset_multipart_clipboard()
        elif msg_type == "cr":
            if self.enable_clipboard in ["true", "out"]:
                data, mime_type = await self.read_clipboard(use_binary=self.enable_binary_clipboard in ["true", "out"])
                if data:
                    if getattr(self.rtc_app, "mode", None) == "websockets":
                        # Tag the reply as a client-requested fetch: the payload
                        # frames are preceded by "clipboard_reply,cr" so clients
                        # can treat it cache-only without the connect-time 5s
                        # heuristic (old clients route the unknown verb to the
                        # input no-op path and keep the heuristic).
                        await self.rtc_app.send_ws_clipboard_data(
                            data, mime_type, reply_to="cr")
                    else:
                        # Same contract over WebRTC: the clipboard-msg carries a
                        # reply_to field (old clients ignore the extra field and
                        # keep their heuristic).
                        await self.rtc_app.send_clipboard_data(
                            data, mime_type, reply_to="cr")
                else:
                    # Reply even when empty: the tag settles the client's
                    # connect-time fetch AND switches it to tagged replies, so a
                    # real clipboard change seconds after connect is never
                    # mistaken for the init snapshot and dropped.
                    logger_webrtc_input.debug("No clipboard content; sending empty tagged reply")
                    if getattr(self.rtc_app, "mode", None) == "websockets":
                        await self.rtc_app.send_ws_clipboard_data(
                            "", "text/plain", reply_to="cr")
                    else:
                        await self.rtc_app.send_clipboard_data(
                            "", "text/plain", reply_to="cr")
            else: logger_webrtc_input.warning("Rejecting clipboard read: outbound clipboard disabled.")
        elif msg_type == "REQUEST_CLIPBOARD":
            # Client sends REQUEST_CLIPBOARD on Ctrl/Cmd+C and awaits the next
            # clipboard,<b64> / clipboard_binary,... message. Read the server clipboard
            # now and push it via the usual on_clipboard_read path (no new wire format).
            if self.enable_clipboard in ["true", "out"]:
                now = time.monotonic()
                # Per-connection debounce: one client's copy must not suppress another's
                # read. Fall back to display_id when no per-connection id is supplied.
                clip_key = conn_id if conn_id is not None else display_id
                # Evict entries older than the debounce window so the dict can't grow
                # unbounded across reconnecting connections.
                if len(self._last_clipboard_request_ts) > 64:
                    self._last_clipboard_request_ts = {
                        k: ts for k, ts in self._last_clipboard_request_ts.items()
                        if now - ts < self._clipboard_request_debounce
                    }
                # Debounce bursts: one read/fork per copy keystroke would be a fork storm.
                if now - self._last_clipboard_request_ts.get(clip_key, 0.0) < self._clipboard_request_debounce:
                    logger_webrtc_input.debug("Debouncing REQUEST_CLIPBOARD (too frequent).")
                else:
                    self._last_clipboard_request_ts[clip_key] = now
                    use_binary = self.enable_binary_clipboard in ["true", "out"]
                    async def _send_requested_clipboard():
                        # Run read_clipboard as a task so a slow read can't stall the
                        # dispatch loop; reuse the on_clipboard_read send path.
                        try:
                            data, mime_type = await self.read_clipboard(use_binary=use_binary)
                            data_bytes = (data.encode('utf-8')
                                          if isinstance(data, str) else data)
                            if data_bytes is not None and data_bytes == self._clipboard_last_bytes:
                                # This read races the injected Ctrl+C: the app has
                                # not published the new selection yet, and pushing
                                # the pre-copy content settles the client's pending
                                # copy with stale data. Wait briefly for the
                                # selection-owner change, then re-read.
                                monitor = self._x11_clipboard_monitor
                                if monitor is not None and monitor.alive():
                                    await monitor.wait_change(0.15)
                                else:
                                    await asyncio.sleep(0.15)
                                data, mime_type = await self.read_clipboard(use_binary=use_binary)
                            if data:
                                await self.on_clipboard_read(data, mime_type)
                            else:
                                logger_webrtc_input.debug("No clipboard content to send on REQUEST_CLIPBOARD.")
                        except Exception as e:
                            logger_webrtc_input.warning(f"REQUEST_CLIPBOARD read failed: {e}")
                    self._spawn_task(_send_requested_clipboard())
            else:
                logger_webrtc_input.warning("Rejecting REQUEST_CLIPBOARD: outbound clipboard disabled.")
        elif msg_type == "cb":
            # Same double gate as cbs: the rejection below is only accurate if the
            # binary policy is actually checked here.
            if self.enable_clipboard in ["true", "in"] and self.enable_binary_clipboard in ["true", "in"]:
                try:
                    _, mime_type, b64_data = toks
                    data_bytes = base64.b64decode(b64_data)
                    # In-line so an immediately-following paste keystroke (same ordered
                    # channel) pastes THIS content, not the previous clipboard.
                    if await self.write_clipboard(data_bytes, mime_type=mime_type):
                        logger_webrtc_input.info(f"Set binary clipboard content ({mime_type}), size: {len(data_bytes)} bytes")
                except Exception as e:
                    logger_webrtc_input.error(f"Binary clipboard write error: {e}")
            else:
                logger_webrtc_input.warning("Rejecting binary clipboard write: inbound binary clipboard disabled.")
        elif msg_type == "cw": 
            if self.enable_clipboard in ["true", "in"]:
                try:
                    data = base64.b64decode(toks[1]).decode("utf-8", 'ignore')
                    # In-line for paste-after-copy ordering (see the cb branch).
                    if await self.write_clipboard(data):
                        logger_webrtc_input.info(f"Set clipboard content, length: {len(data)}")
                except Exception as e:
                    logger_webrtc_input.error(f"Clipboard decode error: {e}")
                    return
            else: 
                logger_webrtc_input.warning("Rejecting clipboard write: inbound clipboard disabled.")
        elif msg_type == "r":
            res = toks[1]
            if re.fullmatch(r"^\d+x\d+$", res):
                # Even-dim normalization lives in parse_resize_dims (round DOWN
                # to even, 8K cap) so both transports realize an odd request
                # identically; pass the request through verbatim.
                _r = self.on_resize(res, display_id)
                if asyncio.iscoroutine(_r): await _r
            else: logger_webrtc_input.warning(f"Rejecting resolution change, invalid: {res}")
        elif msg_type == "s":
            scale = toks[1]
            if re.fullmatch(r"^\d+(\.\d+)?$", scale):
                _s = self.on_scaling_ratio(float(scale))
                if asyncio.iscoroutine(_s): await _s
            else: logger_webrtc_input.warning(f"Rejecting scaling change, invalid: {scale}")
        elif msg_type == "cmd":
            if not settings.command_enabled[0]:
                logger_webrtc_input.warning("Received 'cmd' message, but command execution is disabled by server settings.")
                return
            if len(toks) > 1:
                command_to_run = ",".join(toks[1:])
                logger_webrtc_input.info(f"Attempting to execute command: '{command_to_run}'")
                home_directory = os.path.expanduser("~")
                try:
                    # Use asyncio subprocess for fire-and-forget execution
                    # stdout and stderr are redirected to DEVNULL to ignore output.
                    process = await subprocess.create_subprocess_shell(
                        command_to_run,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        cwd=home_directory
                    )
                    logger_webrtc_input.info(f"Successfully launched command: '{command_to_run}'")
                except Exception as e:
                    logger_webrtc_input.error(f"Failed to launch command '{command_to_run}': {e}")
            else:
                logger_webrtc_input.warning("Received 'cmd' message without a command string.")
        elif msg_type == "_arg_fps":
            try:
                fps = int(toks[1])
                if fps <= 0:
                    return
                await self.on_set_fps(fps, display_id)
            except Exception as e:
                logger_webrtc_input.error(f"Error fps change: {e}")
        elif msg_type == "_arg_resize":
            if len(toks) == 3:
                enabled, res_str = toks[1].lower() == "true", toks[2]
                enable_res = None
                if re.fullmatch(r"^\d+x\d+$", res_str):
                    w,h = [int(i)+int(i)%2 for i in res_str.split("x")]; enable_res = f"{w}x{h}"
                elif res_str: logger_webrtc_input.warning(f"Invalid resolution for enable_resize: {res_str}")
                self.on_set_enable_resize(enabled, enable_res)
            else: logger_webrtc_input.error("Invalid _arg_resize command format")
        elif msg_type == "_f": 
            try: self.on_client_fps(int(toks[1]))
            except (ValueError, IndexError): logger_webrtc_input.error(f"Failed to parse client FPS: {toks}")
        elif msg_type == "_l": 
            try: self.on_client_latency(int(toks[1]))
            except (ValueError, IndexError): logger_webrtc_input.error(f"Failed to parse client latency: {toks}")
        elif msg_type in ["_stats_video", "_stats_audio"]: 
            try: await self.on_client_webrtc_stats(msg_type, ",".join(toks[1:]))
            except (ValueError, IndexError): logger_webrtc_input.error("Failed to parse WebRTC Statistics")
        elif msg_type == "co" and toks[1] == "end":
            try:
                text_to_type = msg[7:]
                if self.is_wayland:
                    self._keyboard_enqueue(("co_end", text_to_type))
                elif self._type_text_xtest(
                        text_to_type,
                        neutralize=not (self.active_modifiers
                                        & self.ACTION_MODIFIER_KEYSYMS)):
                    # Injected in-process via XTEST (mapped chars with shift synthesis,
                    # unmapped Unicode via the spare-keycode overlay) — no per-char
                    # xdotool fork. Falls through to xdotool below only if that fails.
                    pass
                else:
                    cmd = ["xdotool", "type", text_to_type]
                    process = await subprocess.create_subprocess_exec(
                        *cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE
                    )
                    await self._communicate_or_kill(process, 0.5, "xdotool type co,end")
            except Exception as e: logger_webrtc_input.warning(f"Error with co,end type: {e}")
        elif msg_type == "_ebc":
            try:
                enable = toks[1].lower() == "true"
                self._spawn_task(self.update_binary_clipboard_setting(enable))
            except Exception as e:
                logger_webrtc_input.error(f"Error updating binary clipboard setting: {e}")
        elif msg_type == "_rc":
            try:
                mode = toks[1].strip().lower()
                rc_mode = RateControlMode(mode)
                self._spawn_task(self.on_update_rate_control_mode(rc_mode, display_id))
            except Exception as e:
                logger_webrtc_input.error(f"Error updating rate control mode: {e}")
        elif msg_type == "_crf":
            try:
                crf_value = int(toks[1])
                if not (0 <= crf_value <= 51):
                    logger_webrtc_input.warning(f"CRF value out of range (0-51): {crf_value}")
                    return
                self._spawn_task(self.on_update_crf(crf_value, display_id))
            except Exception as e:
                logger_webrtc_input.error(f"Error updating CRF value: {e}")
        elif toks[0].startswith("SETTINGS"):
            settings_data = ','.join(toks[1:]) if len(toks) > 1 else ""
            logger_webrtc_input.info(f"Received SETTINGS message: {settings_data}")
            try:
                settings_json = json.loads(settings_data)
                # Settings apply to the display whose channel delivered them (the
                # transport-level id, not a payload field a page could spoof).
                self._spawn_task(self.on_update_settings(settings_json, display_id))
            except Exception as e:
                logger_webrtc_input.error(f"Failed to parse SETTINGS data: {e}")
        elif toks[0] == "SET_NATIVE_CURSOR_RENDERING":
            # WS-protocol alias for the pointer-visibility toggle ("p,N"): in the
            # WebRTC pipeline both map to the same capture_cursor tunable, and the
            # handler no-ops when the value is already set.
            try:
                await self.on_mouse_pointer_visible(toks[1].strip().lower() in ("1", "true"))
            except (IndexError, ValueError) as e:
                logger_webrtc_input.warning(f"Malformed SET_NATIVE_CURSOR_RENDERING message: {msg[:60]}, error: {e}")
        elif toks[0] == "REQUEST_KEYFRAME":
            # App-level IDR request (viewer-allowed); routes to the pipeline of
            # the display whose channel delivered it, like the RTCP PLI path.
            _kf = self.on_request_keyframe(display_id)
            if asyncio.iscoroutine(_kf): await _kf
        else:
            logger_webrtc_input.info(f"Unknown data channel message: {msg[:100]}")

    def initialize_upload_dir(self):
        if self.upload_dir in ["/sys", "/proc", "/dev"]:
            logger_webrtc_input.info("Can not initialize upload directory at /sys /proc /dev locations")
            return
        if not self.upload_dir:
            logger_webrtc_input.info("Upload dir is empty")
            return

        if self.upload_dir == "~/Desktop":
            # expand the user dir path
            self.upload_dir_path = os.path.expanduser(self.upload_dir)
        else:
            self.upload_dir_path = self.upload_dir

        try:
            os.makedirs(self.upload_dir_path, exist_ok=True)
            logger_webrtc_input.info(f"Upload directory ensured: {self.upload_dir_path}")
        except OSError as e:
            logger_webrtc_input.error(f"Could not create upload directory {self.upload_dir_path}: {e}")
            self.upload_dir_path = None


# MOUSE_POSITION
MOUSE_POSITION = 10
MOUSE_MOVE = 11
MOUSE_SCROLL_UP = 20
MOUSE_SCROLL_DOWN = 21
MOUSE_SCROLL_LEFT = 22
MOUSE_SCROLL_RIGHT = 23
MOUSE_BUTTON_PRESS = 30
MOUSE_BUTTON_RELEASE = 31
MOUSE_BUTTON = 40
MOUSE_BUTTON_LEFT_ID = 41
MOUSE_BUTTON_MIDDLE_ID = 42
MOUSE_BUTTON_RIGHT_ID = 43

# Bits of the client button mask that need translation before the per-bit
# press/release diff: the pen eraser (Pointer Events button 5) has no pointer
# button of its own on either backend and drives the primary button.
MOUSE_MASK_BIT_PRIMARY = 1 << 0
MOUSE_MASK_BIT_ERASER = 1 << 5

# UINPUT constants if uinput_mouse_socket_path is used
UINPUT_BTN_LEFT = (EV_KEY, BTN_LEFT) 
UINPUT_BTN_MIDDLE = (EV_KEY, BTN_MIDDLE) 
UINPUT_BTN_RIGHT = (EV_KEY, BTN_RIGHT) 
# Relative axes: REL_X, REL_Y, REL_HWHEEL, REL_WHEEL.
UINPUT_REL_X = (EV_REL, 0x00)
UINPUT_REL_Y = (EV_REL, 0x01)
UINPUT_REL_HWHEEL = (EV_REL, 0x06)
UINPUT_REL_WHEEL = (EV_REL, 0x08)

# X core pointer button numbers used by XTEST fake_input (1=left, 2=middle, 3=right).
XBUTTON_LEFT = 1
XBUTTON_MIDDLE = 2
XBUTTON_RIGHT = 3

MOUSE_BUTTON_MAP = {
    MOUSE_BUTTON_LEFT_ID: {"uinput": UINPUT_BTN_LEFT, "x11": XBUTTON_LEFT},
    MOUSE_BUTTON_MIDDLE_ID: {"uinput": UINPUT_BTN_MIDDLE, "x11": XBUTTON_MIDDLE},
    MOUSE_BUTTON_RIGHT_ID: {"uinput": UINPUT_BTN_RIGHT, "x11": XBUTTON_RIGHT},
}
